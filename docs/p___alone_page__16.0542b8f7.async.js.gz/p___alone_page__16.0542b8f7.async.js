(window.webpackJsonp=window.webpackJsonp||[]).push([[37],{"/gDc":function(d,l,n){d.exports=n.p+"static/\u5206\u6790\u6D41\u7A0B\u56FE\u7247.ae116877.png"},oaox:function(d,l,n){"use strict";n.d(l,"a",function(){return M});var r=n("tJVT"),o=n("oBTY"),h=n("fOrg"),c=n("+KLJ"),S=n("q1tI"),u=n.n(S),_=n("ysNt"),W=n("9rgm"),T=n("fWQN"),R=n("mtLc"),E;(function(t){t.Linux="Linux",t.Windows="Windows"})(E||(E={}));var H=[{scene:"\u57FA\u672C\u9879",items:[{os:E.Linux,items:u.a.createElement(u.a.Fragment,null)},{os:E.Windows,items:u.a.createElement(u.a.Fragment,null)}]},{scene:"\u52D2\u7D22\u75C5\u6BD2",items:[{os:E.Linux,items:u.a.createElement(u.a.Fragment,null)},{os:E.Windows,items:u.a.createElement(u.a.Fragment,null)}]},{scene:"\u6316\u77FF\u6728\u9A6C",items:[{os:E.Linux,items:u.a.createElement(u.a.Fragment,null)},{os:E.Windows,items:u.a.createElement(u.a.Fragment,null)}]},{scene:"WebShell",items:[{os:E.Linux,items:u.a.createElement(u.a.Fragment,null)},{os:E.Windows,items:u.a.createElement(u.a.Fragment,null)}]},{scene:"\u7F51\u9875\u7E82\u6539",items:[{os:E.Linux,items:u.a.createElement(u.a.Fragment,null)},{os:E.Windows,items:u.a.createElement(u.a.Fragment,null)}]},{scene:"DDos",items:[{os:E.Linux,items:u.a.createElement(u.a.Fragment,null)},{os:E.Windows,items:u.a.createElement(u.a.Fragment,null)}]},{scene:"\u6570\u636E\u6CC4\u9732",items:[{os:E.Linux,items:u.a.createElement(u.a.Fragment,null)},{os:E.Windows,items:u.a.createElement(u.a.Fragment,null)}]},{scene:"\u6D41\u91CF\u52AB\u6301",items:[{os:E.Linux,items:u.a.createElement(u.a.Fragment,null)},{os:E.Windows,items:u.a.createElement(u.a.Fragment,null)}]}],F=n("jJ7j"),w=[{cmdType:"\uFF08\u57FA\u672C\u4ECB\u7ECD\uFF09",items:[{os:E.Windows,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

          \u5E94\u6025\u6392\u67E5\uFF0C\u5E38\u7528\u6A21\u5757

          `))},{os:E.Linux,content_item:u.a.createElement(u.a.Fragment,null)}]},{cmdType:"\u7CFB\u7EDF\u4FE1\u606F",items:[{os:E.Windows,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u7CFB\u7EDF\u4FE1\u606F
                      \u57FA\u672C\u4FE1\u606F
                          systeminfo
                              \u5728CMD\u4E2D\u67E5\u770B\uFF0C\u6587\u5B57\u7248\u7684\u4FE1\u606F\u3002


                          msinfo32
                                  \uFF08\u8001\u7248\u672C\u7684\uFF0C\u7528winmsd\uFF0C\u6548\u679C\u4E00\u6837\uFF09
                              \u67E5\u770B\u3010\u7CFB\u7EDF\u4FE1\u606F\u3011
                                  \u770B\u4E0A\u53BB\uFF0C\u8FD8\u662F\u975E\u5E38\u8BE6\u7EC6\u7684\u3002

                                  \u5E38\u89C1\u7C7B\u522B\uFF1A
                                      \u6B63\u5728\u8FD0\u884C\u4EFB\u52A1
                                      \u670D\u52A1
                                      \u7CFB\u7EDF\u9A71\u52A8\u670D\u52A1
                                      \u52A0\u8F7D\u7684\u6A21\u5757
                                      \u542F\u52A8\u7A0B\u5E8F



                      \u7528\u6237\u4FE1\u606F
                          \u547D\u4EE4\u884C \u65B9\u6CD5          \uFF08\u9ED8\u8BA4\u65E0\u6CD5\u770B\u5230\u3010\u9690\u85CF\u8D26\u6237\u3011\uFF09
                                  \u3010net\u76F8\u5173\u3011\u6307\u4EE4\u3002
                                      \u666E\u901A\u67E5\u770B
                                          net  user
                                              \u67E5\u770B\u7528\u6237

                                      \u67E5\u770B\u3010\u9690\u85CF\u7528\u6237\u3011
                                          net  user  <\u7528\u6237\u540D\u79F0_\u4EE5$\u7ED3\u5C3E>
                                              \u4ECB\u7ECD\uFF1A
                                                  123
                                              \u5FC5\u8981\u6027\uFF1A
                                                  \u5982\u679C\u670D\u52A1\u5668\u88AB\u9ED1\uFF0C\u88AB\u4EBA\u52A0\u4E86\u4E00\u4E2A\u5E26 $ \u7684\u7528\u6237\uFF0C\u5728\u670D\u52A1\u5668\u91CD\u542F\u4E4B\u524D\uFF0C\u5728\u670D\u52A1\u5668\u7BA1\u7406\u5668\u4E2D\u662F\u770B\u4E0D\u5230\u8FD9\u4E2A\u7528\u6237\u7684\u3002

                                  \u3010wmic\u7528\u6237\u76F8\u5173\u3011\u6307\u4EE4\u3002
                                      wmic  useraccount  get  name,SID



                          \u56FE\u5F62\u5316\u754C\u9762 \u65B9\u6CD5        \uFF08\u53EF\u4EE5\u770B\u5230\u3010\u9690\u85CF\u8D26\u6237\u3011\uFF09
                                  \u2460 \u53EF\u4EE5\u4ECE\u3010\u7BA1\u7406\u2014\u2014\u8BA1\u7B97\u673A\u7BA1\u7406\uFF08\u672C\u5730\uFF09\u2014\u2014\u672C\u5730\u7528\u6237\u548C\u7EC4\u2014\u2014\u7528\u6237\u3011\u53BB\u67E5\u770B\u3002

                                  \u2461 \u8FD8\u53EF\u4EE5\u542F\u52A8\u3010lusrmgr.msc\u3011\uFF0C\u662F\u4E00\u6837\u7684\u6548\u679C\u3002

                          \u67E5\u6CE8\u518C\u8868 \u65B9\u6CD5           \uFF08\u53EF\u4EE5\u67E5\u627E\u5230\u3010\u514B\u9686\u7528\u6237\u3011\uFF09
                                  \uFF08\u89C1\u4E0B\u65B9\uFF09


                      \u7F51\u7EDC\u4FE1\u606F
                          \u3010net\u76F8\u5173\u6307\u4EE4\u3011
                              net  session
                                  \u67E5\u770B\u3010\u5F53\u524D\u4F1A\u8BDD\u3011
                              net  use
                                  \u67E5\u770B\u3010\u8FDC\u7A0B\u8FDE\u63A5\u3011
                              net  share
                                  \u67E5\u770B\u3010\u5F53\u524D\u7528\u6237\u3011\u4E0B\u7684\u3010\u5171\u4EAB\u76EE\u5F55\u3011
                              net  start
                                  \u67E5\u770B\u3010\u5F53\u524D\u8FD0\u884C\u670D\u52A1\u3011
                              net  localgroup  administrators
                                  \u67E5\u770B\u3010\u672C\u673A\u7BA1\u7406\u5458\u7EC4\u3011\u7684\u6210\u5458

                          \u3010\u9632\u706B\u5899\u3011\u76F8\u5173\uFF0C\u7F51\u7EDC\u51FA\u5165
                              netsh Firewall show state
                                  \u4ECB\u7ECD\uFF1A
                                      \u67E5\u770B\u7CFB\u7EDF\u9632\u706B\u5899\u72B6\u6001

                                  \u7248\u672C\uFF1A
                                      \u8001\u7248\u672C\u53EF\u7528\uFF0C\u65B0\u7248\u672C\u5DF2\u88AB\u5F03\u7528

                              netsh advfirewall firewall
                                  \u4ECB\u7ECD\uFF1A
                                      \u65B0\u7248\u672C\u7684\u3002
                                  \u4F7F\u7528\uFF1A
                                      \uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F

                      \u7CFB\u7EDF\u914D\u7F6E
                          msconfig
                              \u5E38\u89C1\u9875\u9762\u3002

                      \u6CE8\u518C\u8868
                          \u7528\u6237\u4FE1\u606F
                                  HKEY_LOCAL_MACHINE\\SAM\\SAM\\Domains\\Account\\Users
                                      \u9ED8\u8BA4\uFF0C\u5728\u3010SAM\\SAM\u3011\uFF0C\u4F1A\u662F\u7A7A\u767D\uFF1A
                                          1.\u53F3\u952E\u70B9\u51FB\u3010\u6743\u9650\u3011\u2014\u2014\u9009\u62E9\u3010Administrators\u3011\u2014\u2014\u52FE\u9009\u3010\u5B8C\u5168\u63A7\u5236\u3011\u3002\u70B9\u51FB\u786E\u5B9A\u3002
                                          2.\u5173\u95ED\u5E76\u91CD\u65B0\u542F\u52A8\u3010\u6CE8\u518C\u8868\u3011\u3002
                                      \u8FDB\u5165\u3010Domains\\Account\\Users\\Names\u3011\uFF0C\u67E5\u770B\u6240\u6709\u7684\u7528\u6237\u540D\u3002

                                      \u6B64\u65F6\uFF0C\u8FD8\u53EF\u4EE5\u67E5\u627E\u3010\u514B\u9686\u7528\u6237\u3011\uFF1A
                                          \u5728\u6B64\u9879\u4E0B\u5BFC\u51FA\u6240\u6709\u4EE500000\u5F00\u5934\u7684\u9879\uFF0C
                                              \u5C06\u6240\u6709\u5BFC\u51FA\u7684\u9879\u4E0E000001F4\uFF08\u8BE5\u9879\u5BF9\u5E94Administrator\u7528\u6237\uFF09\u5BFC\u51FA\u5185\u5BB9\u505A\u6BD4\u8F83\uFF0C
                                                  \u82E5\u5176\u4E2D\u7684F\u503C\u76F8\u540C\uFF0C\u5219\u8868\u793A\u53EF\u80FD\u4E3A\u514B\u9686\u7528\u6237\u3002
                                          \u9644\u56FE\uFF1A\u89C1  https://res.weread.qq.com/wrepub/epub_35011077_20

                          \u542F\u52A8\u9879
                                  \u3010RUN\u3011\u76F8\u5173
                                      HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run
                                      HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce
                                      HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServices
                                      HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServicesOnce
                                      HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\Run
                                      //
                                      HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run
                                      HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce
                                      HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServices
                                      HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServicesOnce
                                      HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\Run
                                      //

                                  \u3010RunOnceEx\u3011\u76F8\u5173     \uFF08Windows XP/2003 \u7279\u6709\uFF09
                                      HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnceEx
                                      HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnceEx

                          load\u952E\u503C
                                  HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Windows

                          WinLogon\u952E\u503C
                                  HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Winlogon
                                  HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Winlogon

                          \u5176\u5B83\u3010Shell\u811A\u672C\u3011\u3001\u3010Script\u811A\u672C\u3011\u76F8\u5173
                                  HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\shell
                                  HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ShellServiceObjectDelayLoad
                                  HKEY_CURRENT_USER\\SOFTWARE\\Policies\\Microsoft\\Windows\\SystemScripts
                                  HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\\Scripts



                      \u8BA1\u5212\u4EFB\u52A1
                          \u3010compmgmt.msc\u3011\uFF0C\u542F\u52A8\u3010\u8BA1\u7B97\u673A\u7BA1\u7406\u3011
                                  \uFF08\u5168\u79F0\uFF1AComputerManagement\uFF09
                              \u8FDB\u5165\u3010\u7CFB\u7EDF\u5DE5\u5177\u3011\u2014\u2014\u3010\u4EFB\u52A1\u8BA1\u5212\u7A0B\u5E8F\u3011\u3002

                          \u4ECE\u3010PowerShell\u3011\u4E2D\u6267\u884C\uFF1A
                              \u3010Get-ScheduledTask\u3011\uFF0C\u5217\u4E3E\u51FA\u3010\u8BA1\u5212\u4EFB\u52A1\u9879\u3011\u5217\u8868\u3002

                          \u3010schtasks\u3011\u547D\u4EE4
                                  \uFF08\u5168\u79F0\uFF1AScheduleTasks\uFF09
                              \u5217\u4E3E\u51FA\u3010\u8BA1\u5212\u4EFB\u52A1\u9879\u3011\u5217\u8868\u3002
                                  \u7C7B\u4F3C\u4E8E\u3010Get-ScheduledTask\u3011\u547D\u4EE4\u4E00\u6837\u3002

                      \u7528\u6237\u548C\u7EC4
                          lusrmgr.msc
                                  \uFF08\u5168\u79F0\uFF1AlUserManager.microService\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF09
                              \u67E5\u770B\u3010\u672C\u5730\u7528\u6237\u548C\u7EC4\u3011

                      \u4E8B\u4EF6\u67E5\u770B\u5668
                          eventvwr.msc
                              \u8FD9\u4E2A\u6211\u7528\u8FC7\u7684\uFF0C\u5C31\u5728\u67E5\u3010\u5F02\u5E38\u91CD\u542F\u884C\u4E3A\u3011\u7684\u90A3\u4E00\u6BB5\u3002

                      \u670D\u52A1\u67E5\u770B\u3001\u670D\u52A1\u542F\u52A8\u548C\u505C\u6B62
                          services.msc


                      \u3010\u8FDB\u7A0B\u53C2\u6570\u3011\u7684\u5206\u6790
                          \u63D0\u53D6\u51FA\u3010\u8FDB\u7A0B\u540D\u3011\u548C\u3010\u8FDB\u7A0B\u542F\u52A8\u53C2\u6570\u3011\uFF0C\u5E76\u5BFC\u51FA\u5230\u3010tmp.txt\u3011\u6587\u4EF6
                              \u8D44\u6599\uFF1A
                                  \u4E00\u90E8\u5206\uFF0C\u89C1\u601D\u7EF4\u5BFC\u56FE
                                  \u53E6\u4E00\u4E9B\uFF1Ahttps://blog.csdn.net/swazer_z/article/details/60100596

                              \u547D\u4EE4\uFF1Awmic process get caption,commandline  /  value >> tmp.txt

                      \u540E\u95E8\u67E5\u770B
                          \u3010BitsAdmin\u3011\u540E\u95E8\u67E5\u770B
                              bitsadmin  /list  /allusers  /verbose
                                  \u663E\u793A\u51FA\u4E00\u4E9B\u3010Job\u3011\u4FE1\u606F\u3002

          `))},{os:E.Linux,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`
    \u7CFB\u7EDF\u4FE1\u606F
            \u57FA\u672C\u4FE1\u606F
                  uname   -a
                  cat     /proc/version
                  lsmod
                        \u5217\u4E3E\u6A21\u5757

            \u8FDB\u7A0B
                  top
                      \u5B9E\u65F6\u663E\u793A\u3010\u8FDB\u7A0Bprocess\u3011\u7684\u52A8\u6001\u3002
                  ps                    \uFF08\u5168\u79F0\uFF1AProcess Status\uFF09
                      ps  -ef
                          \uFF08ef\u662FSystem V\u98CE\u683C\uFF09
                      ps  -ef  |  grep  <\u8FDB\u7A0B\u5173\u952E\u5B57>
                      ps  -aux
                          \uFF08aux\u662FBSD\u98CE\u683C\uFF09
                  kill
                      kill  -9  <\u8FDB\u7A0BPID>
                          \u7ED3\u675F\u6307\u5B9A\u3010PID\u3011\u7684\u8FDB\u7A0B

                  free
                      \u67E5\u770B\u3010\u5185\u5B58\u5360\u7528\u3011\u60C5\u51B5\u3002
                          \u540C\u65F6\uFF0C\u5B8C\u5168\u7B49\u4EF7\u4E8E \u3010cat  /proc/meminfo\u3011\u3002
                              \u8FD9\u4E24\u8005\uFF0C\u672C\u8D28\u662F\u540C\u4E00\u4E2A\u3002

                  lsof
                      lsof  -i:<\u7AEF\u53E3\u53F7>
                          \u67E5\u770B\uFF0C\u3010\u7AEF\u53E3\u3011\u5BF9\u5E94\u7684\u3010\u7A0B\u5E8F\u3011\u3002
                              \uFF08-i\u540E\u9762\u5192\u53F7\uFF0C\u662F\u8FDE\u5728\u4E00\u8D77\u7684\uFF09
                      lsof  -p  <\u8FDB\u7A0BPID>
                          \u67E5\u770B\uFF0C\u3010\u5BF9\u5E94\u67D0\u4E00\u8FDB\u7A0B\u3011\u6240\u6253\u5F00\u7684\u3010\u4F7F\u7528\u4E2D\u6587\u4EF6\u3011\u5217\u8868\u4FE1\u606F\u3002

                  rpm
                      rpm  -Va
                          \u68C0\u6D4B\uFF0C\u3010\u5F53\u524D\u7CFB\u7EDF\u6587\u4EF6\u3011\uFF0C\u662F\u5426\u53D1\u751F\u53D8\u5316\u3001\u662F\u5426\u3010\u88AB\u7E82\u6539\u3011
                              \u5982\u679C\u4E00\u5207\u6821\u9A8C\u6B63\u5E38\uFF0C\u5219\u4E0D\u4F1A\u6709\u4EFB\u4F55\u8F93\u51FA

            \u670D\u52A1
                  chkconfig
                      chkconfig  --list
                          \u53EF\u67E5\u770B\u7CFB\u7EDF\u8FD0\u884C\u7684\u670D\u52A1\uFF0C\u6838\u67E5\u662F\u5426\u5B58\u5728\u5F02\u5E38\u670D\u52A1

            \u7528\u6237\u4FE1\u606F
                  useradd\u3001userdel
                  stat  <\u67D0\u4E2A\u6587\u4EF6\u6216\u76EE\u5F55>
                      \u67E5\u770B\u3010\u6587\u4EF6/inode\u3011\u65F6\u95F4\u53D8\u5316
                          Access\u8BBF\u95EE
                          Modify\u4FEE\u6539
                          Create\u521B\u5EFA
                          Change \uFF08\uFF1F\uFF1F\uFF1F\uFF09

                  cat     /etc/passwd
                      \u5206\u6790\u53EF\u7591\u8D26\u53F7\u3001\u5176\u5B83\u53EF\u767B\u5F55\u8D26\u53F7

                      \u4F7F\u7528\u4E3E\u4F8B\uFF1A
                          awk  -F:  '{if($3==0)print $1}'  /etc/passwd
                              \u67E5\u627E\u4E3A\u3010UID\u4E3A0\u3011\u7684\u7528\u6237\u3001\u7528\u6237\u7EC4\u3002
                                  \u5373\uFF0C\u662F\u5BF9\u5E94root\u6743\u9650\u7684\u7528\u6237\u3002

                          cat  /etc/passwd  |  grep  -E  '/bin/bash$'
                              \u7B5B\u9009\uFF0C\u4F7F\u7528\u4E86\u3010/bin/bash\u3011\u4E3AShell\uFF0C\u7684\u7528\u6237
                                  \u540C\u65F6\uFF0C\u4E5F\u610F\u5473\u7740\uFF0C\u662F\u53EF\u4EE5\u3010\u767B\u5F55\u3011\u7684\u8D26\u6237\u3002

                          cat  /etc/passwd  |  grep  -v  "nologin"  |  grep  -v  "false"
                              \u67E5\u770B\uFF0C\u80FD\u591F\u767B\u5F55\u7684\u7528\u6237
                              \u9009\u9879\u8BF4\u660E\uFF1A
                                  \u3010-v\u3011\uFF0C\u53CD\u9009
                                      \u9009\u51FA\uFF0C\u65E0\u3010nologin\u3011\u5E76\u4E14\uFF0C\u65E0\u3010false\u3011\u7684\u884C\u3002

                  cat     /etc/shadow
                        awk  -F:  'length($2)==0{print $1}'  /etc/shadow
                            \u53EF\u67E5\u770B\u662F\u5426\u5B58\u5728\u7A7A\u53E3\u4EE4\u8D26\u6237\u3002
                                \u5176\u5B9E\uFF0C\u662F\u67E5\u627E\u3010\u7B2C1\u4E2A\u5192\u53F7\u3011\u540E\u9762\u7684\u5185\u5BB9

            \u547D\u4EE4\u5386\u53F2history
                  \u547D\u4EE4\uFF1A
                      history
                          \u5B8C\u5168\u7B49\u4EF7\u4E8E\u3010cat  /root/.bash_history\u3011
                              \u4E24\u8005\uFF0C\u5B9E\u8D28\u4E0A\u662F\u4E00\u6837\u7684\u3002
                  \u5173\u6CE8\u8303\u56F4\uFF1A
                      wget    \u8FDC\u7A0B\u67D0\u4E3B\u673A\uFF08\u57DF\u540D&IP\uFF09  \u7684\u8FDC\u63A7\u6587\u4EF6\u3002
                      \u5C1D\u8BD5\u8FDE\u63A5 \u5185\u7F51\u67D0\u4E3B\u673A\uFF08ssh\u3001scp\uFF09
                      \u6253\u5305 \u67D0\u654F\u611F\u6570\u636E\u6216\u4EE3\u7801\uFF0Ctar\u3001zip \u4E4B\u7C7B\u547D\u4EE4
                      \u5BF9\u7CFB\u7EDF\u8FDB\u884C\u914D\u7F6E\uFF0C\u5305\u62EC \u547D\u4EE4\u4FEE\u6539\u3001\u8FDC\u63A7\u6728\u9A6C \u4E4B\u7C7B

            \u542F\u52A8\u9879
                    \u5E38\u89C4\u76EE\u5F55
                        /etc/rc[0-6].d
                            \u5176\u5B9E\u662F\u3010\u8F6F\u94FE\u63A5\u3011
                                \u76EE\u7684\u662F\u4FDD\u6301\u4E0EUNIX\u7CFB\u7EDF\u7684\u517C\u5BB9\u6027\u3002
                        /rc.d/rc[0-6].d
                            \u8BE5\u76EE\u5F55\u4E0B\uFF0C\u6240\u6709\u5BF9\u5E94\u7684\u3010\u542F\u52A8\u6587\u4EF6\u3011\uFF0C\u90FD\u662F\u3010\u8F6F\u94FE\u63A5\u3011
                            \u6587\u4EF6\u5F62\u5F0F\uFF1A\u3010\u5B57\u6BCDS/K\u3011+\u3010\u4E24\u4F4D\u6570\u5B57\u3011+\u3010\u7A0B\u5E8F\u540D\u3011
                            \u6307\u5411\uFF1A
                                \u4E0B\u65B9\u3010/etc/rc.d/init.d\u3011\u4E2D\u7684\u771F\u5B9E\u6587\u4EF6\u3002
                        /etc/rc.d/init.d/
                            \u5B58\u653E\u4E00\u4E9B\u811A\u672C
                            \u672C\u8D28\uFF1A
                                \u7C7B\u4F3C\u4E8E\u3010Windows\u3011\u7684\u3010\u6CE8\u518C\u8868\u3011
                        /etc/rc.d/rc.local
                            \u4F1A\u5728\u3010\u7528\u6237\u767B\u5F55\u3011\u4E4B\u524D\u8BFB\u53D6\uFF0C\u5728\u3010\u6BCF\u6B21\u7CFB\u7EDF\u542F\u52A8\u3011\u65F6\u6267\u884C\u4E00\u6B21\u3002

                    /etc/rc*
                    /etc/init.d/rc.local
                    /etc/rc.local
                    rc.local
                    /etc/init.d
                    /etc/rc.d/rc
                    /etc/init/*.conf
                    /etc/rc$runlevel.d

                    /etc/inittab
                    /etc/systemd/system
                    /etc/rc.d/local
                    /etc/rc.d/init.d



            \u8BA1\u5212\u4EFB\u52A1
                  crontab
                      crontab  -l
                          \u67E5\u770B\u5F53\u524D\u7684\u4EFB\u52A1\u8BA1\u5212
                      crontab  -u <\u5982root>  -l
                            \u67E5\u770B\u3010root\u7528\u6237\u3011\u4E0B\u7684\u8BA1\u5212\u4EFB\u52A1\uFF0C\u786E\u8BA4\u662F\u5426\u6709 \u3010\u540E\u95E8\u6728\u9A6C\u3011\u7A0B\u5E8F \u542F\u52A8\u7684\u76F8\u5173\u4FE1\u606F

                  etc\u76EE\u5F55\uFF0C\u8BA1\u5212\u4EFB\u52A1 \u76F8\u5173\u6587\u4EF6\uFF1A
                        /etc/cron.deny
                        /etc/crontab
                        /etc/cron.d
                        /etc/cron.daily
                        /etc/cron.hourly
                        /etc/cron.monthly
                        /etc/cron.weekly

                  /var/spool/cron
                        \u5B58\u653E\u6BCF\u4E2A\u7528\u6237\uFF0C\u5305\u62EC\u3010root\u7528\u6237\u3011\u7684 crontab \u4EFB\u52A1\u3002


            `))}]},{cmdType:"\u8FDB\u7A0B",items:[{os:E.Windows,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u3010\u8FDB\u7A0B\u3011\u6392\u67E5
                      \u2460 \u901A\u8FC7\u3010\u4EFB\u52A1\u7BA1\u7406\u5668\u3011\u6765\u770B
                      \u2461 tasklist\u547D\u4EE4
                              tasklist
                                  \u67E5\u770B\uFF0C\u5F53\u524D\u3010Windows\u7A0B\u5E8F\u4EFB\u52A1\u3011\u5217\u8868\u3002
                                      \uFF08\u5C31\u548C\u3010\u4EFB\u52A1\u7BA1\u7406\u5668\u3011\u4E00\u6837\uFF09
                              tasklist /svc
                                  \u67E5\u770B\uFF0C\u5F53\u524D\u3010Windows\u670D\u52A1\u3011
                                      \uFF08\u548C\u3010\u4EFB\u52A1\u7BA1\u7406\u5668\u3011\u7684\u3010\u670D\u52A1\u3011  \u4E5F\u7C7B\u4F3C\uFF09

                              tasklist /m
                                  \u67E5\u8BE2\u3010\u5404\u8FDB\u7A0B\u3011\u52A0\u8F7D\u7684\u3010DLL\u5E93\u3011\u4FE1\u606F\u3002
                                      \u5728\u6392\u67E5\u3010\u6076\u610F\u8FDB\u7A0B\u3011\u65F6\u5F88\u6709\u7528\uFF01

                      \u2462 netstat\u547D\u4EE4

                              netstat  -ano  |  findstr  ESTABLISHED
                                  \u67E5\u770B\uFF0C\u5F53\u524D\u3010\u5DF2\u5EFA\u7ACB\u3011\u7684\u7F51\u7EDC\u8FDE\u63A5\u3002

                      \u2463 \u4F7F\u7528PowerShell\uFF0C\u67E5\u770B\u3010\u8FDB\u7A0B\u3011
                              \u539F\u7406\uFF1A\u4E00\u822C\u662F\u3010\u8C03\u7528WMI\u5BF9\u8C61\u3011\u3002
                                  WMI\uFF0C\u539F\u6307\u3010Windows\u7BA1\u7406\u89C4\u8303\u3011\uFF0C\u53C8\u79F0\u4E3A\u3010Windows\u7CFB\u7EDF\u63D2\u4EF6\u3011\u3002
                              \u547D\u4EE4\uFF1A
                                  Get-WmiObject Win32_Process | select Name,ProcessId,ParentProcessId,Path

                      \u2464 wmic\u547D\u4EE4
                              \u89C1\u4E0A\u65B9\uFF0C\u3010\u8FDB\u7A0B\u53C2\u6570\u3011\u7684\u90E8\u5206\u3002

          `))},{os:E.Linux,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`
    \u8FDB\u7A0B
            netstat
                    \u7F51\u7EDC\u8FDE\u63A5\u547D\u4EE4\uFF0C\u663E\u793A\u3010\u7F51\u7EDC\u72B6\u6001\u3011

                    \u793A\u4F8B\uFF1A
                            netstat  -antlp
                                \u53EF\u67E5\u770B\u7F51\u7EDC\u8FDE\u63A5\u3001\u8FDB\u7A0B\u3001\u7AEF\u53E3\u53CA\u5BF9\u5E94\u7684PID\u7B49

                                \u66F4\u597D\u8BB0\u7684\uFF0C\u662F\u3010netstat  -altnp\u3011\uFF01\uFF01\uFF01


                            ls  -alh  /proc/<\u5177\u4F53pid\u8FDB\u7A0B\u53F7> | more
                                \u67E5\u770B\u3010\u8FDB\u7A0B\u3011\u5BF9\u5E94\u7684\u53EF\u6267\u884C\u7A0B\u5E8F

            rm  -rf  ./<\u6587\u4EF6\u540D>        \uFF0C\u7528\u6765\u5220\u9664\u6728\u9A6C
                    \u5982\u679C\u3010root\u7528\u6237\u3011\u65E0\u6CD5\u5220\u9664\uFF0C\u5219\u4F7F\u7528\u3010chattr\u3011\u547D\u4EE4\u79FB\u9664\u3010i\u5C5E\u6027\u3011\u3002

                    lsattr  ./<\u6587\u4EF6\u540D>
                            \u5217\u51FA\u6587\u4EF6\u5C5E\u6027\u3002
                    chattr
                            \u6539\u53D8\u6587\u4EF6\u5C5E\u6027\u3002

                            \u4E3E\u4F8B\uFF1A
                                    chattr  -i  ./<\u6587\u4EF6\u540D>
                                            \u79FB\u9664\u3010i\u5C5E\u6027\u3011\uFF08\u4ECE\u800C\u5728\u540E\u7EED\uFF0C\u80FD\u5220\u9664\u6587\u4EF6\uFF09\u3002

                                    chattr  +i  ./<\u6587\u4EF6\u540D>
                                            \u6B63\u597D\u4E0E\u3010-\u53F7\u3011\u76F8\u53CD\u3002

            \u5982\u679C\u5B58\u5728\u3010\u5B88\u62A4\u8FDB\u7A0B\u3011\u800C\u65E0\u6CD5\u3010\u6740\u6B7B\u8FDB\u7A0B\u3011\uFF0C\u5219\u8FDB\u884C\u4EE5\u4E0B\u64CD\u4F5C\uFF1A
                    \u2460 \u3010\u6302\u8D77\u3011\u5F53\u524D\u8FDB\u7A0B
                    \u2461 \u6740\u6B7B\u3010\u5B88\u62A4\u8FDB\u7A0B\u3011
                    \u2462 \u3010\u6740\u6B7B\u3011\u5F53\u524D\u8FDB\u7A0B
            `))}]},{cmdType:"\u6587\u4EF6\u75D5\u8FF9\u6392\u67E5",items:[{os:E.Windows,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u5728\u3010Linux\u547D\u4EE4\u76F8\u5173\u6A21\u5757\u3011\uFF0C\u4E5F\u8BB0\u8F7D\u4E86\u5F88\u591A\u5185\u5BB9\uFF01

              \u3010\u6587\u4EF6\u75D5\u8FF9\u3011\u6392\u67E5


                      \u654F\u611F\u76EE\u5F55
                          \u73AF\u5883\u53D8\u91CF
                              %WINDIR%
                              %WINDIR%\\system32
                              %TEMP%
                              %LOCALAPPDATA%
                              %APPDATA%



                      \u3010\u7279\u5B9A\u65F6\u95F4\u6BB5\u3011\u7684\u6587\u4EF6\u60C5\u51B5\uFF0C\u6392\u67E5
                          \uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F

                      \u540E\u95E8\u6587\u4EF6\u7684\u6392\u67E5
                          \uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F

                      \u5176\u5B83\u3010\u6587\u4EF6\u75D5\u8FF9\u3011

                          temp\u76F8\u5173\u76EE\u5F55

                          \u6D4F\u89C8\u5668\u8BB0\u5F55\u3001\u4E0B\u8F7D\u6587\u4EF6\u3001Cookie\u8BB0\u5F55

                          \u67E5\u770B\u3010\u6587\u4EF6\u65F6\u95F4\u6233\u3011
                              \u8D44\u6599\uFF1Ahttps://jingyan.baidu.com/article/454316ab004a2bf7a7c03a85.html

                              \u521B\u5EFA\u65F6\u95F4
                                  dir  <\u6587\u4EF6>  /t:c
                              \u4FEE\u6539\u65F6\u95F4
                                  dir  <\u6587\u4EF6>  /t:w
                              \u8BBF\u95EE\u65F6\u95F4
                                  dir  <\u6587\u4EF6>  /t:a

                          \u3010Recent\u6700\u8FD1\u6587\u4EF6\u3011\u8BB0\u5F55
                              C:\\Documents and Settings\\Administrator\\Recent
                              C:\\Documents and Settings\\Default User\\Recent
                              //
                              C:\\Users\\Administrator\\Recent
                              C:\\Users\\Default\\Recent

                          \u9884\u8BFB\u53D6\u6587\u4EF6
                              \u3010%SystemRoot%\\Prefetch\u3011\u76EE\u5F55\uFF0C
                                  \u67E5\u627E\u3010.pf\u540E\u7F00\u3011\u7684\u6587\u4EF6\u3002

                          \u6587\u4EF6\u67E5\u627E
                              \u6839\u636E\u3010\u6307\u5B9A\u65F6\u95F4\u6BB5\u3011\u3001\u3010\u6307\u5B9A\u76D8\u7B26\u3011\uFF0C\u7B49\u6761\u4EF6\uFF0C\u8FDB\u884C\u3010\u6587\u4EF6\u67E5\u627E\u3011\uFF1A
                                  forfiles  /m  *.exe  /d  +2022/6/9  /s  /p  c:  /c  "cmd  /c  echo  @path  @fdate  @ftime"  2>null
                                      \u6D4B\u8BD5\u53EF\u884C\uFF01
                                      \u9009\u9879\uFF1A
                                          \u3010c:\u3011\uFF0C\u662F\u76D8\u7B26 \u6216 \u76EE\u5F55\u8DEF\u5F84\u3002

          `))},{os:E.Linux,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

    \u6587\u4EF6\u75D5\u8FF9\u6392\u67E5
            \u65F6\u95F4\u70B9
                    find  <\u5177\u4F53\u8DEF\u5F84>    -name  <\u6587\u4EF6\u540D\u901A\u914D\u7B26>
                            -type   <b/d/c/p/l/f>
                                    \u3010b\u3011\uFF0C\u5757\u8BBE\u5907
                                    \u3010d\u3011\uFF0C\u76EE\u5F55
                                    \u3010c\u3011\uFF0C\u5B57\u7B26\u8BBE\u5907
                                    \u3010p\u3011\uFF0C\u7BA1\u9053
                                    \u3010l\u3011\uFF0C\u7B26\u53F7\u94FE\u63A5Link
                                    \u3010f\u3011\uFF0C\u666E\u901A\u6587\u4EF6
                            -mtime
                                    Modify\u4FEE\u6539
                            -atime
                                    Access\u8BBF\u95EE
                            -ctime
                                    Create\u521B\u5EFA

            \u7279\u6B8A\u6743\u9650\u6587\u4EF6
                    \u540C\u6837\u662F\u3010find\u3011
                            777\u6743\u9650
                                    find  /  -name  "*.jsp"  -perm  777
                                            \u3010-perm\u3011\uFF0C\u6743\u9650\u6807\u8BC6\u7B26
                            WebShell
                                    \u8D44\u6599\uFF1A
                                        http://www.ithov.net/linux/461
                                        https://blog.csdn.net/adparking/article/details/38702177

                                    \u968F\u4FBF\u4E3E\u51E0\u4F8B\uFF0C\u4ECE\u300A\u7F51\u7EDC\u5B89\u5168\u5E94\u6025\u54CD\u5E94\u6280\u672F\u5B9E\u6218\u6307\u5357\u300B\u4E2D\u6458\u6284\u7684\u8BED\u53E5\u3002
                                        find  /var/www/  -name  "*.php"  |  xargs  egrep  "eval"
                                        find  /var/www/  -name  "*.php"  |  xargs  egrep  "(phpspy|c99sh|milw0rm|eval(gzuncompress(base64_decoolcode|eval(base64_decoolcode|spider_bc|gzinflate)"
                                                \uFF08\u8FD9\u91CC\uFF0C\u4F5C\u8005\u53C8\u62FC\u5199\u9519\u4E86\u5173\u952E\u8BED\u53E5\uFF09


            \u7279\u6B8A\u6587\u4EF6
                    \u53BB\u3010\u547D\u4EE4\u76EE\u5F55/bin\u3011\uFF0C\u67E5\u770B\u3010\u76F8\u5173\u7CFB\u7EDF\u547D\u4EE4\u3011\u7684\u4FEE\u6539\u65F6\u95F4
                            ls  -alt   /bin/*
                                    \u6309\u7167\u3010\u4FEE\u6539\u65F6\u95F4\u3011\uFF0C\u8FDB\u884C\u6392\u5E8F\u3002
                            ls  -altr  /bin/*
                                    \u540C\u4E0A\uFF0C\u4E0D\u8FC7\u662F\u3010\u9006\u5E8F\u3011\u3002
                                            \u6700\u65B0\u7684\u6392\u6700\u540E\uFF0C\u8FD9\u79CD\u66F4\u597D\u7528\u4E00\u4E9B\u3002

            `))}]},{cmdType:"\u65E5\u5FD7\u5206\u6790",items:[{os:E.Windows,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u65E5\u5FD7\u5206\u6790

                  \u601D\u8DEF\u65B9\u6CD5\uFF1A
                          \u2460 \u4F7F\u7528\u3010\u5185\u7F6E\u3011\u7684\u3010\u65E5\u5FD7\u7B5B\u9009\u5668\u3011\u8FDB\u884C\u5206\u6790
                              \u5176\u5B9E\uFF0C\u4E5F\u5C31\u662F\u2014\u2014\u2014\u2014\u3010\u4E8B\u4EF6\u67E5\u770B\u5668\u3011
                                  \u524D\u9762\u5DF2\u7ECF\u8BF4\u8FC7\u4E86

                          \u2461 \u4F7F\u7528PowerShell\uFF0C\u8FDB\u884C\u3010\u65E5\u5FD7\u5206\u6790\u3011
                              Get-EventLog
                                  \u8D44\u6599\uFF1A
                                      https://zhuanlan.zhihu.com/p/112238200
                                      \u5176\u5B83\u90E8\u5206\u8D44\u6599\uFF1Ahttp://www.gimoo.net/t/1403/5416c89153a05.html
                                  \u547D\u4EE4\uFF1A
                                      Get-EventLog  -List
                                      Get-EventLog  -LogName  System

                              Get-WinEvent
                                  \u8D44\u6599\uFF1A
                                      \u4E0D\u592A\u8BE6\u7EC6\uFF1Ahttps://jingyan.baidu.com/article/fc07f989a295da12ffe519bb.html

                                  \u547D\u4EE4\uFF1A
                                      Get-WinEvent  -listlog  *

                          \u2462 \u4F7F\u7528\u3010\u76F8\u5173\u65E5\u5FD7\u5DE5\u5177\u3011\uFF0C\u8FDB\u884C\u5206\u6790\u67E5\u8BE2
                              \uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F
                                  \u90FD\u662F\u5DF2\u7ECF\u8BF4\u8FC7\u7684\uFF0C\u90A3\u4E9B\u5DE5\u5177\u4E86\u5417\uFF1F

                  \u5B89\u5168\u65E5\u5FD7\u7C7B\u578B\uFF1A
                          2       \u4EA4\u4E92\u5F0F\u767B\u5F55
                          3       \u7F51\u7EDC
                          4       \u6279\u5904\u7406
                          5       \u670D\u52A1\u542F\u52A8
                          7       \u89E3\u9501
                          8       \u7F51\u7EDC\u660E\u6587
                          10      \u8FDC\u7A0B\u4EA4\u4E92
                          11      \u7F13\u5B58\u57DF\u8BC1\u4E66\u767B\u5F55

                          \u7591\u4F3C\u3010\u8FDC\u7A0B\u684C\u9762\u4F1A\u8BDD\u3011\u7684\u3010\u4E8B\u4EF6ID\u3011
                              21    \u8FDC\u7A0B\u684C\u9762\u4F1A\u8BDD\uFF0C\u767B\u5F55\u6210\u529F
                              24    \u8FDC\u7A0B\u684C\u9762\u4F1A\u8BDD\uFF0C\u65AD\u5F00\u8FDE\u63A5
                              25    \u8FDC\u7A0B\u684C\u9762\u4F1A\u8BDD\uFF0C\u91CD\u65B0\u8FDE\u63A5\u6210\u529F


                  \u5176\u5B83\u76EE\u5F55
                          %SystemRoot%\\System32\\Winevt\\Logs
                              \u5B58\u5728\u5927\u91CF\u5176\u4ED6\u65E5\u5FD7
                                  \u4F8B\u5982\uFF0C\u8FDC\u7A0B\u684C\u9762\u4F1A\u8BDD\u65E5\u5FD7\u4F1A\u8BB0\u5F55\u901A\u8FC7RDP\u767B\u5F55\u7684\u4FE1\u606F\uFF0C\u5305\u542B\u767B\u5F55\u6E90\u7F51\u7EDC\u5730\u5740\u3001\u767B\u5F55\u7528\u6237\u7B49

          `))},{os:E.Linux,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

    \u65E5\u5FD7\u5206\u6790
            Linux\u4E0B\u65E5\u5FD7\uFF0C\u6240\u5728\u4F4D\u7F6E
                    \u4E00\u822C\u653E\u5728\u3010/var/log\u3011\u4E4B\u4E0B\uFF1A

                            boot.log
                            messages
                            maillog
                            bash_history

                            /var/log/btmp

                            /var/log/wtmp
                                \u767B\u5F55\u8FDB\u5165\u3001\u9000\u51FA
                                \u6570\u636E\u4EA4\u6362\u3001\u5173\u673A\u548C\u91CD\u542F
                                    \u662F\u3010last\u547D\u4EE4\u3011\u7684\u5B9E\u8D28
                            /var/log/lastlog
                                \u8BB0\u5F55\u4E86\uFF0C\u7528\u6237\u6700\u540E\u767B\u5F55\u4FE1\u606F
                                    \u662F\u3010lastlog\u547D\u4EE4\u3011\u7684\u5B9E\u8D28
                            /var/log/secure
                                \u8BB0\u5F55\uFF0C\u767B\u5165\u7CFB\u7EDF\u3001\u5B58\u53D6\u6570\u636E\u7684\u6587\u4EF6
                                \u6BD4\u5982\uFF1A
                                    pop3
                                    ssh
                                    telnet
                                    ftp
                                    \u7B49\u7B49
                            /var/log/cron
                                \u4E0E\u3010\u5B9A\u65F6\u4EFB\u52A1\u3011\u76F8\u5173\u7684\u65E5\u5FD7\u4FE1\u606F
                                    123
                                \u8BB0\u5F55\u3010crontab\u547D\u4EE4\u3011\uFF0C\u662F\u5426\u6B63\u786E\u6267\u884C
                                    123
                            /var/log/message
                                \u7CFB\u7EDF\u542F\u52A8\u540E\uFF0C\u4FE1\u606F\u548C\u9519\u8BEF\u65E5\u5FD7
                                    123
                            /var/log/apache2/access.log
                                \u3010Apache\u3011\u7684\u8BBF\u95EE\u65E5\u5FD7\u3002
                            /var/log/auth.log
                                \u5305\u542B \u7CFB\u7EDF\u6388\u6743\u4FE1\u606F\uFF0C\u5305\u62EC \u7528\u6237\u767B\u5F55\u548C\u4F7F\u7528 \u7684\u6743\u9650\u673A\u5236\u3002
                            /var/log/userlog
                                \u8BB0\u5F55\u3010\u6240\u6709\u7B49\u7EA7\u7528\u6237\u4FE1\u606F\u3011\u7684\u65E5\u5FD7\u3002
                            /var/log/xferlog
                                    \uFF08\u4EE5\u53CA\u3010vsftpd.log\u3011\u6587\u4EF6\u3002\uFF09
                                \u8BB0\u5F55\u3010Linux FTP\u3011\u65E5\u5FD7\u3002
                            /var/log/faillog
                                \u8BB0\u5F55 \u767B\u5F55\u7CFB\u7EDF\u4E0D\u6210\u529F \u7684\u8D26\u53F7\u4FE1\u606F\u3002
                    \u7ECF\u5178\u9AD8\u9891\u65E5\u5FD7
                            Secure\u65E5\u5FD7
                            history\u65E5\u5FD7
                            last\u65E5\u5FD7
                            audit\u65E5\u5FD7

            \u5E38\u7528\u65B9\u6CD5
                \u6587\u672C\u547D\u4EE4\uFF1A
                    \u7EFC\u5408\u4F7F\u7528\uFF0C\u4EE5\u4E0B\u547D\u4EE4
                        grep
                        sed
                        sort
                        awk
                \u767B\u5F55\u65E5\u5FD7
                    \u57FA\u4E8E\u65F6\u95F4
                        /var/log/wtmp
                        /var/run/utmp
                            \uFF1F\uFF1F\uFF1F
                        /var/log/lastlog
                            \u3010lastlog\u547D\u4EE4\u3011\u76F8\u5173
                            \uFF08\u767B\u5F55\u6210\u529F\uFF09\u76F8\u5173
                        /var/log/btmp
                            \u3010lastb\u547D\u4EE4\u3011\u76F8\u5173
                            \uFF08\u767B\u5F55\u5931\u8D25\uFF09\u76F8\u5173

                    \u57FA\u4E8E\u5173\u952E\u5B57
                        \u3010Accepted\u3011
                        \u3010Failed password\u3011
                        \u3010invalid\u3011

                    \u67E5\u767B\u5F55\u7684\u53E6\u4E00\u4E9B\u547D\u4EE4
                        last
                            \u5F53\u524D\u548C\u8FC7\u53BB\uFF0C\u3010\u767B\u5F55\u7CFB\u7EDF\u7528\u6237\u3011\u7684\u76F8\u5173\u4FE1\u606F

                            last  -f  /var/run/utmp
                                \u53EF\u67E5\u770B\u3010utmp\u3011\u6587\u4EF6\u4E2D\uFF0C\u4FDD\u5B58\u7684\u5F53\u524D\u6B63\u5728\u672C\u7CFB\u7EDF\u4E2D\u7684\u7528\u6237\u7684\u4FE1\u606F\uFF0C\u5E76\u67E5\u770B\u7528\u6237\u662F\u5426\u53EF\u7591

                        lastlog
                            \u6BCF\u4E2A\u3010\u7CFB\u7EDF\u7528\u6237\u3011\uFF0C\u6700\u8FD1\u4E00\u6B21\u767B\u9646\u7CFB\u7EDF\u7684\u65F6\u95F4\u3002
                        lastb
                            \u5217\u51FA \u3010\u767B\u5165\u7CFB\u7EDF\u5931\u8D25\u3011 \u7684\u7528\u6237\u76F8\u5173\u4FE1\u606F\u3002
                        who
                            \u663E\u793A\u7CFB\u7EDF\u4E2D\u6709\u54EA\u4E9B\u4F7F\u7528\u8005\u6B63\u5728\u4E0A\u9762
                        w
                            \u663E\u793A\u76EE\u524D\u767B\u5165\u7CFB\u7EDF\u7684\u7528\u6237\u4FE1\u606F\u3002
                        users
                            \u7528\u4E8E\u663E\u793A\u5F53\u524D\u767B\u5F55\u5230\u5F53\u524D\u4E3B\u673A\u7684\u7528\u6237\u7684\u7528\u6237\u540D\u3002
                        finger
                            \u67E5\u8BE2\u4E00\u4E9B\u5176\u4ED6\u4F7F\u7528\u8005\u7684\u8D44\u6599\u3002

            \u67E5\u627E\u8BED\u53E5
                \u5B9A\u4F4D\uFF0C\u5F53\u524D\u6B63\u5728\u3010\u7206\u7834\u4E3B\u673Aroot\u8D26\u53F7\u3011\u7684\u3010IP\u4FE1\u606F\u3011\u5217\u8868\uFF1A
                    \u8D44\u6599\uFF1A
                        \u539F\u601D\u7EF4\u5BFC\u56FE
                        \u5176\u5B83\u8D44\u6599\uFF1Ahttps://cloud.tencent.com/developer/article/1779284

                    cat  /var/log/secure | awk '/Failed/{print $(NF-3)}'|  sort | uniq -c | awk '{print $2"="$1;}'
                        123
                    grep "Failed pass" /var/log/secure|awk '{print $13}'|egrep '[0-8]+\\.'|sort |uniq -c
                        \u67E5\u627E\u54EA\u4E9BIP\u5B58\u5728\u767B\u5F55\u5931\u8D25\uFF08\u5927\u6982\u7387\u4E3A\u66B4\u529B\u7834\u89E3\u7684\uFF09
                    grep "Failed pass" /var/log/secure|egrep invalid|awk '{print $11}'|sort |uniq -c
                        \u67E5\u627E\u66B4\u529B\u7834\u89E3\u7684\u7528\u6237\u548C\u8BCD\u5178\uFF08\u5373\u5BFB\u627E\u66B4\u529B\u7834\u89E3\u8FC7\u7A0B\u4E2D\u767B\u5F55\u5931\u8D25\u7684\u7528\u6237\u540D\uFF09\uFF1A
                    grep "Accept" /var/log/secure|awk '{print $9" "$11}'|sort|uniq -c
                        \u67E5\u627E\u767B\u5F55\u6210\u529F\u7684\u7528\u6237IP\uFF1A
                    grep "Failed password for root" /var/log/secure | awk '{print $11}' | sort | uniq -c | sort -nr| more
                        \u5B9A\u4F4D\u6709\u591A\u5C11IP\u5728\u7206\u7834\u4E3B\u673A\u7684root\u5E10\u53F7\uFF1A
                    grep "Failed password" /var/log/secure|grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|uniq -c
                        \u5B9A\u4F4D\u6709\u54EA\u4E9BIP\u5728\u7206\u7834\uFF1A
                    grep "Failed password" /var/log/secure|perl -e 'while($_=<>){ /for(.*?) from/; print  "$1\\n";}'|uniq -c|sort -nr
                        \u7206\u7834\u7528\u6237\u540D\u8BCD\u5178\u662F\u4EC0\u4E48\uFF1F
                    grep "Accepted " /var/log/secure | awk '{print $11}' | sort | uniq -c | sort -nr | more
                        \u767B\u5F55\u6210\u529F\u7684IP\u6709\u54EA\u4E9B\uFF1A
                    grep "Accepted " /var/log/secure | awk '{print $1,$2,$3,$9,$11}'
                        \u767B\u5F55\u6210\u529F\u7684\u65E5\u671F\u3001\u7528\u6237\u540D\u3001IP\uFF1A



            \u7EDF\u8BA1\u67E5\u8BE2\u8BED\u53E5
                \u5BF9\u3010access_log\u3011\u5904\u7406\uFF1A      \uFF08\u4E00\u822C\u662F\u3010Nginx\u670D\u52A1\u5668\u3011\u7684\u6587\u4EF6\uFF09
                    \u67E5\u770BIP
                        cat  access_log  |  awk  '{print $1}'
                            \uFF08$1\u4EE3\u8868IP\uFF09
                    \u5BF9IP\u6392\u5E8F
                        cat  access_log  |  awk  '{print $1}'  |  sort
                    \u5BF9IP\u6392\u5E8F\uFF0C\u6253\u5370\u3010\u6BCF\u4E00\u4E2A\u91CD\u590D\u51FA\u73B0\u3011\u7684\u6B21\u6570\uFF0C\u3010uniq -c\u3011\u8868\u793A \u7EDF\u8BA1\u51FA\u3010\u91CD\u590D\u7684\u503C\u3011
                        cat  access_log  |  awk  '{print $1}'  |  sort  |  uniq  -c
                    \u6392\u5E8F\uFF0C\u5E76\u7EDF\u8BA1\u884C\u6570
                        cat  access_log  |  awk  '{print $1}'  |  sort  |  uniq  -c  |  sort  -rn  |  wc  -l
                    \u663E\u793A\uFF0C\u3010\u8BBF\u95EE\u524D10\u4F4D\u3011\u7684\u3010IP\u5730\u5740\u3011\uFF0C\u5E76\u67E5\u627E\u653B\u51FB\u6E90
                        cat  access_log  |  awk  '{print $1}'  |  sort  |  uniq  -c  |  sort  -rn  |  head  -10

                        \uFF08\u4F5C\u8005\uFF0C\u5728\u8FD9\u540E\u9762\uFF0C\u53C8\u591A\u91CD\u590D\u4E86\u4E00\u6B21\uFF09

                    \u663E\u793A\u3010\u6307\u5B9A\u4E8B\u4EF6\u3011\u4E4B\u540E\u7684\u65E5\u5FD7
                        cat  access_log  |  awk  '$4>="[21/Jul/2020:00:03:00]"'  access_log
                            \uFF08\u3010$4\u3011\u8868\u793A\u65F6\u95F4\uFF09
                    \u627E\u51FA\u3010\u8BBF\u95EE\u91CF\u6700\u5927\u7684IP\u3011\uFF0C\u5E76\u4F7F\u7528\u3010iptables\u3011\u5C01\u7981\u6389
                        cat  access_log  |  awk  '{print $1}'  |  sort  |  uniq  -c  |  sort  -rn  |  more
                        iptables  -l  INPUT  -s  <IP\u5730\u5740_\u53EF\u5E26\u7F51\u6BB5>  -j  DROP
                            \uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F
                    \u88AB\u4E0B\u8F7D\u3010Top10\u3011\u7684exe\u6587\u4EF6
                        cat  access_log  |  awk  '($7~/.exe){print $10 "" $1 "" $4 "" $7}'  |  sort  -n  |  uniq  -c  |  sort  -rn  |  head  -10
                    \u7B80\u5355\u7EDF\u8BA1\u6D41\u91CF
                        cat  access_log  |  awk  '{sum+=10}'

                    \u7EDF\u8BA1\u3010401\u8BBF\u95EE\u62D2\u7EDD\u3011\u6570\u91CF\uFF0C\u4FBF\u4E8E\u67E5\u627E \u53EF\u7591IP
                        cat  access_log  |  awk  '(/401/)'  |  wc  -l

                    \u7EDF\u8BA1\u6240\u6709\u72B6\u6001\u4FE1\u606F
                        cat  access_log  |  awk  '{print $9}'  |  sort  |  uniq  -cc  |  sort  -rn
                            \uFF08\u3010uniq  -cc\u3011\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F  \u662F\u4E0D\u662F\u5199\u9519\u4E86\uFF1F\uFF09

                    \u67E5\u770B\u3010\u67D0\u4E00\u65F6\u95F4\u5185\u3011\uFF0C\u7684\u3010IP\u94FE\u63A5\u3011\u60C5\u51B5
                        grep  "2020:06"  access_log  |  awk  '{print $4}'  |  sort  |  uniq  -c  |  sort  -rn



            `))}]},{cmdType:"\u5185\u5B58\u5206\u6790",items:[{os:E.Windows,content_item:u.a.createElement(u.a.Fragment,null)},{os:E.Linux,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

    \u5185\u5B58\u5206\u6790
            \u5185\u5B58\u7684\u83B7\u53D6\u65B9\u6CD5
                \u2460 \u3010\u7528\u6237\u6A21\u5F0F\u7A0B\u5E8F\u3011
                \u2461 \u3010\u5185\u6838\u6A21\u5F0F\u7A0B\u5E8F\u3011
                    \u8FD9\u79CD\u83B7\u53D6\u65B9\u6CD5\u4E00\u822C\u9700\u8981\u501F\u52A9\u76F8\u5173\u7684\u5DE5\u5177\u6765\u5B8C\u6210\u3002\u5E38\u7528\u7684\u63D0\u53D6\u5DE5\u5177\u6709Dumpit\u3001Redline\u3001RAMCapturer\u3001FTK Imager\u7B49\u3002
                \u2462 \u3010\u7CFB\u7EDF\u5D29\u6E83\u8F6C\u50A8\u3011
                    \u6253\u5F00\u3010\u7CFB\u7EDF\u5C5E\u6027\u3011\u5BF9\u8BDD\u6846\uFF0C\u9009\u62E9\u3010\u9AD8\u7EA7\u3011\u9009\u9879\u5361\uFF0C\u5355\u51FB\u3010\u542F\u52A8\u548C\u6545\u969C\u6062\u590D\u3011\u4E2D\u7684\u3010\u8BBE\u7F6E\u3011\u6309\u94AE\uFF0C\u6253\u5F00\u3010\u542F\u52A8\u548C\u6545\u969C\u6062\u590D\u3011\u5BF9\u8BDD\u6846\uFF0C\u9009\u62E9\u3010\u6838\u5FC3\u5185\u5B58\u8F6C\u50A8\u3011\u5E76\u627E\u5230\u8F6C\u50A8\u6587\u4EF6\u8FDB\u884C\u83B7\u53D6\u3002
                \u2463 \u3010\u64CD\u4F5C\u7CFB\u7EDF\u6CE8\u5165\u3011
                \u2464 \u3010\u7CFB\u7EDF\u4F11\u7720\u6587\u4EF6\u3011
                \u2465 \u3010\u865A\u62DF\u5316\u5FEB\u7167\u3011
                    \u8FD9\u79CD\u83B7\u53D6\u65B9\u6CD5\u662F\u901A\u8FC7VMware Workstation\u3001ESXI\u7B49\u865A\u62DF\u5316\u8F6F\u4EF6\u5B9E\u73B0\u7684\u3002
                \u2466 \u3010\u7CFB\u7EDF\u51B7\u542F\u52A8\u3011
                \u2467 \u3010\u786C\u4EF6\u3011


            \u5DE5\u5177
                \u3010\u5185\u5B58\u83B7\u53D6\u3011\u7684\u5DE5\u5177\uFF1A
                    RamCapture
                        \uFF1F\uFF1F\uFF1F
                    FTK Imager
                        \uFF1F\uFF1F\uFF1F

                \u5BFC\u5165\u5206\u6790
                    ReadLine
                        \uFF1F\uFF1F\uFF1F

                \u5185\u5B58\u53D6\u8BC1
                    Volatility

                    \u5B50\u529F\u80FD

                        \u6392\u67E5\u3010\u9690\u85CF\u8FDB\u7A0B\u3011
                            PsxView
                                \uFF1F\uFF1F\uFF1F

                        \u67E5\u627E\u3010\u9690\u85CF/\u6CE8\u5165\u3011\u7684\u3010\u4EE3\u7801/DLL\u3011
                            MalFind
                                \uFF1F\uFF1F\uFF1F
                        \u63D0\u53D6\u3010\u8FDB\u7A0B\u6587\u4EF6\u3011
                            ProcDump


            `))}]},{cmdType:"\u5176\u5B83\u96F6\u6563\u7684\u547D\u4EE4",items:[{os:E.Windows,content_item:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

          findstr
              \u7C7B\u4F3C\u4E8E\u3010Linux\u3011\u7684\u3010grep\u3011

          attrib
              \u8D44\u6599\uFF1Ahttps://blog.csdn.net/bytxl/article/details/49641093
              \u4ECB\u7ECD\uFF1A
                  \u7528\u4E8E\u4FEE\u6539\u6587\u4EF6\u7684\u5C5E\u6027\u3002
                      \u6587\u4EF6\u7684\u5E38\u89C1\u5C5E\u6027\u6709\uFF1A\u53EA\u8BFB\u3001\u5B58\u6863\u3001\u9690\u85CF\u3001\u7CFB\u7EDF\u3002
              \u547D\u4EE4\uFF1A
                  attrib  <\u6587\u4EF6\u8DEF\u5F84>
                      \u67E5\u770B\u3010\u6587\u4EF6\u3011\u7684\u5C5E\u6027
                  attrib  -R  <\u6587\u4EF6\u8DEF\u5F84>
                      \u53BB\u9664\u3010\u6587\u4EF6\u3011\u7684\u3010\u53EA\u8BFB\u3011\u5C5E\u6027
                  attrib  +H  <\u6587\u4EF6\u8DEF\u5F84>
                      \u589E\u52A0\u3010\u6587\u4EF6\u3011\u7684\u3010\u9690\u85CF\u3011\u5C5E\u6027
                  attrib  -H  <\u6587\u4EF6\u8DEF\u5F84>
                      \u53BB\u9664\u3010\u6587\u4EF6\u3011\u7684\u3010\u9690\u85CF\u3011\u5C5E\u6027

          \u5176\u5B83\u3010Windows\u3011\u5185\u7F6E\u7684\u3010\u5E38\u7528\u547D\u4EE4\u884C\u5DE5\u5177\u3011
              winver
                  \u68C0\u67E5Windows\u7248\u672C
              dxdiag
                  \u68C0\u67E5\u3010DirectX\u3011\u663E\u5361\u9A71\u52A8\u4FE1\u606F
              mem.exe
                  \u663E\u793A\u3010\u5185\u5B58\u4F7F\u7528\u3011\u60C5\u51B5
              Sndvol32
                      \uFF08\u5168\u79F0\uFF1ASoundVolume32\uFF09
                  \u97F3\u91CF\u63A7\u5236\u7A0B\u5E8F
              sfc.exe
                      \uFF08\u5168\u79F0\uFF1ASystemFileChecker\uFF09
                  \u7CFB\u7EDF\u6587\u4EF6\u68C0\u67E5\u5668
              gpedit.msc
                      \uFF08\u5168\u79F0\uFF1AGroupPolicyEdit\uFF09
                  \u7EC4\u7B56\u7565
              regedit.exe
                  \u6CE8\u518C\u8868
              Msconfig.exe
                  \u4E4B\u524D\u63D0\u5230\u8FC7\u4E86
              cmd.exe
                  123
              chkdsk.exe
                      \uFF08\u5168\u79F0\uFF1ACheckDisk\uFF09
                  \u78C1\u76D8\u68C0\u67E5
              lusrmgr.msc
                  \u4E4B\u524D\u63D0\u5230\u8FC7\u4E86
              drwtsn32
                      \uFF08\u5168\u79F0\uFF1ADr.Watson Post-Mortem Debugger\uFF09
                  \u7CFB\u7EDF\u533B\u751F
              cleanmgr
                  \u78C1\u76D8\u6E05\u7406\u5DE5\u5177
              iexpress
                  \u521B\u5EFA\u4E00\u4E2A\u3010\u81EA\u89E3\u538B/\u81EA\u5B89\u88C5\u7A0B\u5E8F\u3011\u3002
                  \u5371\u5BB3\uFF1A
                      \u5E38\u88AB\u3010\u6728\u9A6C\u3011\u6346\u7ED1\u5728\u4E00\u8D77\u3002
              mmc
                  \u5FAE\u8F6F\u7684\u3010\u7BA1\u7406\u63A7\u5236\u53F0\u3011
              DCPromo
                  \u4ECB\u7ECD\uFF1A
                      \u662F\u3010\u57DF\u63A7\u5236\u5668\u3011\u7684\u3010\u542F\u52A8\u5668\u3011
                      \u662F\u3010Active Directory\u3011\u7684\u4E00\u4E2A\u5DE5\u5177\u3002
                  \u7528\u9014\uFF1A
                      \u5B89\u88C5\u548C\u5220\u9664\uFF0CActive Directory \u57DF\u670D\u52A1\uFF1B
                      \u5E76\u53EF\u4EE5\u63D0\u5347\u3010\u57DF\u63A7\u5236\u5668\u3011\u3002
              ntbackup
                      \uFF08\u5168\u79F0\uFF1ANT Backup\uFF09
                          \uFF08\u5168\u79F0\uFF1ANT\u2014\u2014\u2014\u2014New Technology\uFF09
                  \u7CFB\u7EDF\u5907\u4EFD\u548C\u8FD8\u539F\uFF0C\u5DE5\u5177

              \u3010rononce -p\u3011
                  \u975E\u5E38\u53E4\u8001\u7684\u4E00\u4E2A\u547D\u4EE4\u3002\u662F15\u79D2\u540E\u5173\u673A\u3002

              taskmgr
                  \u4EFB\u52A1\u7BA1\u7406\u5668\uFF08\u7ECF\u5E38\u7528\u7684\u90A3\u4E2A\uFF09

              conf netmeeting
                  \u5F88\u4E45\u4EE5\u524D\u7248\u672C\u7684\uFF0C\u7F51\u7EDC\u4F1A\u8BAE\u7A0B\u5E8F\u3002\u73B0\u5728\u5DF2\u505C\u7528

              devmgmt.msc
                      \uFF08\u5168\u79F0\uFF1ADeviceManagement\uFF09
                  \u8BBE\u5907\u7BA1\u7406\u5668

              diskmgmt.msc
                  \u78C1\u76D8\u7BA1\u7406\u5668

              compmgmt.msc
                  \u4E4B\u524D\u63D0\u5230\u8FC7\u4E86

              winchat
                  \u5F88\u4E45\u4EE5\u524D\u7248\u672C\u7684\uFF0C\u804A\u5929\u901A\u8BAF\u7A0B\u5E8F\u3002\u73B0\u5728\u5DF2\u505C\u7528

              dvdplay
                  \u6253\u5F00\u3010Windows Media Player\u3011\u3002

              mplayer
                  \u7B80\u6613\u7248\u7684\u3010dvdplayer\u3011\u3002
                      \u73B0\u5728\u4F3C\u4E4E\u5DF2\u4E0D\u53EF\u7528\u3002

              mspaint
                  \u5185\u7F6E\u3010\u7ED8\u56FE\u3011\u7A0B\u5E8F

              nslookup
                      \uFF08\u5168\u79F0\uFF1ANameServer Lookup\uFF09
                  \u7528\u9014
                      \u8FDB\u884C\u3010\u68C0\u67E5\u57DF\u540D\u89E3\u6790\u3011\uFF1B
                      \u6216\u8005\u7528\u6765\u3010\u68C0\u6D4BDNS\u95EE\u9898\u3011\u3002

                  nslookup  <\u57DF\u540D>
                      \u5C06\u8FD4\u56DE\uFF0C\u81EA\u5DF1\u5F53\u524D\u6240\u4F7F\u7528\u7684\u3010DNS\u670D\u52A1\u5668\u3011\u7684\u3010IP\u5730\u5740\u3011\u3002

              syskey
                  Windows\u7684\u5185\u7F6E\u5BC6\u94A5\u52A0\u5BC6\u3002
                      \u73B0\u5728\u4F3C\u4E4E\u5DF2\u4E0D\u53EF\u7528\u3002

              wupdmgr
                  Windows\u81EA\u52A8\u66F4\u65B0\u7684\u5347\u7EA7\u7A0B\u5E8F\u3002
                      \u65B0\u7248\u672C\u4F3C\u4E4E\u6539\u4E86\u540D\u5B57

              clipbrd
                  \u526A\u8D34\u677F\u67E5\u770B\u5668
                      \u73B0\u5728\u4F3C\u4E4E\u5DF2\u4E0D\u53EF\u7528\u3002

              Odbcad32
                  \u5185\u7F6E\u7684\u3010ODBC\u6570\u636E\u6E90\u7BA1\u7406\u7A0B\u5E8F\u3011


      `))},{os:E.Linux,content_item:u.a.createElement(u.a.Fragment,null)}]}],P=function(){function t(){Object(T.a)(this,t)}return Object(R.a)(t,null,[{key:"\u5148\u64CD\u4F5C\u7CFB\u7EDF____\u518D\u547D\u4EE4\u5206\u7C7B",value:function(){var m=w.reduce(function(B,C,A){var D=C.items,a=C.cmdType;return D.forEach(function(i){var s=i.os,g=i.content_item;if(B[s]||(B[s]={}),B[s][a])throw new Error("\u6B64\u5904\uFF0C\u660E\u663E\u5B9A\u4E49\u91CD\u590D\u4E86\uFF01\u8BF7\u68C0\u67E5");B[s][a]={cmdType:a,item:g}}),B},{});return Object.entries(m).map(function(B){var C=Object(r.a)(B,2),A=C[0],D=C[1];return{name:A,steps:Object.entries(D).map(function(a){var i=Object(r.a)(a,2),s=i[0],g=i[1];return{name:"".concat(s,"  (").concat(A,")"),content:g.item}})}})}},{key:"\u5148\u547D\u4EE4\u5206\u7C7B____\u518D\u64CD\u4F5C\u7CFB\u7EDF",value:function(){var m=w.reduce(function(B,C,A){var D=C.cmdType;return B[D]||(B[D]=C.items),B},{});return Object.entries(m).map(function(B){var C=Object(r.a)(B,2),A=C[0],D=C[1];return{name:A,steps:D.map(function(a){return{name:"".concat(A,"  (").concat(a.os,")"),content:a.content_item}})}})}}]),t}(),x=_.l.singleATag_blank,e={\u57FA\u672C\u77E5\u8BC6:u.a.createElement(c.a,{type:"success",showIcon:!0,message:"\u57FA\u672C\u77E5\u8BC6",description:" "}),\u5DE5\u5177\u51C6\u5907:u.a.createElement(c.a,{type:"info",showIcon:!0,message:"\u5DE5\u5177\u51C6\u5907",description:" "}),\u5B9E\u6218\u89E3\u6790:u.a.createElement(c.a,{type:"warning",showIcon:!0,closable:!1,message:"\u5B9E\u6218\u89E3\u6790",description:" "})},f=[{name:"\u57FA\u672C\u4ECB\u7ECD",desc:u.a.createElement(u.a.Fragment,null,e.\u57FA\u672C\u77E5\u8BC6),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u53C2\u8003\u8D44\u6599\uFF1A
                      \u601D\u7EF4\u5BFC\u56FE\uFF1Ahttps://github.com/mrknow001/Mind_Map/blob/main/%E5%BA%94%E6%80%A5%E5%93%8D%E5%BA%94/%E5%BA%94%E6%80%A5%E5%93%8D%E5%BA%94%E6%80%BB%E7%BB%93%E6%80%9D%E7%BB%B4%E5%AF%BC%E5%9B%BE.png

                      \u76F8\u5173\u4E66\u7C4D\uFF1A
                          \u300A\u7F51\u7EDC\u5B89\u5168\u5E94\u6025\u54CD\u5E94\u6280\u672F\u5B9E\u6218\u6307\u5357\u300B
                              \u5DF2\u7ECF\u83B7\u53D6\u5230
                          \u300A\u5E94\u6025\u54CD\u5E94\u2014\u2014\u7F51\u7EDC\u5B89\u5168\u7684\u9884\u9632\u3001\u53D1\u73B0\u3001\u5904\u7F6E\u548C\u6062\u590D\u300B
                              \u6682\u65F6\u672A\u83B7\u53D6\uFF0C\u4F3C\u4E4E\u662F\u8001\u7248\u672C\u7684\u4E66\uFF1F  \u770B\u4E0A\u9762\u90A3\u8FB9\u6700\u65B0\u7684\u5C31\u53EF\u4EE5\u4E86\uFF1F

              \u8D44\u6599\u67E5\u8BE2\u6280\u5DE7\uFF1A
                      \u5E94\u6025\u54CD\u5E94
                      \uFF08\u63A8\u8350\uFF09  \u5E94\u6025\u54CD\u5E94  -\u9632\u6C5B  -\u653F\u5E9C  -\u6C14\u8C61\u5C40  -\u6C34\u6C61\u67D3  -\u66B4\u96E8  -\u6D2A\u6C34  -\u5730\u9707  -\u5E94\u6025\u54CD\u5E94\u4E2D\u5FC3  -\u6D77\u6D0B\u707E\u5BB3  -\u75AB\u60C5  -\u5F02\u5E38\u5929\u6C14
                      \u5E94\u6025\u54CD\u5E94  -\u9632\u6C5B  -\u653F\u5E9C  -\u54CD\u5E94\u4E2D\u5FC3
                          \u8FD9\u4E00\u6761\uFF0C\u53EF\u80FD\u4F1A\u7B5B\u9009\u6389  \u90E8\u5206\u884C\u4E1A\u5185\u7684\u6587\u7AE0

              `))},{name:"\u601D\u8DEF\u3001\u65B9\u6CD5\u8BBA\u3001\u6838\u5FC3\u672C\u8D28",desc:u.a.createElement(u.a.Fragment,null,e.\u57FA\u672C\u77E5\u8BC6),steps:[{name:"\u672C\u8D28",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u6211\u7684\u7406\u89E3\uFF0C\u5BF9\u4E8E\u672C\u8D28\uFF1A
                      \u5E94\u6025\u5C31\u662F\u624B\u52A8\u6740\u6BD2
                          \u975E\u5E38\u7B80\u5355\u660E\u4E86\u7684\u8868\u8FF0
                          \u8FD9\u4E48\u591A\u5E74\u7528\u81EA\u52A8\u6740\u6BD2  \u7528\u50BB\u4E86\u5C5E\u4E8E\u662F

                      \u53E3\u8FF0\uFF0C\u60F3\u8C61\uFF1A
                          \u653B\u51FB\u8005  \u901A\u8FC7\u3010\u9759\u6001\u65B9\u5F0F  /  \u52A8\u6001\u65B9\u5F0F\u3011\u2014\u2014\u8FDE\u63A5\u8FDB\u6765\u2014\u2014\u751F\u6210\u3010\u9AD8AI/\u4F4EAI\u3011\u2014\u2014\u7559\u4E0B\u3010\u540E\u95E8\u7A0B\u5E8F/\u540E\u95E8\u8D26\u6237\u3011\u2014\u2014\u672C\u5730\u690D\u5165\u5927\u91CF\u3010\u8F85\u52A9\u6587\u4EF6/\u4E3B\u529B\u6587\u4EF6\u3011\u2014\u2014\u6267\u884C\u3010\u547D\u4EE4\u7A0B\u5E8F/\u8FDB\u7A0B\u3011\u2014\u2014\u8FDE\u63A5\u7F51\u7EDC\u3010\u53D1\u9001\u6570\u636E/\u6536\u96C6\u6570\u636E\u3011
                                  \u8FD8\u4F1A\u6709\u3010\u9AD8\u7EA7\u8FDB\u7A0B\u5F62\u5F0F\u2014\u2014\u7EA7\u522B\u66F4\u9AD8\u670D\u52A1  /  \u65F6\u95F4\u66F4\u8FDC\u8BA1\u5212\u5B9A\u65F6\u4EFB\u52A1\u3011
                                      \u518D\u9AD8\u7EA7\u4E00\u4E9B\u7684\u5F62\u5F0F\u2014\u2014\u3010\u5C71\u5BE8\u7CFB\u7EDF\u8FDB\u7A0B\u3001\u5BC4\u751F\u7CFB\u7EDF\u8FDB\u7A0B\u3011
                          \u5728\u8FD9\u4E2A\u8FC7\u7A0B\u4E2D\uFF0C\u4F1A\u3010\u7559\u4E0B\u75D5\u8FF9\u3011\u2014\u2014\u89E6\u53D1\u3010\u89C2\u5BDF\u8005\u62A5\u8B66\u3011\u3002
                          \u8FD8\u6709\u4E9B\u672A\u5F52\u7C7B\u7684\uFF1A
                                  \u9A71\u52A8\uFF08win\uFF09\u3001\u52A0\u8F7D\u6A21\u5757\uFF08win\u3001linux\uFF09\u3001rootkit\uFF08\uFF1F\uFF1F\uFF1F\u6211\u771F\u4E0D\u719F\uFF09\u3001

                                  \u66F4\u9AD8\u7EA7\u7684\u4E00\u4E9B\uFF1A
                                          \u5185\u5B58\u6392\u67E5\uFF08\u6211\u80FD\u7406\u89E3\uFF0C\u4F46\u4E0D\u662F\u7279\u522B\u719F\u6089\u7279\u522B\u6027\u7684\u64CD\u4F5C\uFF09

                          \u8865\u5145\uFF1A
                                  \u4E00\u4E9B\u4E2D\u95F4\u4EF6\u65E5\u5FD7\uFF08Linux\u5B58\u653E\u4F4D\u7F6E\uFF0C\u7B49\uFF09
                                  \u8865\u5145\u7684\u8865\u5145\uFF1A
                                          \u5982\u679C\u6709\u7A7A\uFF0C\u5BF9\u4E8E\u3010\u6D41\u91CF\u3011\u4E00\u5757\uFF0C\u53EF\u518D\u52A0\u4E0A  WireShark  \u5E38\u89C4\u8BED\u6CD5\u7684  \u518D\u652F\u6301\uFF08\u4F60\u90FD\u7406\u89E3\u4E86\uFF0C\u4F46\u7EC6\u8282\u8BB0\u4E0D\u4F4F\uFF09



                  `))},{name:"\u5E94\u6025\u89C2",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`
                  \u89C2\u70B9\uFF1A
                      \u672A\u96E8\u7EF8\u7F2A
                              \u4F8B\u5982\uFF0C\u5F00\u5C55\u98CE\u9669\u8BC4\u4F30\uFF0C\u5236\u8BA2\u5B89\u5168\u8BA1\u5212\uFF0C\u8FDB\u884C\u5B89\u5168\u610F\u8BC6\u7684\u57F9\u8BAD\uFF0C\u4EE5\u53D1\u5E03\u5B89\u5168\u901A\u544A\u7684\u65B9\u6CD5\u8FDB\u884C\u9884\u8B66\uFF0C\u4EE5\u53CA\u5404\u79CD\u5176\u4ED6\u9632\u8303\u63AA\u65BD\u3002
                      \u4EA1\u7F8A\u8865\u7262
                              \u4F8B\u5982\uFF0C\u5728\u53D1\u73B0\u4E8B\u4EF6\u540E\uFF0C\u91C7\u53D6\u7D27\u6025\u63AA\u65BD\uFF0C\u8FDB\u884C\u7CFB\u7EDF\u5907\u4EFD\u3001\u75C5\u6BD2\u68C0\u6D4B\u3001\u540E\u95E8\u68C0\u6D4B\u3001\u6E05\u9664\u75C5\u6BD2\u6216\u540E\u95E8\u3001\u9694\u79BB\u3001\u7CFB\u7EDF\u6062\u590D\u3001\u8C03\u67E5\u4E0E\u8FFD\u8E2A\u3001\u5165\u4FB5\u53D6\u8BC1\u7B49\u4E00\u7CFB\u7EDF\u64CD\u4F5C\u3002
                      \u76F8\u4E92\u5173\u7CFB\uFF1A
                              \u4E8B\u524D\u7684\u8BA1\u5212\u548C\u51C6\u5907\u53EF\u4E3A\u4E8B\u4EF6\u53D1\u751F\u540E\u7684\u54CD\u5E94\u52A8\u4F5C\u63D0\u4F9B\u6307\u5BFC\u6846\u67B6\u3002
                                      \u5426\u5219\uFF0C\u54CD\u5E94\u52A8\u4F5C\u5F88\u53EF\u80FD\u9677\u5165\u6DF7\u4E71\uFF0C\u6BEB\u65E0\u7AE0\u6CD5\u7684\u54CD\u5E94\u52A8\u4F5C\u6709\u53EF\u80FD\u5F15\u8D77\u66F4\u5927\u7684\u635F\u5931
                              \u4E8B\u540E\u7684\u54CD\u5E94\u53EF\u80FD\u4F1A\u53D1\u73B0\u4E8B\u524D\u8BA1\u5212\u7684\u4E0D\u8DB3\uFF0C\u4ECE\u800C\u4F7F\u6211\u4EEC\u5438\u53D6\u6559\u8BAD\uFF0C\u8FDB\u4E00\u6B65\u5B8C\u5584\u5B89\u5168\u8BA1\u5212\u3002
                  `))},{name:"\u65B9\u6CD5\u8BBA \u548C \u80FD\u529B",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u5BF9\u673A\u6784\u7684\u80FD\u529B\u8981\u6C42",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                  \u5BF9\u673A\u6784\u7684\u80FD\u529B\u8981\u6C42\uFF1A
                          1\uFF09\u6570\u636E\u91C7\u96C6\u3001\u5B58\u50A8\u548C\u68C0\u7D22\u80FD\u529B
                                  \uFF081\uFF09\u80FD\u5BF9\u5168\u6D41\u91CF\u6570\u636E\u534F\u8BAE\u8FDB\u884C\u8FD8\u539F\uFF1B
                                  \uFF082\uFF09\u80FD\u5BF9\u8FD8\u539F\u7684\u6570\u636E\u8FDB\u884C\u5B58\u50A8\uFF1B
                                  \uFF083\uFF09\u80FD\u5BF9\u5B58\u50A8\u7684\u6570\u636E\u5FEB\u901F\u68C0\u7D22\u3002
                          2\uFF09\u4E8B\u4EF6\u53D1\u73B0\u80FD\u529B
                                  \uFF081\uFF09\u80FD\u53D1\u73B0\u9AD8\u7EA7\u53EF\u6301\u7EED\u5A01\u80C1\uFF08AdvancedPersistent Threat\uFF0CAPT\uFF09\u653B\u51FB\uFF1B
                                  \uFF082\uFF09\u80FD\u53D1\u73B0Web\u653B\u51FB\uFF1B
                                  \uFF083\uFF09\u80FD\u53D1\u73B0\u6570\u636E\u6CC4\u9732\uFF1B
                                  \uFF084\uFF09\u80FD\u53D1\u73B0\u5931\u9677\u4E3B\u673A\uFF1B
                                  \uFF085\uFF09\u80FD\u53D1\u73B0\u5F31\u5BC6\u7801\u53CA\u4F01\u4E1A\u901A\u7528\u5BC6\u7801\uFF1B
                                  \uFF086\uFF09\u80FD\u53D1\u73B0\u4E3B\u673A\u5F02\u5E38\u884C\u4E3A\u3002
                          3\uFF09\u4E8B\u4EF6\u5206\u6790\u80FD\u529B
                                  \uFF081\uFF09\u80FD\u8FDB\u884C\u591A\u7EF4\u5EA6\u5173\u8054\u5206\u6790\uFF1B
                                  \uFF082\uFF09\u80FD\u8FD8\u539F\u5B8C\u6574\u6740\u4F24\u94FE\uFF1B
                                  \uFF083\uFF09\u80FD\u7ED3\u5408\u5177\u4F53\u4E1A\u52A1\u8FDB\u884C\u6DF1\u5EA6\u5206\u6790\u3002
                          4\uFF09\u4E8B\u4EF6\u7814\u5224\u80FD\u529B
                                  \uFF081\uFF09\u80FD\u786E\u5B9A\u653B\u51FB\u8005\u7684\u52A8\u673A\u53CA\u76EE\u7684\uFF1B
                                  \uFF082\uFF09\u80FD\u786E\u5B9A\u4E8B\u4EF6\u7684\u5F71\u54CD\u9762\u53CA\u5F71\u54CD\u8303\u56F4\uFF1B
                                  \uFF083\uFF09\u80FD\u786E\u5B9A\u653B\u51FB\u8005\u7684\u624B\u6CD5\u3002
                          5\uFF09\u4E8B\u4EF6\u5904\u7F6E\u80FD\u529B
                                  \uFF081\uFF09\u80FD\u5728\u7B2C\u4E00\u65F6\u95F4\u6062\u590D\u4E1A\u52A1\u6B63\u5E38\u8FD0\u884C\uFF1B
                                  \uFF082\uFF09\u80FD\u5BF9\u53D1\u73B0\u7684\u75C5\u6BD2\u3001\u6728\u9A6C\u8FDB\u884C\u5904\u7F6E\uFF1B
                                  \uFF083\uFF09\u80FD\u5BF9\u653B\u51FB\u8005\u6240\u5229\u7528\u7684\u6F0F\u6D1E\u8FDB\u884C\u4FEE\u590D\uFF1B
                                  \uFF084\uFF09\u80FD\u5BF9\u95EE\u9898\u673A\u5668\u8FDB\u884C\u5B89\u5168\u52A0\u56FA\u3002
                          6\uFF09\u653B\u51FB\u6EAF\u6E90\u80FD\u529B
                                  \uFF081\uFF09\u5177\u5907\u5B89\u5168\u5927\u6570\u636E\u80FD\u529B\uFF1B
                                  \uFF082\uFF09\u80FD\u6839\u636E\u5DF2\u6709\u7EBF\u7D22\uFF08IP\u5730\u5740\u3001\u6837\u672C\u7B49\uFF09\u5BF9\u653B\u51FB\u8005\u7684\u653B\u51FB\u8DEF\u5F84\u3001\u653B\u51FB\u624B\u6CD5\u53CA\u80CC\u540E\u7EC4\u7EC7\u8FDB\u884C\u8FD8\u539F\u3002


                      `))},{name:"\u5E38\u7528\u65B9\u6CD5\u8BBA",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                  \u4ED6\u4EBA\u6240\u8BF4\uFF1A
                          \u4E09\u8981\u7D20\u6CD5
                              \u65F6\u95F4
                              \u5730\u70B9
                              \u4E8B\u4EF6
                                  \u7CFB\u7EDF\u7684
                                  \u5B89\u5168\u8BBE\u5907\u7684
                                  \u76F8\u5173\u5E94\u7528\u7684
                                  \u64CD\u4F5C\u5386\u53F2\u7684
                                  \u65E5\u5FD7\u7684

                          \u56DE\u6EAF\u653B\u51FB\u6CD5
                              \u4ECE\u3010\u653B\u51FB\u8005\u3011\u89D2\u5EA6\uFF0C\u6A21\u62DF\u51FA\u3010\u5408\u7406\u3011\u7684\u3010\u653B\u51FB\u8DEF\u7EBF\u3011


                          \u7ECF\u9A8C\u6CD5

                              \u5E38\u89C1\u76EE\u5F55
                              \u5E38\u7528\u624B\u6CD5
                                  \u5E38\u89C1\u4E00\u53E5\u8BDD\u6728\u9A6C
                                  \u5E38\u89C1\u540E\u95E8

                              \u5E38\u89C1\u6076\u610F\u7A0B\u5E8F\u7279\u5F81



                  PDCERF\u65B9\u6CD5\uFF086\u9636\u6BB5\uFF09
                          \u51C6\u5907\u9636\u6BB5
                          \u68C0\u6D4B\u9636\u6BB5
                              \u68C0\u6D4B\u9636\u6BB5\u4E3B\u8981\u68C0\u6D4B\u4E8B\u4EF6\u662F\u3010\u5DF2\u7ECF\u53D1\u751F\u3011\u7684\u8FD8\u662F\u3010\u6B63\u5728\u8FDB\u884C\u4E2D\u3011\u7684\uFF0C\u4EE5\u53CA\u4E8B\u4EF6\u4EA7\u751F\u7684\u539F\u56E0\u3002
                          \u6291\u5236\u9636\u6BB5
                              \u9650\u5236\u3010\u653B\u51FB/\u7834\u574F\u3011\u6CE2\u53CA\u7684\u8303\u56F4\uFF0C\u540C\u65F6\u4E5F\u662F\u5728\u964D\u4F4E\u6F5C\u5728\u7684\u635F\u5931\u3002
                          \u6839\u9664\u9636\u6BB5
                              \u901A\u8FC7\u4E8B\u4EF6\u5206\u6790\u627E\u51FA\u3010\u6839\u6E90\u3011\u5E76\u3010\u5F7B\u5E95\u6839\u9664\u3011\uFF0C\u4EE5\u907F\u514D\u653B\u51FB\u8005\u518D\u6B21\u4F7F\u7528\u76F8\u540C\u7684\u624B\u6BB5\u653B\u51FB\u7CFB\u7EDF\uFF0C\u5F15\u53D1\u5B89\u5168\u4E8B\u4EF6\u3002
                          \u6062\u590D\u9636\u6BB5
                              \u628A\u88AB\u7834\u574F\u7684\u4FE1\u606F\u3010\u5F7B\u5E95\u8FD8\u539F\u3011\u5230\u6B63\u5E38\u8FD0\u4F5C\u72B6\u6001\u3002
                          \u603B\u7ED3\u9636\u6BB5
                              \uFF08\u9488\u5BF9\u4EBA\u5458\u548C\u590D\u76D8\uFF09\uFF1A
                                  \u56DE\u987E\u5E76\u6574\u5408\u5E94\u6025\u54CD\u5E94\u8FC7\u7A0B\u7684\u76F8\u5173\u4FE1\u606F
                                      \u8FDB\u884C\u4E8B\u540E\u5206\u6790\u603B\u7ED3\u548C\u4FEE\u8BA2\u5B89\u5168\u8BA1\u5212\u3001\u653F\u7B56\u3001\u7A0B\u5E8F
                                          \u5E76\u8FDB\u884C\u8BAD\u7EC3\uFF0C\u4EE5\u9632\u6B62\u5165\u4FB5\u7684\u518D\u6B21\u53D1\u751F\u3002
                              \u8FD9\u4E00\u9636\u6BB5\u7684\u5DE5\u4F5C\u5BF9\u4E8E\u3010\u51C6\u5907\u9636\u6BB5\u3011\u5DE5\u4F5C\u7684\u5F00\u5C55\u8D77\u5230\u91CD\u8981\u7684\u652F\u6301\u4F5C\u7528
                                  \u53C8\u662F\u4E00\u4E2A\u5FAA\u73AF\u3002

                      `))}]}]},{name:"\u73B0\u573A\u5904\u7F6E - \u57FA\u7840\u6D41\u7A0B",desc:u.a.createElement(u.a.Fragment,null,e.\u57FA\u672C\u77E5\u8BC6),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u73B0\u573A\u5904\u7F6E\u8FC7\u7A0B\u4E2D
                  1. \u5148\u8981\u786E\u5B9A\u4E8B\u4EF6\u7C7B\u578B\u4E0E\u65F6\u95F4\u8303\u56F4\uFF0C\u9488\u5BF9\u4E0D\u540C\u7684\u4E8B\u4EF6\u7C7B\u578B\uFF0C\u5BF9\u4E8B\u4EF6\u76F8\u5173\u4EBA\u5458\u8FDB\u884C\u8BBF\u8C08\uFF0C\u4E86\u89E3\u4E8B\u4EF6\u53D1\u751F\u7684\u5927\u81F4\u60C5\u51B5\u53CA\u6D89\u53CA\u7684\u7F51\u7EDC\u3001\u4E3B\u673A\u7B49\u57FA\u672C\u4FE1\u606F\uFF0C\u5236\u5B9A\u76F8\u5173\u7684\u5E94\u6025\u65B9\u6848\u548C\u7B56\u7565\u3002
                  2. \u968F\u540E\u5BF9\u76F8\u5173\u7684\u4E3B\u673A\u8FDB\u884C\u6392\u67E5\uFF0C\u4E00\u822C\u4F1A\u4ECE\u7CFB\u7EDF\u6392\u67E5\u3001\u8FDB\u7A0B\u6392\u67E5\u3001\u670D\u52A1\u6392\u67E5\u3001\u6587\u4EF6\u75D5\u8FF9\u6392\u67E5\u3001\u65E5\u5FD7\u5206\u6790\u7B49\u65B9\u9762\u8FDB\u884C
                  3. \u6574\u5408\u76F8\u5173\u4FE1\u606F\uFF0C\u8FDB\u884C\u5173\u8054\u63A8\u7406\uFF0C\u6700\u540E\u7ED9\u51FA\u4E8B\u4EF6\u7ED3\u8BBA\u3002
              `),u.a.createElement("div",null,u.a.createElement("img",{src:n("/gDc")})))}],v=[{name:"\u57FA\u672C\u5DE5\u5177",desc:u.a.createElement(u.a.Fragment,null,e.\u5DE5\u5177\u51C6\u5907),steps:[{name:"\u5728\u7EBF\u5DE5\u5177",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`


                  \u52D2\u7D22\u75C5\u6BD2\u3001\u89E3\u5BC6\u5DE5\u5177

                          \u3010\u67E5\u8BE2\u3011+\u3010\u89E3\u5BC6\u3011
                              \u5947\u5B89\u4FE1
                                  https://lesuobingdu.qianxin.com/
                              360
                                  http://lesuobingdu.360.cn
                              QQ
                                  https://guanjia.qq.com/pr/ls/#navi_0
                              IdRansomWare
                                  https://id-ransomware.malwarehunterteam.com/
                              NoMoreRansom
                                  https://www.nomoreransom.org/zh/decryption-tools.html
                              \u5361\u5DF4\u65AF\u57FA
                                  https://noransom.kaspersky.com/
                          \u3010\u89E3\u5BC6\u3011
                              \u8D8B\u52BF
                                  \u4E0B\u8F7D\u9875\uFF1Ahttps://success.trendmicro.com/dcx/s/solution/1114221-downloading-and-using-the-trend-micro-ransomware-file-decryptor?language=en_US
                                  \u4ECB\u7ECD\u9875\uFF1Ahttps://esupport.trendmicro.com/en-us/home/pages/technical-support/1114221.aspx
                              EmsiSoft
                                  https://www.emsisoft.com/ransomware-decryption-tools/free-download
                              Avast\u5C0F\u7EA2\u4F1E
                                  https://www.avast.com/en-us/ransomware-decryption-tools
                              QuickHeal
                                  https://www.quickheal.com/free-ransomware-decryption-tool


                  \u5A01\u80C1\u60C5\u62A5\u3001\u5927\u6570\u636E\u67E5\u8BE2\u3001\u6709\u5BB3\u8D44\u4EA7\u3001\u6709\u5BB3\u75C5\u6BD2\u6728\u9A6C\u3001\u6709\u5BB3\u6570\u636E\uFF0C\u67E5\u8BE2
                              \uFF08\u7406\u89E3\uFF1A\u5BF9\u4E8E\u4EFB\u4F55\u653B\u51FB\u7684\u5927\u6570\u636E\uFF09

                          \u5947\u5B89\u4FE1
                              https://ti.qianxin.com/
                          \u5FAE\u6B65\u5728\u7EBF
                              https://x.threatbook.cn/
                          VirusTotal
                              https://www.virustotal.com/
                          ThreatCrowd
                              https://www.threatcrowd.org/
                          ThreatMiner
                              https://www.threatminer.org/


                  `))},{name:"\u5C0F\u5DE5\u5177\uFF08\u4E2A\u4EBA\uFF0C\u6216\u4F53\u91CF\u6BD4\u8F83\u5C0F\u7684\uFF09",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`


                  \u542F\u52A8\u9879
                      AutoRuns

                  \u8FDB\u7A0B
                      ProcDump

                      ProcessMonitor

                      ProcessExplorer
                          \u4ECB\u7ECD\uFF1A
                              \u5305\u542B\u5728\u3010SysInternalsSuite\u3011\u4E4B\u5185\u3002
                              \u300A\u8D85\u5F3A\u4EFB\u52A1\u7BA1\u7406\u5668\u300B\uFF0C\u6211\u4E4B\u524D\u7528\u8FC7\u7684\u3002
                          \u5B83\u80FD\u7BA1\u7406\u9690\u85CF\u5728\u540E\u53F0\u8FD0\u884C\u7684\u7A0B\u5E8F\uFF0C\u53EF\u76D1\u89C6\u3001\u6302\u8D77\u3001\u91CD\u542F\u3001\u5F3A\u884C\u7EC8\u6B62\u4EFB\u4F55\u7A0B\u5E8F\uFF0C\u5305\u62EC\u7CFB\u7EDF\u7EA7\u7684\u4E0D\u5141\u8BB8\u968F\u4FBF\u7EC8\u6B62\u7684\u5173\u952E\u8FDB\u7A0B\u7B49\u3002

                      BusyBox
                          \u573A\u666F\uFF1A
                              \u5982\u679C\u547D\u4EE4\u3010\u88AB\u7E82\u6539\u3011\uFF0C\u90A3\u4E48\u518D\u67E5\u770B\u8FDB\u7A0B\u6216\u7F51\u7EDC\u8FDE\u63A5\u53EF\u80FD\u5C31\u4E0D\u51C6\u786E\u3002
                              \u7531\u4E8EBusyBox\u91C7\u7528\u9759\u6001\u7F16\u8BD1\uFF0C\u4E0D\u4F9D\u8D56\u4E8E\u7CFB\u7EDF\u7684\u52A8\u6001\u94FE\u63A5\u5E93\uFF0C
                                  \u56E0\u6B64\u4E0D\u53D7ld.so.preload\u52AB\u6301\u5F71\u54CD\uFF0C\u80FD\u591F\u6B63\u5E38\u64CD\u4F5C\u6587\u4EF6\u3002
                          \u57FA\u672C\u7528\u5904\uFF1A
                              \u5728\u3010\u547D\u4EE4\u88AB\u7E82\u6539\u3011\u65F6\uFF0C\u67E5\u770B\u3010\u771F\u6B63\u7684\u6587\u4EF6\u4FE1\u606F\u3011\u3002

                      unhide
                          \u53EF\u4EE5\u6392\u67E5\u9690\u85CF\u8FDB\u7A0B\u3002
                              unhide\u662F\u4E00\u4E2A\u5C0F\u5DE7\u7684\u7F51\u7EDC\u53D6\u8BC1\u5DE5\u5177\uFF0C
                              \u80FD\u591F\u53D1\u73B0\u9690\u85CF\u7684\u8FDB\u7A0B\u548CTCP/UDP\u7AEF\u53E3\u3002

                          \u5728Linux\u3001UNIX\u3001MS-Windows\u7B49\u64CD\u4F5C\u7CFB\u7EDF\u4E2D\u90FD\u53EF\u4F7F\u7528\u3002

                          \u4F7F\u7528\u4E3E\u4F8B\uFF1A
                              \u4F8B\u5982\uFF0C\u5728\u5E94\u6025\u54CD\u5E94\u4E2D\u53D1\u73B0\u653B\u51FB\u8005\u5229\u7528LD_PRELOAD\u52AB\u6301\u7CFB\u7EDF\u51FD\u6570\uFF0C\u5C06\u6076\u610F\u52A8\u6001\u94FE\u63A5\u5E93\u8DEF\u5F84\u5199\u5165\u3010/etc/ld.so.preload\u3011\u914D\u7F6E\u6587\u4EF6\uFF0C  \uFF08\u6CA1\u6709\u5219\u521B\u5EFA\uFF09
                                      \u4F7F\u5BF9\u5E94\u7684\u6076\u610F\u52A8\u6001\u94FE\u63A5\u5E93\u6587\u4EF6\u9690\u85CF\u3002
                                      \u6267\u884C\u3010ps\u3011\u548C\u3010top\u3011\u547D\u4EE4\u5747\u65E0\u6CD5\u770B\u5230\u6076\u610F\u8FDB\u7A0B\uFF0C
                                          \u4F46\u4F7F\u7528\u3010unhide proc\u3011\u547D\u4EE4\u53EF\u67E5\u51FA\u9690\u85CF\u7684\u6076\u610F\u8FDB\u7A0B\u3002

                  \u4E8B\u4EF6\u3001\u65E5\u5FD7
                      EventLogExplorer

                      FullEventLogView

                      LogParser

                      \u3010\u65E5\u5FD7\u6587\u4EF6\u67E5\u770B\u5668-WebServer\u3011
                              SqlServer\u5185\u7F6E\u7684\u3010\u65E5\u5FD7\u67E5\u770B\u5668\u3011
                                  123

                  \u7528\u6237
                      LP_Check
                          \u53EF\u4EE5\u7528\u6765\u67E5\u627E\u3010\u514B\u9686\u7528\u6237\u3011\u3002
                              \u9644\u56FE\uFF1A  https://res.weread.qq.com/wrepub/epub_35011077_258

                  \u7F51\u7EDC
                      TCPView
                          \u53EF\u7528\u4E8E\u68C0\u6D4B\u5F53\u524D\u7CFB\u7EDF\u4E2D\u7684\u8FDB\u7A0B\u53CA\u5176\u5BF9\u5E94\u7684\u8FDE\u63A5\u72B6\u6001\u3002

                          \u989C\u8272\uFF1A
                              \u5F53\u8FDB\u7A0B\u6807\u8BB0\u4E3A\u7EFF\u8272\u65F6\uFF0C\u8868\u793A\u8BE5\u8FDE\u63A5\u4E3A\u65B0\u53D1\u8D77\u7684\u8FDE\u63A5\uFF0C
                              \u5F53\u8FDB\u7A0B\u6807\u8BB0\u4E3A\u7EA2\u8272\u65F6\uFF0C\u8868\u793A\u8BE5\u8FDE\u63A5\u4E3A\u7ED3\u675F\u72B6\u6001\u3002

                  `))},{name:"\u5927\u5DE5\u5177\uFF08\u5382\u5546\uFF0C\u6216\u4F53\u91CF\u6BD4\u8F83\u5927\u7684\uFF09",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                  SysInternalsSuite\u5DE5\u5177\u96C6
                          \u76F8\u5173\u94FE\u63A5\uFF1Ahttps://docs.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite


                  PCHunter
                      \u662F\u4E00\u4E2A\u529F\u80FD\u5F3A\u5927\u7684Windows\u7CFB\u7EDF\u4FE1\u606F\u67E5\u770B\u8F6F\u4EF6\uFF0C\u540C\u65F6\u4E5F\u662F\u624B\u5DE5\u6740\u6BD2\u8F6F\u4EF6\uFF0C
                      \u5B83\u4E0D\u4F46\u53EF\u4EE5\u67E5\u770B\u5404\u7C7B\u7CFB\u7EDF\u4FE1\u606F\uFF0C\u8FD8\u53EF\u4EE5\u67E5\u51FA\u8BA1\u7B97\u673A\u4E2D\u6F5C\u4F0F\u7684\u6316\u77FF\u6728\u9A6C\u3002
                      PCHunter\u4F7F\u7528\uF9BAWindows\u5185\u6838\u6280\u672F\u3002

                      \u7F3A\u9677\uFF1A       \uFF08\u4E00\u5B9A\u8981\u6CE8\u610F\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF09
                          \u9488\u5BF9\u91CD\u8981\u4E1A\u52A1\u5728\u7EBF\u670D\u52A1\u5668\u53CA\u6BD4\u8F83\u65E7\u7684\u7CFB\u7EDF\uFF0C\u5C3D\u91CF\u4E0D\u8981\u4F7F\u7528PCHunter\uFF0C
                              \u56E0\u4E3A\u5176\u6613\u89E6\u53D1\u84DD\u5C4F\uFF0C\u5BFC\u81F4\u670D\u52A1\u5668\u91CD\u542F\u6216\u4E1A\u52A1\u4E2D\u65AD\u7B49\u3002

                      \u4F7F\u7528\uFF1A
                          \u2460 \u4FE1\u606F\u4E2D\u9ED1\u8272\u7684\u6761\u76EE\u4EE3\u8868\u5FAE\u8F6F\u8FDB\u7A0B\uFF1B
                          \u2461 \u84DD\u8272\u7684\u6761\u76EE\u4EE3\u8868\u975E\u5FAE\u8F6F\u8FDB\u7A0B\uFF0C\u53EF\u80FD\u662F\u7B2C\u4E09\u65B9\u5E94\u7528\u7A0B\u5E8F\u7684\u8FDB\u7A0B\uFF0C
                              \u84DD\u8272\u7F3A\u5C11\u6587\u4EF6\u5382\u5546\u4FE1\u606F\u7684\u8FDB\u7A0B\u9700\u591A\u52A0\u5173\u6CE8\uFF1B
                          \u2462 \u7EA2\u8272\u7684\u6761\u76EE\u4EE3\u8868\u53EF\u7591\u8FDB\u7A0B\u3001\u9690\u85CF\u670D\u52A1\u3001\u88AB\u6302\u94A9\u51FD\u6570


                  \u300A\u5E94\u6025\u54CD\u5E94\u4FE1\u606F\u91C7\u96C6\u5DE5\u5177\u300B\u2014\u2014\u89C2\u661F\u5B9E\u9A8C\u5BA4
                          \u96B6\u5C5E\u4E8E\u3010\u5947\u5B89\u4FE1\u3011\u7684\u3010ALPHA\u5A01\u80C1\u5206\u6790\u5E73\u53F0 - \u5A01\u80C1\u5206\u6790\u6B66\u5668\u5E93\u3011\u3002

                  \u5947\u5B89\u4FE1\u5E94\u6025\u54CD\u5E94\u5DE5\u5177\u7BB1
                          123

                  WebShell\u68C0\u6D4B
                      D\u76FE
                          \u76F8\u5173\u56FE\u7247\uFF1Ahttps://res.weread.qq.com/wrepub/epub_35011077_75
                          D\u76FE\u662F\u76EE\u524D\u6D41\u884C\u7684Web\u67E5\u6740\u5DE5\u5177\uFF0C\u4F7F\u7528\u65B9\u4FBF

                          \u529F\u80FD\uFF1A
                              \uFF081\uFF09Webshell\u67E5\u6740\u3001\u53EF\u7591\u6587\u4EF6\u9694\u79BB\uFF1B
                              \uFF082\uFF09\u7AEF\u53E3\u8FDB\u7A0B\u67E5\u770B\u3001base64\u89E3\u7801\uFF0C\u4EE5\u53CA\u514B\u9686\u7528\u6237\u68C0\u6D4B\u7B49\uFF1B
                              \uFF083\uFF09\u6587\u4EF6\u76D1\u63A7\u3002

                      \u6CB3\u9A6CWebshell\u67E5\u6740
                          \u62E5\u6709\u6D77\u91CFWebshell\u6837\u672C\u548C\u81EA\u4E3B\u67E5\u6740\u6280\u672F
                              \u91C7\u7528\u4F20\u7EDF\u7279\u5F81+\u4E91\u7AEF\u5927\u6570\u636E\u53CC\u5F15\u64CE\u7684\u67E5\u6740\u6280\u672F\uFF0C\u652F\u6301\u591A\u79CD\u64CD\u4F5C\u7CFB\u7EDF

                      HwsKill

                      WebshellKill

                  \u540E\u95E8\u68C0\u6D4B
                      Linux
                          ChkRootkit
                          RKHunter

                  `))}]},{name:"\uFF08\u53EF\u6574\u5408\uFF09\u8D85\u91CD\u8981\u6A21\u5757 \u2014\u2014 \u65E5\u5FD7",desc:u.a.createElement(u.a.Fragment,null,e.\u5DE5\u5177\u51C6\u5907),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u4E3B\u673A\u65E5\u5FD7
                      \u5E94\u7528\u7A0B\u5E8F
                      \u5B89\u5168\u6027
                      \u7CFB\u7EDF

              \u4E2D\u95F4\u4EF6\u65E5\u5FD7
                      IIS
                      Apache
                      Tomcat

              \u5E38\u89C1\u65E5\u5FD7ID
                      \u767B\u5F55
                          1102  \u6E05\u7406\u5BA1\u8BA1\u65E5\u5FD7
                          4624  \u767B\u5F55\u6210\u529F
                                  \u8868\u793A\u5728\u5927\u90E8\u5206\u767B\u5F55\u4E8B\u4EF6\u6210\u529F\u65F6\u4F1A\u4EA7\u751F\u7684\u65E5\u5FD7\u3002
                          4625  \u767B\u5F55\u5931\u8D25
                                  \u8868\u793A\u5728\u5927\u90E8\u5206\u767B\u5F55\u4E8B\u4EF6\u5931\u8D25\u65F6\u4F1A\u4EA7\u751F\u7684\u65E5\u5FD7\uFF08\u89E3\u9501\u5C4F\u5E55\u5E76\u4E0D\u4F1A\u4EA7\u751F\u8FD9\u4E2A\u65E5\u5FD7\uFF09
                          4648  \u8868\u793A\u4E00\u4E9B\u5176\u4ED6\u7684\u767B\u5F55\u60C5\u51B5\u3002
                          4672  \u8868\u793A\u5728\u7279\u6743\u7528\u6237\u767B\u5F55\u6210\u529F\u65F6\u4F1A\u4EA7\u751F\u7684\u65E5\u5FD7\uFF0C\u5982\u767B\u5F55Administrator\uFF0C\u4E00\u822C\u4F1A\u770B\u52304624\u548C4672\u65E5\u5FD7\u4E00\u8D77\u51FA\u73B0\u3002
                          4720  \u521B\u5EFA\u7528\u6237\u65F6\uFF0C\u4F1A\u4EA7\u751F\u7684\u65E5\u5FD7
                          4722  \u542F\u7528\u7528\u6237\u65F6\uFF0C\u4F1A\u4EA7\u751F\u7684\u65E5\u5FD7
                          4724  \u8BD5\u56FE\uFF0C\u91CD\u7F6E\u8D26\u53F7\u3001\u5BC6\u7801
                          4726  \u5220\u9664\u7528\u6237\u65F6\uFF0C\u4F1A\u4EA7\u751F\u7684\u65E5\u5FD7
                          4728  \u8868\u793A\u628A\u7528\u6237\u6DFB\u52A0\u8FDB\u5B89\u5168\u5168\u5C40\u7EC4\uFF0C\u5982Administrators\u7EC4\u3002
                          4729  \u5C06\u6210\u5458\uFF0C\u4ECE\u5B89\u5168\u7684\u5168\u5C40\u7EC4\u4E2D\uFF0C\u79FB\u9664
                          4732  \u5DF2\u5411\uFF0C\u542F\u7528\u4E86\u5B89\u5168\u7684\u672C\u5730\u7EC4\u4E2D\uFF0C\u6DFB\u52A0\u67D0\u4E2A\u6210\u5458\uFF1B\u5982\u901A\u5E38\uFF0C\u5728\u5C06\u521B\u5EFA\u7684\u7528\u6237\uFF0C\u6DFB\u52A0\u5230 Administrators \u7BA1\u7406\u5458\u7EC4\u65F6\uFF0C\u4F1A\u4EA7\u751F\u8BE5\u65E5\u5FD7
                          4797  \u67E5\u8BE2\u8D26\u6237\u662F\u5426\u5B58\u5728\u7A7A\u767D\u5BC6\u7801
                                  \u8868\u793A\u8BD5\u56FE\u67E5\u8BE2\u8D26\u6237\u662F\u5426\u5B58\u5728\u7A7A\u767D\u5BC6\u7801

                      \u5176\u5B83\u4E8B\u4EF6
                          5     \u62D2\u7EDD\u8BBF\u95EE
                          6     \u53E5\u67C4\u65E0\u6548
                          \u5B58\u50A8
                                7     \u5B58\u50A8\u63A7\u5236\u5757\u88AB\u7834\u574F
                                8     \u5B58\u50A8\u7A7A\u95F4\u4E0D\u8DB3
                                9     \u5B58\u50A8\u63A7\u5236\u5757\u5730\u5740\u65E0\u6548


              `))},{name:"\u8D85\u91CD\u8981\u6A21\u5757 \u2014\u2014 \u547D\u4EE4\u96C6\u9526",desc:u.a.createElement(u.a.Fragment,null,e.\u5DE5\u5177\u51C6\u5907),steps:[{name:"\u4F18\u5148\u300A\u547D\u4EE4\u7C7B\u578B\u300B\u805A\u5408",desc:u.a.createElement(u.a.Fragment,null),steps:Object(o.a)(P.\u5148\u547D\u4EE4\u5206\u7C7B____\u518D\u64CD\u4F5C\u7CFB\u7EDF())},{name:"\u4F18\u5148\u300A\u64CD\u4F5C\u7CFB\u7EDF\u300B\u805A\u5408",desc:u.a.createElement(u.a.Fragment,null),steps:Object(o.a)(P.\u5148\u64CD\u4F5C\u7CFB\u7EDF____\u518D\u547D\u4EE4\u5206\u7C7B())}]}],L=[{name:"\u5177\u4F53\u573A\u666F\u3001\u9884\u6848",desc:u.a.createElement(u.a.Fragment,null,e.\u5B9E\u6218\u89E3\u6790),steps:[{name:"\u52D2\u7D22\u75C5\u6BD2",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u6982\u8FF0",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                  \u57FA\u672C\u77E5\u8BC6\uFF1A
                          \u673A\u5668\u4E00\u65E6\u906D\u53D7\u52D2\u7D22\u75C5\u6BD2\u653B\u51FB\uFF0C\u5C06\u4F1A\u4F7F\u7EDD\u5927\u591A\u6570\u6587\u4EF6\u88AB\u52A0\u5BC6\u7B97\u6CD5\u4FEE\u6539\uFF0C\u5E76\u6DFB\u52A0\u4E00\u4E2A\u7279\u6B8A\u7684\u540E\u7F00\uFF0C
                              \u4E14\u53D7\u5BB3\u8005\u65E0\u6CD5\u8BFB\u53D6\u539F\u672C\u6B63\u5E38\u7684\u6587\u4EF6\uFF0C\u4ECE\u800C\u9020\u6210\u65E0\u6CD5\u4F30\u91CF\u7684\u635F\u5931\u3002

                          \u52D2\u7D22\u75C5\u6BD2\u901A\u5E38\u5229\u7528\u3010\u975E\u5BF9\u79F0\u52A0\u5BC6\u7B97\u6CD5\u3011\u548C\u3010\u5BF9\u79F0\u52A0\u5BC6\u7B97\u6CD5\u3011\u7EC4\u5408\u7684\u5F62\u5F0F\u6765\u52A0\u5BC6\u6587\u4EF6\u3002

                          \u7EDD\u5927\u591A\u6570\u52D2\u7D22\u75C5\u6BD2\u5747\u65E0\u6CD5\u901A\u8FC7\u6280\u672F\u624B\u6BB5\u89E3\u5BC6\uFF0C\u5FC5\u987B\u62FF\u5230\u5BF9\u5E94\u7684\u89E3\u5BC6\u79C1\u94A5\u624D\u6709\u53EF\u80FD\u65E0\u635F\u8FD8\u539F\u88AB\u52A0\u5BC6\u6587\u4EF6\u3002
                              \u653B\u51FB\u8005\u6B63\u662F\u901A\u8FC7\u8FD9\u6837\u7684\u884C\u4E3A\u5411\u53D7\u5BB3\u8005\u52D2\u7D22\u9AD8\u6602\u7684\u8D4E\u91D1\uFF0C
                                  \u8FD9\u4E9B\u8D4E\u91D1\u5FC5\u987B\u901A\u8FC7\u6570\u5B57\u8D27\u5E01\u652F\u4ED8\uFF0C\u4E00\u822C\u65E0\u6CD5\u6EAF\u6E90\uFF0C\u56E0\u6B64\u5371\u5BB3\u5DE8\u5927\u3002


                          \u5386\u53F2\uFF1A
                                  \u6C38\u6052\u4E4B\u84DD

                                  \u4F20\u64AD\u591A\u5229\u7528\u201C\u6C38\u6052\u4E4B\u84DD\u201D\u6F0F\u6D1E\u3001\u66B4\u529B\u7834\u89E3\u3001\u9493\u9C7C\u90AE\u4EF6\u3001\u6346\u7ED1\u8F6F\u4EF6\u7B49\u65B9\u6CD5\u3002





                  \u6709\u5927\u91CF\u5728\u7EBF\u5DE5\u5177\uFF0C\u5DF2\u8BB0\u5F55\u5728\u4E0A\u9762\u90E8\u5206\u3002


                  \u5178\u578B\u6848\u4F8B\u5904\u7406\uFF1A
                          Crysis/Dharma
                              \u8D44\u6599\uFF1Ahttps://bbs.360.cn/thread-15782297-1-1.html
                              \u91C7\u7528AES+RSA\u7684\u52A0\u5BC6\u65B9\u6CD5\uFF0C\u56E0\u6B64\u6700\u65B0\u7248\u672C\u65E0\u6CD5\u89E3\u5BC6\u3002
                              \u653B\u51FB\u65B9\u6CD5\u540C\u6837\u662F\u5229\u7528\u8FDC\u7A0BRDP\u66B4\u529B\u7834\u89E3\u7684\u65B9\u6CD5\u690D\u5165\u5230\u670D\u52A1\u5668\u8FDB\u884C\u653B\u51FB\u3002
                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1A\u3010id\u3011+\u52D2\u7D22\u90AE\u7BB1+\u7279\u5B9A\u540E\u7F00\u3002
                              \uFF082\uFF09\u4F20\u64AD\u65B9\u6CD5\uFF1ARDP\u66B4\u529B\u7834\u89E3\u3002
                              \uFF083\uFF09\u7279\u5F81\uFF1A\u52D2\u7D22\u4FE1\u4F4D\u7F6E\u5728startup\u76EE\u5F55\uFF0C\u6837\u672C\u4F4D\u7F6E\u5728 %windir%\\system32\u3001startup\u76EE\u5F55\u3001%appdata%\u76EE\u5F55 \u3002

                          Phobos
                          Globelmposter
                              \u653B\u51FB\u76EE\u6807\uFF1A\u4E3B\u8981\u662F\u5F00\u542F\u8FDC\u7A0B\u684C\u9762\u670D\u52A1\u7684\u670D\u52A1\u5668\uFF0C
                                  \u653B\u51FB\u8005\u66B4\u529B\u7834\u89E3\u670D\u52A1\u5668\u5BC6\u7801\uFF0C\u5BF9\u5185\u7F51\u670D\u52A1\u5668\u53D1\u8D77\u626B\u63CF\u5E76\u4EBA\u5DE5\u6295\u653E\u52D2\u7D22\u75C5\u6BD2\uFF0C\u5BFC\u81F4\u6587\u4EF6\u88AB\u52A0\u5BC6\uFF0C\u6682\u65F6\u65E0\u6CD5\u89E3\u5BC6\u3002
                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1Aauchentoshan\u3001RESERVE\u3001\u52A8\u7269\u540D+4444\u3001  \u7B49\u3002
                              \uFF082\uFF09\u4F20\u64AD\u65B9\u6CD5\uFF1ARDP\u66B4\u529B\u7834\u89E3\u3001\u9493\u9C7C\u90AE\u4EF6\u3001\u6346\u7ED1\u8F6F\u4EF6\u7B49\u3002
                              \uFF083\uFF09\u7279\u5F81\uFF1A\u91CA\u653E\u5728%appdata%\u6216%localappdata%\u3002
                          Sodinokibi
                          WannaCry
                              \u901A\u8FC7MS17-010\u6F0F\u6D1E\u5728\u5168\u7403\u8303\u56F4\u4F20\u64AD\u3002
                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1Awncry\u3002
                              \uFF082\uFF09\u4F20\u64AD\u65B9\u6CD5\uFF1A\u201C\u6C38\u6052\u4E4B\u84DD\u201D\u6F0F\u6D1E\u3002
                              \uFF083\uFF09\u7279\u5F81\uFF1A
                                      \u542F\u52A8\u65F6\u4F1A\u8FDE\u63A5\u4E00\u4E2A\u4E0D\u5B58\u5728\u7684URL\uFF08Uniform Resource Locator\uFF0C\u7EDF\u4E00\u8D44\u6E90\u5B9A\u4F4D\u7B26\uFF09\uFF1B
                                      \u521B\u5EFA\u7CFB\u7EDF\u670D\u52A1mssecsvc2.0\uFF1B
                                      \u91CA\u653E\u8DEF\u5F84\u4E3AWindows\u76EE\u5F55\u3002
                          GandCrab
                              \u75C5\u6BD2\u91C7\u7528Salsa20\u548CRSA-2048\u7B97\u6CD5\u5BF9\u6587\u4EF6\u8FDB\u884C\u52A0\u5BC6\uFF0C\u5E76\u5C06\u611F\u67D3\u4E3B\u673A\u684C\u9762\u80CC\u666F\u66FF\u6362\u4E3A\u52D2\u7D22\u4FE1\u606F\u56FE\u7247\u3002
                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1A\u968F\u673A\u751F\u6210\u3002
                              \uFF082\uFF09\u4F20\u64AD\u65B9\u6CD5\uFF1ARDP\u66B4\u529B\u7834\u89E3\u3001\u9493\u9C7C\u90AE\u4EF6\u3001\u6346\u7ED1\u8F6F\u4EF6\u3001\u50F5\u5C38\u7F51\u7EDC\u3001\u6F0F\u6D1E\u4F20\u64AD\u7B49\u3002
                              \uFF083\uFF09\u7279\u5F81\uFF1A\u6837\u672C\u6267\u884C\u5B8C\u6BD5\u540E\u81EA\u52A8\u5220\u9664\uFF0C\u5E76\u4F1A\u4FEE\u6539\u611F\u67D3\u4E3B\u673A\u684C\u9762\u80CC\u666F\uFF0C\u6709\u540E\u7F00MANUAL.txt\u3001DECRYPT.txt\u3002
                          Satan
                              \u9664\u4E86\u901A\u8FC7RDP\u66B4\u529B\u7834\u89E3\uFF0C\u4E00\u822C\u8FD8\u901A\u8FC7\u591A\u4E2A\u6F0F\u6D1E\u4F20\u64AD\u3002

                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1Aevopro\u3001sick\u7B49\u3002
                              \uFF082\uFF09\u4F20\u64AD\u65B9\u6CD5\uFF1A\u201C\u6C38\u6052\u4E4B\u84DD\u201D\u6F0F\u6D1E\u3001RDP\u66B4\u529B\u7834\u89E3\u3001JBoss\u7CFB\u5217\u6F0F\u6D1E\u3001Tomcat\u7CFB\u5217\u6F0F\u6D1E\u3001WebLogic\u7EC4\u4EF6\u6F0F\u6D1E\u7B49\u3002
                              \uFF083\uFF09\u7279\u5F81\uFF1A\u6700\u65B0\u53D8\u79CD\u6682\u65F6\u65E0\u6CD5\u89E3\u5BC6\uFF0C\u4EE5\u524D\u7684\u53D8\u79CD\u53EF\u89E3\u5BC6\u3002
                          SaCrab
                              \u6700\u6D41\u884C\u7684\u4E00\u4E2A\u7248\u672C\u662F\u901A\u8FC7Necurs\u50F5\u5C38\u7F51\u7EDC\u8FDB\u884C\u5206\u53D1
                                  \u4F7F\u7528Visual C\u8BED\u8A00\u7F16\u5199\u800C\u6210\u7684\uFF0C\u8FD8\u53EF\u901A\u8FC7\u9493\u9C7C\u90AE\u4EF6\u548CRDP\u66B4\u529B\u7834\u89E3\u7B49\u65B9\u6CD5\u4F20\u64AD\u3002
                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1Akrab\u3001sacrab\u3001bomber\u3001crash\u7B49\u3002
                              \uFF082\uFF09\u4F20\u64AD\u65B9\u6CD5\uFF1ANecurs\u50F5\u5C38\u7F51\u7EDC\u3001RDP\u66B4\u529B\u7834\u89E3\u3001\u9493\u9C7C\u90AE\u4EF6\u7B49\u3002
                              \uFF083\uFF09\u7279\u5F81\uFF1A\u6837\u672C\u91CA\u653E\u4F4D\u7F6E\u5728 %appdata%\\roaming \u3002
                          Matrix
                              \u8FC7\u5165\u4FB5\u8FDC\u7A0B\u684C\u9762\u8FDB\u884C\u611F\u67D3\u5B89\u88C5
                                  \u653B\u51FB\u8005\u901A\u8FC7\u66B4\u529B\u679A\u4E3E\u76F4\u63A5\u8FDE\u5165\u516C\u7F51\u7684\u8FDC\u7A0B\u684C\u9762\u670D\u52A1\uFF0C\u4ECE\u800C\u5165\u4FB5\u670D\u52A1\u5668
                                      \u83B7\u53D6\u6743\u9650\u540E\u4FBF\u4F1A\u4E0A\u4F20\u8BE5\u52D2\u7D22\u75C5\u6BD2\u8FDB\u884C\u611F\u67D3\u3002

                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1Agrhan\u3001prcp\u3001spct\u3001pedant\u7B49\u3002
                              \uFF082\uFF09\u4F20\u64AD\u65B9\u6CD5\uFF1ARDP\u66B4\u529B\u7834\u89E3\u3002
                          Stop
                              \u901A\u8FC7\u9493\u9C7C\u90AE\u4EF6\u3001\u6346\u7ED1\u8F6F\u4EF6\u3001RDP\u66B4\u529B\u7834\u89E3\u8FDB\u884C\u4F20\u64AD\uFF0C\u6709\u67D0\u4E9B\u7279\u6B8A\u53D8\u79CD\u8FD8\u4F1A\u91CA\u653E\u8FDC\u63A7\u6728\u9A6C\u3002
                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1Atro\u3001djvu\u3001puma\u3001pumas\u3001pumax\u3001djvuq\u7B49\u3002
                              \uFF082\uFF09\u4F20\u64AD\u65B9\u6CD5\uFF1A\u9493\u9C7C\u90AE\u4EF6\u3001\u6346\u7ED1\u8F6F\u4EF6\u548CRDP\u66B4\u529B\u7834\u89E3\u3002
                              \uFF083\uFF09\u7279\u5F81\uFF1A\u6837\u672C\u91CA\u653E\u4F4D\u7F6E\u5728  %appdata%\\local\\<\u968F\u673A\u540D\u79F0>  \uFF0C\u53EF\u80FD\u4F1A\u6267\u884C\u8BA1\u5212\u4EFB\u52A1\u3002
                          Paradise
                              \u5728\u6BCF\u4E2A\u5305\u542B\u52A0\u5BC6\u6587\u4EF6\u7684\u6587\u4EF6\u5939\u4E2D\u90FD\u4F1A\u751F\u6210\u4E00\u5C01\u52D2\u7D22\u4FE1\u3002
                              \u6700\u521D\u7248\u672C\u4F1A\u9644\u52A0\u4E00\u4E2A\u8D85\u957F\u540E\u7F00\u5230\u539F\u6587\u4EF6\u540D\u672B\u5C3E\u3002

                              \uFF081\uFF09\u5E38\u89C1\u540E\u7F00\uFF1A\u6587\u4EF6\u540D_%ID\u5B57\u7B26\u4E32%_{\u52D2\u7D22\u90AE\u7BB1}.\u7279\u5B9A\u540E\u7F00\u3002
                              \uFF082\uFF09\u7279\u5F81\uFF1A\u5C06\u52D2\u7D22\u5F39\u7A97\u548C\u81EA\u8EAB\u91CA\u653E\u5230startup\u542F\u52A8\u76EE\u5F55\u3002


                  \u5DF2\u77E5\u7684\u88AB\u3010\u52D2\u7D22\u75C5\u6BD2\u3011\u5229\u7528\u7684\u3010\u6F0F\u6D1E\u3011\uFF1A
                          123
                          123
                          123
                          \u7565\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026

                  \u89E3\u5BC6\u65B9\u6CD5\uFF1A
                          123

                  \u4F20\u64AD\u65B9\u6CD5\uFF1A
                          123

                  \u9632\u5FA1\u65B9\u6CD5\uFF1A
                          \u4E2A\u4EBA\u7EC8\u7AEF
                                  123

                          \u4F01\u4E1A\u7EA7\u7EC8\u7AEF
                                  123

                `))},{name:"\u5904\u7F6E\u65B9\u6CD5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u9694\u79BB\u88AB\u611F\u67D3\u7684\u670D\u52A1\u5668/\u4E3B\u673A
                        123

                \u6392\u67E5\u4E1A\u52A1\u7CFB\u7EDF
                        123

                \u786E\u5B9A\u52D2\u7D22\u75C5\u6BD2\u79CD\u7C7B\uFF0C\u8FDB\u884C\u6EAF\u6E90\u5206\u6790
                        123

                \u6062\u590D\u6570\u636E\u548C\u4E1A\u52A1
                        123

                \u540E\u7EED\u9632\u62A4\u5EFA\u8BAE
                        123

                `))},{name:"\u5E38\u7528\u5DE5\u5177",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u52D2\u7D22\u75C5\u6BD2\u67E5\u8BE2\u5DE5\u5177
                        123

                \u65E5\u5FD7\u5206\u6790\u5DE5\u5177
                        123

                `))},{name:"\u64CD\u4F5C\u6307\u5357",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u521D\u6B65\u9884\u5224
                        \u5982\u4F55\u5224\u65AD\u906D\u9047\u52D2\u7D22\u75C5\u6BD2\u653B\u51FB
                                \u4E1A\u52A1\u7CFB\u7EDF\u65E0\u6CD5\u8BBF\u95EE
                                \u6587\u4EF6\u540E\u7F00\u88AB\u7BE1\u6539
                                \u52D2\u7D22\u4FE1\u5C55\u793A
                                \u684C\u9762\u6709\u65B0\u7684\u6587\u672C\u6587\u4EF6
                        \u4E86\u89E3\u52D2\u7D22\u75C5\u6BD2\u52A0\u5BC6\u65F6\u95F4
                        \u4E86\u89E3\u201C\u4E2D\u62DB\u201D\u8303\u56F4
                        \u4E86\u89E3\u7CFB\u7EDF\u67B6\u6784
                        \u5178\u578B\u6848\u4F8B
                                123

                \u4E34\u65F6\u5904\u7F6E
                        \u9488\u5BF9\u5DF2\u201C\u4E2D\u62DB\u201D\u670D\u52A1\u5668/\u4E3B\u673A
                                \u7269\u7406\u9694\u79BB
                                \u8BBF\u95EE\u63A7\u5236
                        \u9488\u5BF9\u672A\u201C\u4E2D\u62DB\u201D\u670D\u52A1\u5668/\u4E3B\u673A
                        \u9488\u5BF9\u672A\u660E\u786E\u662F\u5426\u201C\u4E2D\u62DB\u201D\u7684\u670D\u52A1\u5668/\u4E3B\u673A

                \u7CFB\u7EDF\u6392\u67E5
                        \u6587\u4EF6\u6392\u67E5
                                Windows\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                Linux\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                        \u8865\u4E01\u6392\u67E5
                        \u8D26\u6237\u6392\u67E5
                                Windows\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                Linux\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                        \u7F51\u7EDC\u8FDE\u63A5\u3001\u8FDB\u7A0B\u3001\u4EFB\u52A1\u8BA1\u5212\u6392\u67E5
                                Windows\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                        \u67E5\u770B\u53EF\u7591\u7F51\u7EDC\u8FDE\u63A5\u3002
                                        \u67E5\u770B\u53EF\u7591\u8FDB\u7A0B\u3002
                                        \u67E5\u770B\u53EF\u7591\u4EFB\u52A1\u8BA1\u5212\u3002
                                        \u67E5\u770BCPU\u3001\u5185\u5B58\u5360\u7528\u60C5\u51B5\u53CA\u7F51\u7EDC\u4F7F\u7528\u7387\u3002
                                        \u67E5\u770B\u6CE8\u518C\u8868\u3002
                                Linux\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                        \u67E5\u770B\u53EF\u7591\u7F51\u7EDC\u8FDE\u63A5\u548C\u8FDB\u7A0B\u3002
                                        \u67E5\u770BCPU\u3001\u5185\u5B58\u5360\u7528\u60C5\u51B5\u3002
                                        \u67E5\u770B\u7CFB\u7EDF\u4EFB\u52A1\u8BA1\u5212\u3002
                                        \u67E5\u770B\u7528\u6237\u4EFB\u52A1\u8BA1\u5212\u3002
                                        \u67E5\u770B\u5386\u53F2\u6267\u884C\u547D\u4EE4\u3002

                \u65E5\u5FD7\u6392\u67E5
                        Windows\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                \u7CFB\u7EDF\u65E5\u5FD7
                                \u5B89\u5168\u65E5\u5FD7
                        Linux\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                \u67E5\u770B\u6240\u6709\u7528\u6237\u6700\u540E\u767B\u5F55\u4FE1\u606F\u3002
                                \u67E5\u770B\u7528\u6237\u767B\u5F55\u5931\u8D25\u4FE1\u606F\u3002
                                \u67E5\u770B\u7528\u6237\u6700\u8FD1\u767B\u5F55\u4FE1\u606F\u3002

                \u7F51\u7EDC\u6D41\u91CF\u6392\u67E5
                        \uFF08\u5F53\u73B0\u573A\u90E8\u7F72\u4E86\u7F51\u7EDC\u5B89\u5168\u8BBE\u5907\u65F6\uFF0C\u53EF\u4EE5\u901A\u8FC7\u7F51\u7EDC\u6D41\u91CF\u6392\u67E5\u5206\u6790\u4EE5\u4E0B\u5185\u5BB9\uFF09

                        \uFF081\uFF09\u5206\u6790\u5185\u7F51\u662F\u5426\u6709\u9488\u5BF9445\u7AEF\u53E3\u7684\u626B\u63CF\u548CMS17-010\u6F0F\u6D1E\u7684\u5229\u7528\u3002
                        \uFF082\uFF09\u5206\u6790\u6EAF\u6E90\u52D2\u7D22\u7EC8\u7AEF\u88AB\u5165\u4FB5\u7684\u8FC7\u7A0B\u3002
                        \uFF083\uFF09\u5206\u6790\u90AE\u4EF6\u9644\u4EF6MD5\u503C\u5339\u914D\u5A01\u80C1\u60C5\u62A5\u7684\u6570\u636E\uFF0C\u5224\u5B9A\u662F\u5426\u4E3A\u52D2\u7D22\u75C5\u6BD2\u3002
                        \uFF084\uFF09\u5206\u6790\u5728\u7F51\u7EDC\u4E2D\u4F20\u64AD\u7684\u6587\u4EF6\u662F\u5426\u88AB\u4E8C\u6B21\u6253\u5305\uFF0C\u8FDB\u884C\u690D\u5165\u5F0F\u653B\u51FB\u3002
                        \uFF085\uFF09\u5206\u6790\u5728\u6B63\u5E38\u7F51\u9875\u4E2D\u690D\u5165\u6728\u9A6C\uFF0C\u8BA9\u8BBF\u95EE\u8005\u5728\u6D4F\u89C8\u7F51\u9875\u65F6\u5229\u7528IE\u6D4F\u89C8\u5668\u6216Flash\u7B49\u8F6F\u4EF6\u6F0F\u6D1E\u5B9E\u65BD\u653B\u51FB\u7684\u60C5\u51B5\u3002

                \u6E05\u9664\u52A0\u56FA
                        \u75C5\u6BD2\u6E05\u7406\u53CA\u52A0\u56FA
                                \uFF081\uFF09\u5728\u7F51\u7EDC\u8FB9\u754C\u9632\u706B\u5899\u4E0A\u5168\u5C40\u5173\u95ED3389\u7AEF\u53E3\uFF0C\u62163389\u7AEF\u53E3\u53EA\u5BF9\u7279\u5B9AIP\u5730\u5740\u5F00\u653E\u3002
                                \uFF082\uFF09\u5F00\u542FWindows\u9632\u706B\u5899\uFF0C\u5C3D\u91CF\u5173\u95ED3389\u3001445\u3001139\u3001135\u7B49\u4E0D\u7528\u7684\u9AD8\u5371\u7AEF\u53E3\u3002
                                \uFF083\uFF09\u6BCF\u53F0\u673A\u5668\u8BBE\u7F6E\u552F\u4E00\u767B\u5F55\u5BC6\u7801\uFF0C\u4E14\u5BC6\u7801\u5E94\u4E3A\u9AD8\u5F3A\u5EA6\u7684\u590D\u6742\u5BC6\u7801\uFF0C\u4E00\u822C\u8981\u6C42\u91C7\u7528\u5927\u5C0F\u5199\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u7279\u6B8A\u7B26\u53F7\u6DF7\u5408\u7684\u7EC4\u5408\u7ED3\u6784\uFF0C\u5BC6\u7801\u4F4D\u6570\u8981\u8DB3\u591F\u957F\uFF0815\u4F4D\u3001\u4E24\u79CD\u7EC4\u5408\u4EE5\u4E0A\uFF09\u3002
                                \uFF084\uFF09\u5B89\u88C5\u6700\u65B0\u6740\u6BD2\u8F6F\u4EF6\uFF0C\u5BF9\u88AB\u611F\u67D3\u673A\u5668\u8FDB\u884C\u5B89\u5168\u626B\u63CF\u548C\u75C5\u6BD2\u67E5\u6740\u3002
                                \uFF085\uFF09\u5BF9\u7CFB\u7EDF\u8FDB\u884C\u8865\u4E01\u66F4\u65B0\uFF0C\u5C01\u5835\u75C5\u6BD2\u4F20\u64AD\u9014\u5F84\u3002
                                \uFF086\uFF09\u7ED3\u5408\u5907\u4EFD\u7684\u7F51\u7AD9\u65E5\u5FD7\u5BF9\u7F51\u7AD9\u5E94\u7528\u8FDB\u884C\u5168\u9762\u4EE3\u7801\u5BA1\u8BA1\uFF0C\u627E\u51FA\u653B\u51FB\u8005\u5229\u7528\u7684\u6F0F\u6D1E\u5165\u53E3\uFF0C\u8FDB\u884C\u5C01\u5835\u3002
                                \uFF087\uFF09\u4F7F\u7528\u5168\u6D41\u91CF\u8BBE\u5907\uFF08\u5982\u5929\u773C\uFF09\u5BF9\u5168\u7F51\u4E2D\u5B58\u5728\u7684\u5A01\u80C1\u8FDB\u884C\u5206\u6790\uFF0C\u6392\u67E5\u95EE\u9898\u3002
                        \u611F\u67D3\u6587\u4EF6\u6062\u590D
                                \uFF081\uFF09\u901A\u8FC7\u89E3\u5BC6\u5DE5\u5177\u6062\u590D\u611F\u67D3\u6587\u4EF6\u3002
                                \uFF082\uFF09\u652F\u4ED8\u8D4E\u91D1\u8FDB\u884C\u6587\u4EF6\u6062\u590D\u3002
                                \uFF083\uFF09\u540E\u7EED\u9632\u62A4\uFF08\u8BE6\u89C14.2.5\u8282\uFF09\u3002


                `))},{name:"\u5178\u578B\u6848\u4F8B",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`
                \u4E8B\u4EF6\u80CC\u666F
                        123
                \u4E8B\u4EF6\u5904\u7F6E
                        \u52D2\u7D22\u75C5\u6BD2\u5224\u5B9A
                        \u7CFB\u7EDF\u6392\u67E5
                        \u65E5\u5FD7\u5206\u6790
                        \u603B\u4F53\u7ED3\u8BBA
                \u4E8B\u4EF6\u6291\u5236
                        123
                \u6839\u9664\u53CA\u6062\u590D
                        123
                `))}]},{name:"\u8815\u866B\u3001\u6316\u77FF\u6728\u9A6C",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u57FA\u672C\u4ECB\u7ECD",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                      \u7279\u70B9\uFF1A
                              CPU\u5360\u7528\u7387\u9AD8\u3002
                              \u4F20\u64AD\u65B9\u5F0F\uFF1A
                                  \u4EE5\u3010\u5185\u7F51\u6F0F\u6D1E\u3011\u53CA\u3010\u7206\u7834\u3011\u7684\u65B9\u5F0F\uFF0C\u8FDB\u884C\u4F20\u64AD\u3002

                              \u5E26\u3010\u8815\u866B\u75C5\u6BD2\u3011\u7684\u7C7B\u578B\u3002

                      `))},{name:"\u5E38\u89C1\u6316\u77FF\u6728\u9A6C\uFF0C\u5217\u8868",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u6982\u8FF0",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                    \u5E38\u89C1\u7684\u6316\u77FF\u6728\u9A6C\uFF1A
                            WannaMine
                                \u4E3B\u8981\u9488\u5BF9\u642D\u5EFAWebLogic\u7684\u670D\u52A1\u5668\uFF0C\u4E5F\u653B\u51FBPHPMyadmin\u3001Drupal\u7B49Web\u5E94\u7528\u3002
                                WannaMine\u5C06\u67D3\u6BD2\u673A\u5668\u7528\u201C\u65E0\u6587\u4EF6\u201D\u653B\u51FB\u65B9\u6CD5\u6784\u5EFA\u4E00\u4E2A\u5065\u58EE\u7684\u50F5\u5C38\u7F51\u7EDC\uFF0C\u5E76\u4E14\u652F\u6301\u5185\u7F51\u81EA\u66F4\u65B0\u3002
                                WannaMine\u901A\u8FC7WMI\u7C7B\u5C5E\u6027\u5B58\u50A8shellcode\uFF0C\u5E76\u4F7F\u7528\u201C\u6C38\u6052\u4E4B\u84DD\u201D\u6F0F\u6D1E\u653B\u51FB\u6B66\u5668\u53CA\u201CMimikatz+WMIExec\u201D\u653B\u51FB\u7EC4\u4EF6\uFF0C\u5728\u540C\u4E00\u5C40\u57DF\u7F51\u8FDB\u884C\u6A2A\u5411\u6E17\u900F\uFF0C\u4EE5\u9690\u85CF\u5176\u6076\u610F\u884C\u4E3A\u3002
                                \u6700\u65B0\u53D8\u52A8
                                    2018\u5E746\u6708\uFF0CWannaMine\u589E\u52A0\u4E86DDoS\u6A21\u5757\uFF0C\u6539\u53D8\u4E86\u4EE5\u5F80\u7684\u4EE3\u7801\u98CE\u683C\u548C\u653B\u51FB\u624B\u6CD5\u3002
                                    2019\u5E744\u6708\uFF0CWannaMine\u820D\u5F03\u4E86\u539F\u6709\u7684\u9690\u85CF\u7B56\u7565\uFF0C\u542F\u7528\u65B0\u7684C2\u5730\u5740\u5B58\u653E\u6076\u610F\u4EE3\u7801\uFF0C\u91C7\u7528PowerShell\u5185\u5B58\u6CE8\u5165\u6267\u884C\u6316\u77FF\u7A0B\u5E8F\u548C\u91CA\u653EPE\u6728\u9A6C\u6316\u77FF\u7684\u65B9\u6CD5\u8FDB\u884C\u6316\u77FF\uFF0C\u589E\u5927\u4E86\u6316\u77FF\u7A0B\u5E8F\u6267\u884C\u6210\u529F\u7684\u6982\u7387\u3002
                            Mykings\uFF08\u9690\u533F\u8005\uFF09
                                Mykings\u4E3B\u8981\u5229\u7528\u201C\u6C38\u6052\u4E4B\u84DD\u201D\u6F0F\u6D1E\uFF0C\u9488\u5BF9MsSQL\u3001Telnet\u3001RDP\u3001CCTV\u7B49\u7CFB\u7EDF\u7EC4\u4EF6\u6216\u8BBE\u5907\u8FDB\u884C\u5BC6\u7801\u66B4\u529B\u7834\u89E3\u3002
                                    \u66B4\u529B\u7834\u89E3\u6210\u529F\u540E\uFF0C\u5229\u7528\u626B\u63CF\u653B\u51FB\u8FDB\u884C\u8815\u866B\u5F0F\u4F20\u64AD\u3002
                            BuleHero
                                \u4E13\u6CE8\u4E8E\u653B\u51FBWindows\u670D\u52A1\u5668
                                Bulehero\u4E0D\u4EC5\u4F7F\u7528\u5F31\u5BC6\u7801\u66B4\u529B\u7834\u89E3\uFF0C\u5E76\u4E14\u5229\u7528\u591A\u4E2A\u670D\u52A1\u5668\u7EC4\u4EF6\u6F0F\u6D1E\u8FDB\u884C\u653B\u51FB
                                    \u653B\u51FB\u4E3B\u8981\u5206\u4E3AWindows\u7CFB\u7EDF\u6F0F\u6D1E\u3001Web\u7EC4\u4EF6\u6F0F\u6D1E\u3001\u5404\u7C7B\u5F31\u5BC6\u7801\u66B4\u529B\u7834\u89E3\u653B\u51FB\u4E09\u79CD\u7C7B\u578B\u3002
                            8220Miner
                                \u56E0\u56FA\u5B9A\u4F7F\u75288220\u7AEF\u53E3\u800C\u88AB\u547D\u540D\u3002
                                \u5229\u7528\u591A\u4E2A\u6F0F\u6D1E\u8FDB\u884C\u653B\u51FB\u548C\u90E8\u7F72\u6316\u77FF\u7A0B\u5E8F
                                    \u6700\u65E9\u4F7F\u7528Hadoop Yarn\u672A\u6388\u6743\u8BBF\u95EE\u6F0F\u6D1E\u653B\u51FB\u7684\u6316\u77FF\u6728\u9A6C
                                    \u9664\u6B64\u4E4B\u5916\uFF0C\u5176\u8FD8\u4F7F\u7528\u4E86\u591A\u79CD\u5176\u4ED6\u7684Web\u670D\u52A1\u6F0F\u6D1E\u3002
                                8220Miner\u5E76\u672A\u91C7\u7528\u8815\u866B\u5F0F\u4F20\u64AD\uFF0C\u800C\u662F\u4F7F\u7528\u56FA\u5B9A\u7684\u4E00\u7EC4IP\u5730\u5740\u8FDB\u884C\u5168\u7F51\u653B\u51FB\u3002
                                \u4E3A\u4E86\u66F4\u6301\u4E45\u7684\u9A7B\u7559\u4E3B\u673A\uFF0C\u4EE5\u83B7\u5F97\u6700\u5927\u6536\u76CA\uFF0C\u5176\u4F7F\u7528rootkit\u6280\u672F\u8FDB\u884C\u81EA\u6211\u9690\u85CF\u3002
                            \u533F\u5F71\u6316\u77FF\u6728\u9A6C
                                \u4E00\u79CD\u643A\u5E26NSA\u5168\u5957\u6B66\u5668\u5E93\u7684\u65B0\u53D8\u79CD\u6316\u77FF\u6728\u9A6C\u201C\u533F\u5F71\u201D
                                    \uFF08\u66FE\u7ECF\u7684\u3010\u9707\u7F51\u3011\u3001\u3010\u6C38\u6052\u4E4B\u84DD\u3011\uFF0C\u90FD\u662F\u8FD9\u5957\u6B66\u5668\u5E93\u7684\u6210\u5458\uFF09
                                \u8BE5\u6316\u77FF\u6728\u9A6C\u5927\u8086\u5229\u7528\u529F\u80FD\u7F51\u76D8\u548C\u56FE\u5E8A\u9690\u85CF\u81EA\u5DF1\uFF0C\u5728\u5C40\u57DF\u7F51\u4E2D\u5229\u7528\u201C\u6C38\u6052\u4E4B\u84DD\u201D\u548C\u201C\u53CC\u8109\u51B2\u661F\u201D\u7B49\u6F0F\u6D1E\u8FDB\u884C\u6A2A\u5411\u4F20\u64AD
                                \u66F4\u65B0\u8FC7\u7A0B\uFF1A
                                    \u8BE5\u6316\u77FF\u6728\u9A6C\u88AB\u53D1\u73B0\u4EE5\u6765\uFF0C\u5176\u8FDB\u884C\u4E0D\u65AD\u66F4\u65B0
                                        \u589E\u52A0\u4E86\u6316\u77FF\u5E01\u79CD\u3001\u94B1\u5305ID\u3001\u77FF\u6C60\u3001\u5B89\u88C5\u6D41\u7A0B\u3001\u4EE3\u7406\u7B49\u57FA\u7840\u8BBE\u65BD
                                        \u7B80\u5316\u4E86\u653B\u51FB\u6D41\u7A0B
                                        \u542F\u7528\u4E86\u6700\u65B0\u7684\u6316\u77FF\u8D26\u6237\uFF0C\u540C\u65F6\u6316\u6398PASC\u5E01\u3001\u95E8\u7F57\u5E01\u7B49\u591A\u79CD\u6570\u5B57\u52A0\u5BC6\u8D27\u5E01\u3002
                            DDG
                                \u4E00\u4E2ALinux\u7CFB\u7EDF\u4E0B\u7528go\u8BED\u8A00\u5B9E\u73B0\u7684\u6316\u77FF\u6728\u9A6C
                                    DDG\u5229\u7528Orientdb\u6F0F\u6D1E\u3001Redis\u672A\u6388\u6743\u8BBF\u95EE\u6F0F\u6D1E\u3001SSH\u5F31\u5BC6\u7801\u8FDB\u884C\u5165\u4FB5
                                \u5165\u4FB5\u4E3B\u673A\u540E\u4F1A\u4E0B\u8F7D\u3010i.sh\u3011\u7684\u6076\u610F\u811A\u672C\u548C\u3010DDG\u6076\u610F\u7A0B\u5E8F\u3011\uFF0C\u7136\u540E\u542F\u52A8\u3010disable.sh\u3011\u811A\u672C\u6E05\u7406\u5176\u4ED6\u6316\u77FF\u7A0B\u5E8F
                                    \u5728\u4E0E\u653B\u51FB\u8005\u63A7\u5236\u7684\u4E2D\u63A7\u670D\u52A1\u5668\u901A\u4FE1\u540E\uFF0C\u542F\u52A8\u6316\u77FF\u7A0B\u5E8F\uFF0C\u6316\u6398\u95E8\u7F57\u5E01\u7B49\u83B7\u5229\u3002

                            h2Miner
                                \u4E00\u4E2ALinux\u7CFB\u7EDF\u4E0B\u7684\u6316\u77FF\u6728\u9A6C\uFF0C\u5176\u4EE5\u6076\u610Fshell\u811A\u672C\u3010h2.sh\u3011\u8FDB\u884C\u547D\u540D
                                \u5229\u7528Redis\u672A\u6388\u6743\u8BBF\u95EE\u6F0F\u6D1E\u6216SSH\u5F31\u5BC6\u7801\u4F5C\u4E3A\u66B4\u529B\u7834\u89E3\u5165\u53E3
                                    \u540C\u65F6\u5229\u7528\u591A\u79CDWeb\u670D\u52A1\u6F0F\u6D1E\u8FDB\u884C\u653B\u51FB
                                \u4F7F\u7528\u4E3B\u4ECE\u540C\u6B65\u7684\u65B9\u6CD5\u4ECE\u6076\u610F\u670D\u52A1\u5668\u4E0A\u540C\u6B65\u6076\u610Fmodule\uFF0C
                                    \u4E4B\u540E\u5728\u76EE\u6807\u673A\u5668\u4E0A\u52A0\u8F7D\u6B64\u6076\u610Fmodule\uFF0C\u5E76\u6267\u884C\u6076\u610F\u6307\u4EE4
                            MinerGuard
                                \u4E0EDDG\u4E00\u6837\u662F\u7531go\u8BED\u8A00\u5B9E\u73B0\u7684\u6316\u77FF\u6728\u9A6C
                                    \u4F46\u4E0D\u540C\u7684\u662F\u5B83\u53EF\u8DE8Windows\u548CLinux\u4E24\u4E2A\u5E73\u53F0\u8FDB\u884C\u4EA4\u53C9\u611F\u67D3
                                \u5229\u7528Redis\u672A\u6388\u6743\u8BBF\u95EE\u6F0F\u6D1E\u3001SSH\u5F31\u5BC6\u7801\u3001\u591A\u79CDWeb\u670D\u52A1\u6F0F\u6D1E\u8FDB\u884C\u5165\u4FB5
                                    \u6210\u529F\u5165\u4FB5\u4E3B\u673A\u540E\u4F1A\u8FD0\u884C\u95E8\u7F57\u5E01\u6316\u77FF\u7A0B\u5E8F\uFF0C
                                        \u5E76\u4E14\u901A\u8FC7\u591A\u4E2A\u7F51\u7EDC\u670D\u52A1\u5668\u6F0F\u6D1E\u53CA\u66B4\u529B\u7834\u89E3\u670D\u52A1\u5668\u7684\u65B9\u6CD5\u4F20\u64AD
                                \u653B\u51FB\u8005\u53EF\u4EE5\u968F\u65F6\u901A\u8FC7\u8FDC\u7A0B\u670D\u52A1\u5668\u4E3AMinerGuard\u53D1\u9001\u65B0\u7684\u75C5\u6BD2\u6A21\u5757
                                \u4E14\u901A\u8FC7\u4EE5\u592A\u574A\u94B1\u5305\u66F4\u65B0\u75C5\u6BD2\u670D\u52A1\u5668\u5730\u5740\u3002
                            KWorkerDs
                                \u4E00\u4E2A\u8DE8Windows\u548CLinux\u5E73\u53F0\u7684\u6316\u77FF\u6728\u9A6C
                                \u6700\u5927\u7684\u7279\u70B9\u662F\u901A\u8FC7\u52AB\u6301\u52A8\u6001\u94FE\u63A5\u5E93\u690D\u5165rootkit\u540E\u95E8
                                \u4E3B\u8981\u5229\u7528Redis\u672A\u6388\u6743\u8BBF\u95EE\u6F0F\u6D1E\u3001SSH\u5F31\u5BC6\u7801\u3001WebLogic\u8FDC\u7A0B\u4EE3\u7801\u6267\u884C\u7B49\u8FDB\u884C\u5165\u4FB5

                                \u5165\u4FB5\u540E\u4E0B\u8F7Dmr.sh/2mr.sh\u6076\u610F\u811A\u672C\u8FD0\u884C\uFF0C\u690D\u5165\u6316\u77FF\u7A0B\u5E8F

                            WatchDogs
                                Watchdogs\u5229\u7528SSH\u5F31\u5BC6\u7801\u3001WebLogic\u8FDC\u7A0B\u4EE3\u7801\u6267\u884C\u3001Jenkins\u6F0F\u6D1E\u3001ActiveMQ\u6F0F\u6D1E\u7B49\u8FDB\u884C\u5165\u4FB5
                                    \u8FD8\u5229\u7528\u65B0\u516C\u5F00\u7684Confluence RCE\u6F0F\u6D1E\u5927\u8086\u4F20\u64AD
                                \u5305\u542B\u81EA\u5B9A\u4E49\u7248\u672C\u7684UPX\u52A0\u58F3\u7A0B\u5E8F\uFF0C\u4F1A\u5C1D\u8BD5\u83B7\u53D6root\u6743\u9650\uFF0C\u8FDB\u884C\u9690\u85CF



                    \u6316\u77FF\u6728\u9A6C\u7684\u4F20\u64AD\u65B9\u6CD5
                            \u5229\u7528\u6F0F\u6D1E\u4F20\u64AD
                            \u901A\u8FC7\u5F31\u5BC6\u7801\u66B4\u529B\u7834\u89E3\u4F20\u64AD
                            \u901A\u8FC7\u50F5\u5C38\u7F51\u7EDC\u4F20\u64AD
                            \u91C7\u7528\u65E0\u6587\u4EF6\u653B\u51FB\u65B9\u6CD5\u4F20\u64AD
                            \u5229\u7528\u7F51\u9875\u6302\u9A6C\u4F20\u64AD
                            \u5229\u7528\u8F6F\u4EF6\u4F9B\u5E94\u94FE\u653B\u51FB\u4F20\u64AD
                            \u5229\u7528\u793E\u4EA4\u8F6F\u4EF6\u3001\u90AE\u4EF6\u4F20\u64AD
                            \u5185\u90E8\u4EBA\u5458\u79C1\u81EA\u5B89\u88C5\u548C\u8FD0\u884C\u6316\u77FF\u7A0B\u5E8F


                    \u7ECF\u5E38\u88AB\u3010\u6316\u77FF\u6728\u9A6C\u3011\u5229\u7528\u7684\u6F0F\u6D1E


                            Windows\u5E73\u53F0\u6F0F\u6D1E
                                    WebLogic
                                        CVE-2017-3248
                                        CVE-2017-10271
                                        CVE-2018-2628
                                        CVE-2018-2894
                                    Drupal
                                        CVE-2018-7600
                                        CVE-2018-7602
                                    Struts2
                                        CVE-2017-5638
                                        CVE-2017-9805
                                        CVE-2018-11776
                                    ThinkPHP
                                        v3 GetShell
                                        v5 GetShell
                                    WindowsServer
                                        \u5F31\u53E3\u4EE4\u7206\u7834
                                        CVE-2017-0143
                                    PhpStudy
                                        \u5F31\u53E3\u4EE4\u7206\u7834
                                        PhpStudy\u540E\u95E8\u6F0F\u6D1E
                                    PhpMyAdmin
                                        \u5F31\u53E3\u4EE4\u7206\u7834
                                    MySQL
                                        \u5F31\u53E3\u4EE4\u7206\u7834
                                    SpringDataCommons
                                        CVE-2018-1273
                                    Tomcat
                                        \u5F31\u53E3\u4EE4\u7206\u7834
                                        CVE-2017-13615
                                    MsSQL
                                        \u5F31\u53E3\u4EE4\u7206\u7834
                                    Jenkins
                                        CVE-2019-1003000\uFF0CRCE\u6F0F\u6D1E
                                    JBoss
                                        CVE-2010-0738
                                        CVE-2017-12149

                            \u7B2C\u4E09\u65B9\u7EC4\u4EF6\u6F0F\u6D1E
                                    Docker
                                        Docker\u672A\u6388\u6743\u6F0F\u6D1E

                                        Docker\u9003\u9038
                                                CVE-2016-5195
                                                CVE-2019-5736

                                                \u914D\u7F6E\u4E0D\u5F53\u5F15\u53D1
                                                    Emote Api   \u672A\u6388\u6743\u8BBF\u95EE
                                                    Docker.Sock \u6302\u8F7D\u5230\u5BB9\u5668\u5185\u90E8
                                                    \u7279\u6743\u6A21\u5F0F

                                    Nexus Repository
                                        Nexus Repository Manager 3 \u8FDC\u7A0B\u4EE3\u7801\u6267\u884C

                                    ElasticSearch
                                        ElasticSearch \u672A\u6388\u6743\u6F0F\u6D1E

                                    Hadoop Yarn
                                        Hadoop Yarn REST API \u672A\u6388\u6743\u6F0F\u6D1E

                                    Kubernetes
                                        Kubernetes API Server \u672A\u6388\u6743\u6F0F\u6D1E

                                    Jenkins
                                        \u4F3C\u4E4E\u548C\u4E0A\u9762\u91CD\u590D\u4E86\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F

                                    Spark
                                        Spark REST API \u672A\u6388\u6743\u6F0F\u6D1E



                    `))}]},{name:"\u5904\u7F6E\u65B9\u6CD5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u9694\u79BB\u88AB\u611F\u67D3\u7684\u670D\u52A1\u5668/\u4E3B\u673A

                \u786E\u8BA4\u6316\u77FF\u8FDB\u7A0B

                \u6316\u77FF\u6728\u9A6C\u6E05\u9664
                        \u963B\u65AD\u77FF\u6C60\u5730\u5740\u7684\u8FDE\u63A5

                        \u6E05\u9664\u6316\u77FF\u5B9A\u65F6\u4EFB\u52A1\u3001\u542F\u52A8\u9879\u7B49

                        \u5B9A\u4F4D\u6316\u77FF\u6728\u9A6C\u6587\u4EF6\u7684\u4F4D\u7F6E\u5E76\u5220\u9664

                \u6316\u77FF\u6728\u9A6C\u9632\u8303
                        \u6316\u77FF\u6728\u9A6C\u50F5\u5C38\u7F51\u7EDC\u7684\u9632\u8303
                                \u907F\u514D\u4F7F\u7528\u5F31\u5BC6\u7801
                                \u53CA\u65F6\u6253\u8865\u4E01
                                \u670D\u52A1\u5668\u5B9A\u671F\u7EF4\u62A4
                        \u7F51\u9875/\u5BA2\u6237\u7AEF\u6316\u77FF\u6728\u9A6C\u7684\u9632\u8303
                                \u6D4F\u89C8\u7F51\u9875\u6216\u542F\u52A8\u5BA2\u6237\u7AEF\u65F6\u6CE8\u610FCPU/GPU\u7684\u4F7F\u7528\u7387
                                \u907F\u514D\u8BBF\u95EE\u88AB\u6807\u8BB0\u4E3A\u9AD8\u98CE\u9669\u7684\u7F51\u7AD9
                                \u907F\u514D\u4E0B\u8F7D\u6765\u6E90\u4E0D\u660E\u7684\u5BA2\u6237\u7AEF\u548C\u5916\u6302\u7B49\u8F85\u52A9\u8F6F\u4EF6

                `))},{name:"\u5E38\u7528\u5DE5\u5177",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`
                ProcessExplorer

                PCHunter
                        \u597D\u5904\u548C\u5F0A\u7AEF


                `))},{name:"\u64CD\u4F5C\u6307\u5357",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`


                \u5176\u5B83\u7684\u4E00\u4E9B\u3001\u6682\u672A\u5F52\u7C7B\u7684\u3001\u96F6\u6563\u7684\uFF1A

                          Windows\u5E73\u53F0
                                  1.\u6392\u67E5\u8D26\u53F7
                                      lusrmgr.msc
                                      net  user

                                  2.\u67E5\u6CE8\u518C\u8868
                                      HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run
                                      HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run
                                      HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce

                          Linux\u5E73\u53F0
                                  123




                \u521D\u6B65\u9884\u5224
                        \u5982\u4F55\u5224\u65AD\u906D\u9047\u6316\u77FF\u6728\u9A6C
                                \uFF081\uFF09\u88AB\u690D\u5165\u6316\u77FF\u6728\u9A6C\u7684\u8BA1\u7B97\u673A\u4F1A\u51FA\u73B0CPU\u4F7F\u7528\u7387\u98D9\u5347\u3001\u7CFB\u7EDF\u5361\u987F\u3001\u90E8\u5206\u670D\u52A1\u65E0\u6CD5\u6B63\u5E38\u8FD0\u884C\u7B49\u73B0\u8C61\u3002
                                \uFF082\uFF09\u901A\u8FC7\u670D\u52A1\u5668\u6027\u80FD\u76D1\u6D4B\u8BBE\u5907\u67E5\u770B\u670D\u52A1\u5668\u6027\u80FD\uFF0C\u4ECE\u800C\u5224\u65AD\u5F02\u5E38\u3002
                                \uFF083\uFF09\u6316\u77FF\u6728\u9A6C\u4F1A\u4E0E\u77FF\u6C60\u5730\u5740\u5EFA\u7ACB\u8FDE\u63A5\uFF0C\u53EF\u901A\u8FC7\u67E5\u770B\u5B89\u5168\u76D1\u6D4B\u7C7B\u8BBE\u5907\u544A\u8B66\u5224\u65AD\u3002
                        \u5224\u65AD\u6316\u77FF\u6728\u9A6C\u6316\u77FF\u65F6\u95F4
                                \uFF081\uFF09\u67E5\u770B\u6316\u77FF\u6728\u9A6C\u6587\u4EF6\u521B\u5EFA\u65F6\u95F4\u3002
                                \uFF082\uFF09\u67E5\u770B\u4EFB\u52A1\u8BA1\u5212\u521B\u5EFA\u65F6\u95F4\u3002
                                \uFF083\uFF09\u67E5\u770B\u77FF\u6C60\u5730\u5740\u3002
                        \u5224\u65AD\u6316\u77FF\u6728\u9A6C\u4F20\u64AD\u8303\u56F4
                                \u6316\u77FF\u6728\u9A6C\u4F1A\u4E0E\u77FF\u6C60\u5730\u5740\u5EFA\u7ACB\u8FDE\u63A5\uFF0C\u53EF\u4EE5\u5229\u7528\u5B89\u5168\u76D1\u6D4B\u7C7B\u8BBE\u5907\u67E5\u770B\u6316\u77FF\u8303\u56F4\u3002
                        \u4E86\u89E3\u7F51\u7EDC\u90E8\u7F72\u73AF\u5883
                                123
                        \u5178\u578B\u6848\u4F8B
                                123

                \u7CFB\u7EDF\u6392\u67E5
                        Windows\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                \u68C0\u67E5\u7528\u6237\u4FE1\u606F
                                        123
                                \u68C0\u67E5\u7F51\u7EDC\u8FDE\u63A5\u3001\u8FDB\u7A0B\u3001\u670D\u52A1\u3001\u4EFB\u52A1\u8BA1\u5212
                                        \u7F51\u7EDC\u8FDE\u63A5\u6392\u67E5
                                            TCPView
                                        \u8FDB\u7A0B\u6392\u67E5
                                            PCHunter
                                        \u4EFB\u52A1\u8BA1\u5212\u6392\u67E5\u3001\u670D\u52A1\u6392\u67E5
                                                123
                        Linux\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                \u68C0\u67E5\u7528\u6237\u4FE1\u606F
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u4E00\u4E9B\u547D\u4EE4
                                \u68C0\u67E5\u8FDB\u7A0B
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u4E00\u4E9B\u547D\u4EE4

                \u65E5\u5FD7\u6392\u67E5
                        Windows\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                \u7CFB\u7EDF\u65E5\u5FD7\uFF0C\u4E4B\u7C7B
                                LogParser
                                \u7B49\u7B49\u5176\u5B83\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026
                        Linux\u7CFB\u7EDF\u6392\u67E5\u65B9\u6CD5
                                \u67E5\u770B\u4EFB\u52A1\u8BA1\u5212\u65E5\u5FD7
                                \u67E5\u770B\u81EA\u542F\u52A8\u65E5\u5FD7

                \u6E05\u9664\u52A0\u56FA
                        \u5C01\u5835\u77FF\u6C60\u5730\u5740

                        \u6E05\u7406\u4EFB\u52A1\u8BA1\u5212\u3001\u7981\u7528\u53EF\u7591\u7528\u6237

                        \u7ED3\u675F\u5F02\u5E38\u8FDB\u7A0B

                        \u6E05\u9664\u6316\u77FF\u6728\u9A6C

                        \u5168\u76D8\u6740\u6BD2\u3001\u52A0\u56FA



                `))},{name:"\u5178\u578B\u6848\u4F8B",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u4E8B\u4EF6\u80CC\u666F\uFF1A

                \u4E8B\u4EF6\u5904\u7F6E\uFF1A
                        \u7CFB\u7EDF\u5206\u6790

                        \u65E5\u5FD7\u5206\u6790

                        \u95EE\u9898\u603B\u7ED3

                \u4E8B\u4EF6\u6291\u5236
                        123

                \u6839\u9664\u53CA\u6062\u590D
                        123



                `))}]},{name:"WebShell",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u6982\u8FF0",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                Webshell\u5206\u7C7B
                        JSP\u578BWebshell\u811A\u672C
                        ASP\u578BWebshell\u811A\u672C
                        PHP\u578BWebshell\u811A\u672C

                Webshell\u7528\u9014
                        \uFF08\u539F\u59CB\u7528\u9014\uFF09\u7AD9\u957F\u5DE5\u5177
                        \u6301\u7EED\u8FDC\u7A0B\u63A7\u5236
                        \uFF08\u6709\u4E9B\u65F6\u5019\u53EF\u4EE5\uFF09\u6743\u9650\u63D0\u5347
                        \uFF08\u76F8\u6BD4\u5176\u5B83\uFF09\u6781\u5F3A\u7684\u9690\u853D\u6027

                Webshell\u68C0\u6D4B\u65B9\u6CD5
                        \u57FA\u4E8E\u6D41\u91CF\u7684Webshell\u68C0\u6D4B
                                \u57FA\u4E8E\u6D41\u91CF\u7684Webshell\u68C0\u6D4B\u65B9\u4FBF\u90E8\u7F72\uFF0C\u6211\u4EEC\u53EF\u901A\u8FC7\u6D41\u91CF\u955C\u50CF\u76F4\u63A5\u5206\u6790\u539F\u59CB\u4FE1\u606F\u3002
                                \u57FA\u4E8Epayload\u7684\u884C\u4E3A\u5206\u6790\uFF0C\u6211\u4EEC\u4E0D\u4EC5\u53EF\u5BF9\u5DF2\u77E5\u7684Webshell\u8FDB\u884C\u68C0\u6D4B\uFF0C\u8FD8\u53EF\u8BC6\u522B\u51FA\u672A\u77E5\u7684\u3001\u4F2A\u88C5\u6027\u5F3A\u7684Webshell\uFF0C\u5BF9Webshell\u7684\u8BBF\u95EE\u7279\u5F81\uFF08IP/UA/Cookie\uFF09\u3001payload\u7279\u5F81\u3001path\u7279\u5F81\u3001\u65F6\u95F4\u7279\u5F81\u7B49\u8FDB\u884C\u5173\u8054\u5206\u6790\uFF0C\u4EE5\u65F6\u95F4\u4E3A\u7D22\u5F15\uFF0C\u53EF\u8FD8\u539F\u653B\u51FB\u4E8B\u4EF6\u3002

                        \u57FA\u4E8E\u6587\u4EF6\u7684Webshell\u68C0\u6D4B
                                \u6211\u4EEC\u901A\u8FC7\u68C0\u6D4B\u6587\u4EF6\u662F\u5426\u52A0\u5BC6\uFF08\u6DF7\u6DC6\u5904\u7406\uFF09\uFF0C\u521B\u5EFAWebshell\u6837\u672Chash\u5E93\uFF0C\u53EF\u5BF9\u6BD4\u5206\u6790\u53EF\u7591\u6587\u4EF6\u3002
                                \u5BF9\u6587\u4EF6\u7684\u521B\u5EFA\u65F6\u95F4\u3001\u4FEE\u6539\u65F6\u95F4\u3001\u6587\u4EF6\u6743\u9650\u7B49\u8FDB\u884C\u68C0\u6D4B\uFF0C\u4EE5\u786E\u8BA4\u662F\u5426\u4E3AWebshell\u3002

                        \u57FA\u4E8E\u65E5\u5FD7\u7684Webshell\u68C0\u6D4B
                                \u5BF9\u5E38\u89C1\u7684\u591A\u79CD\u65E5\u5FD7\u8FDB\u884C\u5206\u6790\uFF0C\u53EF\u5E2E\u52A9\u6211\u4EEC\u6709\u6548\u8BC6\u522BWebshell\u7684\u4E0A\u4F20\u884C\u4E3A\u7B49\u3002
                                \u901A\u8FC7\u7EFC\u5408\u5206\u6790\uFF0C\u53EF\u56DE\u6EAF\u6574\u4E2A\u653B\u51FB\u8FC7\u7A0B\u3002

                Webshell\u9632\u5FA1\u65B9\u6CD5
                        \uFF081\uFF09\u914D\u7F6E\u5FC5\u8981\u7684\u9632\u706B\u5899\uFF0C\u5E76\u5F00\u542F\u9632\u706B\u5899\u7B56\u7565
                        \uFF082\uFF09\u5BF9\u670D\u52A1\u5668\u8FDB\u884C\u5B89\u5168\u52A0\u56FA
                        \uFF083\uFF09\u52A0\u5F3A\u6743\u9650\u7BA1\u7406\uFF0C\u5BF9\u654F\u611F\u76EE\u5F55\u8FDB\u884C\u6743\u9650\u8BBE\u7F6E
                        \uFF084\uFF09\u5B89\u88C5Webshell\u68C0\u6D4B\u5DE5\u5177\uFF0C\u6839\u636E\u68C0\u6D4B\u7ED3\u679C\u5BF9\u5DF2\u53D1\u73B0\u7684\u53EF\u7591Webshell\u75D5\u8FF9\u7ACB\u5373\u9694\u79BB\u67E5\u6740\uFF0C\u5E76\u6392\u67E5\u6F0F\u6D1E
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49\u66F4\u591A\u51718\u6761

                `))},{name:"\u5904\u7F6E\u65B9\u6CD5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u5165\u4FB5\u65F6\u95F4\u786E\u5B9A
                        \u5728\u7F51\u7AD9\u76EE\u5F55\u4E2D\u53D1\u73B0\u7684Webshell\u6587\u4EF6\u7684\u521B\u5EFA\u65F6\u95F4\uFF0C\u5224\u65AD\u653B\u51FB\u8005\u5B9E\u65BD\u653B\u51FB\u7684\u65F6\u95F4\u8303\u56F4\uFF0C\u4EE5\u4FBF\u540E\u7EED\u4F9D\u636E\u6B64\u65F6\u95F4\u8FDB\u884C\u6EAF\u6E90\u5206\u6790\u3001\u8FFD\u8E2A\u653B\u51FB\u8005\u7684\u6D3B\u52A8\u8DEF\u5F84\u3002

                Web\u65E5\u5FD7\u5206\u6790
                        \u5BF9\u8BBF\u95EE\u7F51\u7AD9\u7684Web\u65E5\u5FD7\u8FDB\u884C\u5206\u6790\uFF0C\u91CD\u70B9\u5173\u6CE8\u5DF2\u77E5\u7684\u5165\u4FB5\u65F6\u95F4\u524D\u540E\u7684\u65E5\u5FD7\u8BB0\u5F55\uFF0C
                                \u4ECE\u800C\u5BFB\u627E\u653B\u51FB\u8005\u7684\u653B\u51FB\u8DEF\u5F84\uFF0C\u4EE5\u53CA\u6240\u5229\u7528\u7684\u6F0F\u6D1E

                        \u8865\u5145\uFF0C\u6BD4\u5982\uFF1A
                                IIS\u65E5\u5FD7
                                Apache\u65E5\u5FD7
                                Tomcat\u65E5\u5FD7

                        \u4E3E\u4F8B\uFF1A
                                \u5206\u6790Web\u65E5\u5FD7\u53D1\u73B0\u5728\u6587\u4EF6\u521B\u5EFA\u7684\u65F6\u95F4\u8282\u70B9\u5E76\u672A\u6709\u53EF\u7591\u6587\u4EF6\u4E0A\u4F20\uFF0C\u4F46\u5B58\u5728\u53EF\u7591\u7684Webservice\u63A5\u53E3\uFF0C
                                        \u8FD9\u91CC\u9700\u8981\u6CE8\u610F\u7684\u662F\uFF0C\u4E00\u822C\u5E94\u7528\u670D\u52A1\u5668\u9ED8\u8BA4\u65E5\u5FD7\u4E0D\u8BB0\u5F55POST\u8BF7\u6C42\u5185\u5BB9\u3002

                \u6F0F\u6D1E\u5206\u6790
                        \u901A\u8FC7\u65E5\u5FD7\u4E2D\u53D1\u73B0\u7684\u95EE\u9898\uFF0C\u9488\u5BF9\u653B\u51FB\u8005\u6D3B\u52A8\u8DEF\u5F84\uFF0C\u53EF\u6392\u67E5\u7F51\u7AD9\u4E2D\u5B58\u5728\u7684\u6F0F\u6D1E\uFF0C\u5E76\u8FDB\u884C\u5206\u6790

                        \u4E3E\u4F8B\uFF1A
                                \u9488\u5BF9\u53D1\u73B0\u7684\u53EF\u7591\u63A5\u53E3Webservice\uFF0C\u8BBF\u95EE\u53D1\u73B0\u53D8\u91CFbuffer\u3001distinctPath\u3001newFileName\u53EF\u4EE5\u5728\u5BA2\u6237\u7AEF\u81EA\u5B9A\u4E49\uFF0C\u5BFC\u81F4\u4EFB\u610F\u6587\u4EF6\u90FD\u53EF\u4E0A\u4F20\u3002

                \u6F0F\u6D1E\u590D\u73B0
                        \u5BF9\u5DF2\u53D1\u73B0\u7684\u6F0F\u6D1E\u8FDB\u884C\u6F0F\u6D1E\u590D\u73B0\uFF0C\u4ECE\u800C\u8FD8\u539F\u653B\u51FB\u8005\u7684\u6D3B\u52A8\u8DEF\u5F84

                        \u4E3E\u4F8B\uFF1A
                                \u5BF9\u5DF2\u53D1\u73B0\u7684\u6F0F\u6D1E\u8FDB\u884C\u590D\u73B0\uFF0C\u6210\u529F\u4E0A\u4F20Webshell\uFF0C\u5E76\u83B7\u53D6\u4E86\u7F51\u7AD9\u670D\u52A1\u5668\u7684\u63A7\u5236\u6743

                \u6F0F\u6D1E\u4FEE\u590D
                        \u6E05\u9664\u5DF2\u53D1\u73B0\u7684Webshell\u6587\u4EF6\uFF0C\u5E76\u4FEE\u590D\u6F0F\u6D1E

                `))},{name:"\u5E38\u7528\u5DE5\u5177",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u626B\u63CF\u5DE5\u5177
                        D\u76FE
                        \u6CB3\u9A6CWebshell\u67E5\u6740

                \u6293\u5305\u5DE5\u5177
                        Wireshark
                                \u8FD9\u6709\u5565\u7528\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F

                `))},{name:"\u64CD\u4F5C\u6307\u5357",desc:u.a.createElement(u.a.Fragment,null),content:function(){function t(){var p="                                            ";return Object.entries({\u670D\u52A1\u5668:["Windows","Linux"],CMS:["JeeCms","WordPress","Drupal","TRS WCM","PhpCms","DedeCms"],\u4E2D\u95F4\u4EF6:["Tomcat","IIS","Apache","WebLogic","JBoss","WebSphere","Jetty"],\u6846\u67B6:["Struts2","ThinkPhp","Spring","Shiro","FastJson"],\u6570\u636E\u5E93:["Tomcat\uFF1F\uFF1F\uFF1F","IIS\uFF1F\uFF1F\uFF1F","Apache\uFF1F\uFF1F\uFF1F","WebLogic\uFF1F\uFF1F\uFF1F","Struts\uFF1F\uFF1F\uFF1F","MySQL","\u600E\u4E48\u8FD9\u91CC\u5927\u6BB5\u9519\u8BEF\u7684\uFF1F\uFF1F\uFF1F"],\u811A\u672C\u8BED\u8A00:["ASP","PHP","JSP"],\u4E1A\u52A1\u67B6\u6784:["\u6BD4\u5982\u3010\u524D\u7AEF\u7F51\u9875\u5185\u5BB9\u3011\u662F\u5426\u662F\u540E\u7AEF\u901A\u8FC7\u3010FTP\u3011\u4E0A\u4F20\u7684(\u65B0\u95FB\u7F51\u5C45\u591A)"]}).map(function(m){var B=Object(r.a)(m,2),C=B[0],A=B[1],D="".concat(C,"\uFF1A").concat(A.join(" / "),"        \u7B49");return"".concat(p).concat(D)}).join(`
`)}return u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u57FA\u672C\u4ECB\u7ECD\uFF1A
                        \u9996\u5148\u5E94\u5224\u65AD\u7CFB\u7EDF\u662F\u5426\u5B58\u5728\u690D\u5165Webshell\u7684\u53EF\u80FD
                                \u6839\u636E\u4E8B\u4EF6\u53D1\u751F\u7684\u65F6\u95F4\u8FDB\u884C\u6392\u67E5\uFF0C\u5BF9\u653B\u51FB\u8DEF\u5F84\u8FDB\u884C\u6EAF\u6E90\u5206\u6790

                                \u5982\u679C\u7F51\u7AD9\u88AB\u690D\u5165\u6697\u94FE\u6216\u51FA\u73B0\u5355\u51FB\u94FE\u63A5\u8DF3\u8F6C\u5230\u5176\u4ED6\u7F51\u7AD9\uFF08\u5982\u535A\u5F69\u7F51\u7AD9\u3001\u8272\u60C5\u7F51\u7AD9\u7B49\uFF09\u7684\u60C5\u51B5\uFF0C\u5E94\u9996\u5148\u6392\u67E5\u7F51\u7AD9\u9996\u9875\u76F8\u5173js\uFF0C\u67E5\u770B\u662F\u5426\u88AB\u690D\u5165\u4E86\u6076\u610F\u8DF3\u8F6C\u7684js\u3002

                                \u82E5\u7F51\u7AD9\u9996\u9875\u88AB\u7BE1\u6539\u6216\u6709\u5176\u4ED6\u88AB\u653B\u51FB\u7684\u73B0\u8C61\uFF0C\u5219\u5E94\u6839\u636E\u7F51\u7AD9\u7A0B\u5E8F\u4FE1\u606F\uFF0C\u5982\u7A0B\u5E8F\u76EE\u5F55\u3001\u6587\u4EF6\u4E0A\u4F20\u76EE\u5F55\u3001war\u5305\u90E8\u7F72\u76EE\u5F55\uFF0C\u4F7F\u7528\u5DE5\u5177\uFF08\u5982D\u76FE\uFF09\u548C\u641C\u7D22\u5173\u952E\u8BCD\uFF08\u5982eval\u3001base64_decode\u3001assert\uFF09\u65B9\u5F0F\uFF0C\u5B9A\u4F4D\u5230Webshell\u6587\u4EF6\u5E76\u6E05\u9664

                        \u7136\u540E\u6839\u636E\u65E5\u5FD7\u8FDB\u884C\u6EAF\u6E90\u5206\u6790

                        \u540C\u65F6\u9664\u4E86\u8FDB\u884CWeb\u5E94\u7528\u5C42\u6392\u67E5\uFF0C\u8FD8\u5E94\u5BF9\u7CFB\u7EDF\u5C42\u8FDB\u884C\u5168\u9762\u6392\u67E5\uFF0C\u9632\u6B62\u653B\u51FB\u8005\u5728\u83B7\u53D6Webshell\u540E\u6267\u884C\u4E86\u5176\u4ED6\u7684\u6743\u9650\u7EF4\u6301\u64CD\u4F5C

                \u521D\u6B65\u9884\u5224
                        \u4E86\u89E3Webshell\u4E8B\u4EF6\u8868\u73B0
                                \u690D\u5165Webshell\uFF0C\u7CFB\u7EDF\u53EF\u80FD\u51FA\u73B0\u7684\u5F02\u5E38\u73B0\u8C61\u5982\u4E0B\uFF1A
                                        \u7F51\u9875\u88AB\u7BE1\u6539\uFF0C\u6216\u5728\u7F51\u7AD9\u4E2D\u53D1\u73B0\u975E\u7BA1\u7406\u5458\u8BBE\u7F6E\u7684\u5185\u5BB9\uFF1B
                                        \u51FA\u73B0\u653B\u51FB\u8005\u6076\u610F\u7BE1\u6539\u7F51\u9875\u6216\u7F51\u9875\u88AB\u690D\u5165\u6697\u94FE\u7684\u73B0\u8C61\uFF1B
                                        \u53D1\u73B0\u5B89\u5168\u8BBE\u5907\u62A5\u8B66\uFF0C\u6216\u88AB\u4E0A\u7EA7\u90E8\u95E8\u901A\u62A5\u906D\u9047Webshell\u3002
                        \u5224\u65ADWebshell\u4E8B\u4EF6\u53D1\u751F\u65F6\u95F4
                                \u6839\u636E\u5F02\u5E38\u73B0\u8C61\u53D1\u751F\u65F6\u95F4\uFF0C\u7ED3\u5408\u7F51\u7AD9\u76EE\u5F55\u4E2DWebshell\u6587\u4EF6\u7684\u521B\u5EFA\u65F6\u95F4\uFF0C\u53EF\u5927\u81F4\u5B9A\u4F4D\u4E8B\u4EF6\u53D1\u751F\u7684\u65F6\u95F4\u6BB5
                        \u5224\u65AD\u7CFB\u7EDF\u67B6\u6784
                                \u6536\u96C6\u7CFB\u7EDF\u4FE1\u606F\uFF0C\u4E3A\u5FEB\u901F\u6EAF\u6E90\u5206\u6790\u63D0\u4F9B\u524D\u671F\u51C6\u5907\u5DE5\u4F5C
                                        \u6B64\u5904\uFF0C\u6709\u4E00\u5F20\u56FE\uFF1A
                                            `.concat(t().trimStart(),`

                Webshell\u6392\u67E5
                        Windows\u7CFB\u7EDF\u6392\u67E5
                                \u53EF\u5229\u7528Webshell\u626B\u63CF\u5DE5\u5177\uFF08\u5982D\u76FE\uFF09\u5BF9\u5E94\u7528\u90E8\u7F72\u76EE\u5F55\u8FDB\u884C\u626B\u63CF
                                        \u5982\u7F51\u7AD9D\uFF1A\\WWW\\\u76EE\u5F55\uFF0C
                                \u6216\u8005\u5C06\u5F53\u524D\u7F51\u7AD9\u76EE\u5F55\u6587\u4EF6\u4E0E\u6B64\u524D\u5907\u4EFD\u6587\u4EF6\u8FDB\u884C\u6BD4\u5BF9
                                        \u67E5\u770B\u662F\u5426\u5B58\u5728\u65B0\u589E\u7684\u4E0D\u4E00\u81F4\u5185\u5BB9\uFF0C\u786E\u5B9A\u662F\u5426\u5305\u542BWebshell\u76F8\u5173\u4FE1\u606F\uFF0C\u5E76\u786E\u5B9AWebshell\u4F4D\u7F6E\u53CA\u521B\u5EFA\u65F6\u95F4

                        Linux\u7CFB\u7EDF\u6392\u67E5
                                \u5728Linux\u7CFB\u7EDF\u4E2D\uFF0C\u53EF\u7528\u6CB3\u9A6CWebshell\u67E5\u6740\u5DE5\u5177\u626B\u63CF\uFF0C
                                \u4E5F\u53EF\u624B\u5DE5\u641C\u7D22\u53EF\u80FD\u5305\u542BWebshell\u7279\u5F81\u7684\u6587\u4EF6
                                        \u89C1\u4E4B\u524D\u547D\u4EE4\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026

                Web\u65E5\u5FD7\u5206\u6790
                        Windows\u7CFB\u7EDF\u6392\u67E5
                                \u5E38\u89C1Web\u4E2D\u95F4\u4EF6\u3010\u65E5\u5FD7\u3011\u9ED8\u8BA4\u8DEF\u5F84\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49\u4E4B\u7C7B\u7684

                                \u6839\u636EWebshell\u6587\u4EF6\u521B\u5EFA\u65F6\u95F4\uFF0C\u6392\u67E5\u5BF9\u5E94\u65F6\u95F4\u8303\u56F4\u7684IIS\u8BBF\u95EE\u65E5\u5FD7

                                \u8FDB\u4E00\u6B65\u641C\u7D22Webshell\u6587\u4EF6\u521B\u5EFA\u65F6\u95F4\u524D\u540E\u7684\u76F8\u5173\u65E5\u5FD7\uFF0C
                                        \u4E3E\u4F8B\uFF1A
                                                \u53EF\u4EE5\u770B\u5230\u5728\u8BBF\u95EE\u65F6\u95F4\u4E4B\u524D\u6709\u5229\u7528POST\u65B9\u6CD5\u8BBF\u95EEUpload_user.aspx\u4E0A\u4F20\u9875\u9762\u7684\u60C5\u51B5
                                                \u8FDB\u4E00\u6B65\u5206\u6790\u5F97\u77E5\u8BE5Upload_user.aspx\u9875\u9762\u9700\u8981\u767B\u5F55\u540E\u53F0\u624D\u80FD\u8BBF\u95EE\u3002
                                                        \u4ECE\u65E5\u5FD7\u4E2D\u53EF\u4EE5\u53D1\u73B0\uFF0C\u653B\u51FB\u8005\u5728\u8BBF\u95EE\u4E0A\u4F20\u9875\u9762\u4E4B\u524D\u8FD8\u8BBF\u95EE\u4E86\u767B\u5F55\u9875\u9762\uFF0C
                                                                \u7531\u4E8EWeb\u5E94\u7528\u65E5\u5FD7\u9ED8\u8BA4\u4E0D\u8BB0\u5F55POST\u8BF7\u6C42\u4F53\uFF0C\u4E14\u901A\u8FC7\u6D4B\u8BD5\u53D1\u73B0\u7F51\u7AD9\u540E\u53F0\u5B58\u5728\u5F31\u5BC6\u7801\u7528\u6237\uFF0C\u5F31\u5BC6\u7801\u4E3A123456

                        Linux\u7CFB\u7EDF\u6392\u67E5
                                \u5E38\u89C1Web\u4E2D\u95F4\u4EF6\u3010\u65E5\u5FD7\u3011\u9ED8\u8BA4\u8DEF\u5F84\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49\u4E4B\u7C7B\u7684

                                \u53EF\u4EE5\u6839\u636E\u53D1\u73B0Webshell\u7684\u65F6\u95F4\u3001\u7CFB\u7EDF\u5F02\u5E38\u7684\u65F6\u95F4\u6216Webshell\u67E5\u6740\u5DE5\u5177\u5B9A\u4F4D\u5230\u6728\u9A6C\u7684\u65F6\u95F4\u5BF9\u76F8\u5173\u65F6\u95F4\u6BB5\u65E5\u5FD7\u8FDB\u884C\u5206\u6790
                                        \u4E3E\u4F8B\uFF1A
                                                \u6839\u636E\u53D1\u73B0Webshell\u7684\u65F6\u95F4\uFF0C\u5206\u6790\u76F8\u5173\u65F6\u95F4\u6BB5\u65E5\u5FD7\uFF0C\u53D1\u73B0\u4E86\u653B\u51FB\u8005\u5229\u7528Dedecms\u540E\u53F0GetShell\u6F0F\u6D1E\u4E0A\u4F20\u7684Webshell\u3002

                \u7CFB\u7EDF\u6392\u67E5
                        Windows\u7CFB\u7EDF\u6392\u67E5
                                \u7528\u6237\u4FE1\u606F\u6392\u67E5
                                        \u7528\u6237\u6392\u67E5
                                        \u9690\u85CF\u7528\u6237\u6392\u67E5
                                        \u514B\u9686\u7528\u6237\u6392\u67E5

                                \u8FDB\u7A0B\u3001\u670D\u52A1\u3001\u9A71\u52A8\u3001\u6A21\u5757\u3001\u542F\u52A8\u9879\u6392\u67E5
                                        \u8FDB\u7A0B\u6392\u67E5
                                                \u624B\u52A8\u6392\u67E5
                                                \u4E4B\u524D\u8BB2\u8FC7\u7684\u3010PCHunter\u3011\u7B49\u7B49
                                        \u670D\u52A1\u6392\u67E5
                                        \u9A71\u52A8\u3001\u6A21\u5757\u3001\u542F\u52A8\u9879\u6392\u67E5

                                \u7F51\u7EDC\u8FDE\u63A5\u6392\u67E5
                                        \u7CFB\u7EDF\u81EA\u5E26\u547D\u4EE4\u6392\u67E5
                                        \u4E4B\u524D\u8BB2\u8FC7\u7684\u3010TCPView\u3011\u7B49\u7B49

                                \u4EFB\u52A1\u8BA1\u5212\u6392\u67E5

                                \u6587\u4EF6\u6392\u67E5
                                        temp\u76F8\u5173\u76EE\u5F55
                                        recent\u76F8\u5173\u76EE\u5F55

                        Linux\u7CFB\u7EDF\u6392\u67E5
                                \u7528\u6237\u4FE1\u606F\u6392\u67E5
                                        123
                                \u8FDB\u7A0B\u3001\u670D\u52A1\u3001\u7F51\u7EDC\u8FDE\u63A5\u6392\u67E5
                                        \u65B9\u6CD51
                                        \u65B9\u6CD52
                                        \u65B9\u6CD53
                                        \u65B9\u6CD54
                                        \u65B9\u6CD55
                                        \u65B9\u6CD56
                                \u5F00\u673A\u81EA\u542F\u52A8\u6392\u67E5
                                        123
                                \u5B9A\u65F6\u4EFB\u52A1\u6392\u67E5
                                        \u65B9\u6CD51
                                        \u65B9\u6CD52
                                rootkit\u6392\u67E5
                                        \u65B9\u6CD51
                                        \u65B9\u6CD52
                                        \u65B9\u6CD53
                                        \u65B9\u6CD54
                                \u6587\u4EF6\u6392\u67E5
                                        \u65B9\u6CD51
                                        \u65B9\u6CD52
                                        \u65B9\u6CD53
                                        \u65B9\u6CD54
                                        \u65B9\u6CD55

                \u65E5\u5FD7\u6392\u67E5
                        Windows\u7CFB\u7EDF\u6392\u67E5
                                \u67E5\u770B\u5B89\u5168\u65E5\u5FD7\uFF0C\u591A\u5173\u6CE8\u5176\u4E2D\u7684\u7279\u6B8A\u4E8B\u4EF6
                                \u5728%SystemRoot%\\System32\\Winevt\\Logs\u76EE\u5F55\u4E0B\u8FD8\u5B58\u5728\u5927\u91CF\u5176\u4ED6\u65E5\u5FD7\uFF0C
                                        \u4F8B\u5982\uFF0C\u8FDC\u7A0B\u684C\u9762\u4F1A\u8BDD\u65E5\u5FD7\u4F1A\u8BB0\u5F55\u901A\u8FC7RDP\u767B\u5F55\u7684\u4FE1\u606F\uFF0C\u5305\u542B\u767B\u5F55\u6E90\u7F51\u7EDC\u5730\u5740\u3001\u767B\u5F55\u7528\u6237\u7B49

                        Linux\u7CFB\u7EDF\u6392\u67E5
                                Linux\u7CFB\u7EDF\u65E5\u5FD7\u4E00\u822C\u4F4D\u4E8E/var/log\u76EE\u5F55\u4E0B\uFF0C\u51E0\u4E4E\u4FDD\u5B58\u4E86\u7CFB\u7EDF\u6240\u6709\u7684\u64CD\u4F5C\u8BB0\u5F55\uFF0C
                                        \u5305\u62EC\u7528\u6237\u8BA4\u8BC1\u65F6\u4EA7\u751F\u7684\u65E5\u5FD7\u3001\u7CFB\u7EDF\u5B9A\u671F\u6267\u884C\u4EFB\u52A1\u8BA1\u5212\u65F6\u4EA7\u751F\u7684\u65E5\u5FD7\u3001\u7CFB\u7EDF\u67D0\u4E9B\u5B88\u62A4\u8FDB\u7A0B\u4EA7\u751F\u7684\u65E5\u5FD7\u3001\u7CFB\u7EDF\u90AE\u4EF6\u65E5\u5FD7\u3001\u5185\u6838\u4FE1\u606F\u7B49\u3002

                        \u6570\u636E\u5E93\u65E5\u5FD7\u6392\u67E5
                                MySQL\u65E5\u5FD7

                                SQL Server\u65E5\u5FD7

                \u7F51\u7EDC\u6D41\u91CF\u6392\u67E5
                        \u5229\u7528\u73B0\u573A\u90E8\u7F72\u7684\u7F51\u7EDC\u5B89\u5168\u8BBE\u5907\uFF0C\u901A\u8FC7\u7F51\u7EDC\u6D41\u91CF\u6392\u67E5\u5206\u6790\u4EE5\u4E0B\u5185\u5BB9\uFF1A
                                \u670D\u52A1\u5668\u9AD8\u5371\u884C\u4E3A\u3001Webshell\u8FDE\u63A5\u884C\u4E3A\u3001\u6570\u636E\u5E93\u5371\u9669\u64CD\u4F5C\u3001\u90AE\u4EF6\u8FDD\u89C4\u884C\u4E3A\u3001\u975E\u6CD5\u5916\u8FDE\u884C\u4E3A\u3001\u5F02\u5E38\u8D26\u6237\u767B\u5F55\u884C\u4E3A\u7B49\u3002

                        \u5728\u7F3A\u5C11\u6D41\u91CF\u5206\u6790\u8BBE\u5907\u65F6\uFF0CWindows\u7CFB\u7EDF\u53EF\u4EE5\u501F\u52A9\u6293\u5305\u5DE5\u5177Wireshark\u8F85\u52A9\u5206\u6790

                        \u4E00\u4E9B\u7279\u5F81\uFF1A
                                \u82E5\u6570\u636E\u5305\u4E2D\u5E26\u6709z0\u3001eval\u3001base64_decode\uFF0C\u5219\u8BE5\u6570\u636E\u5305\u5F88\u53EF\u80FD\u662F\u4E2D\u56FD\u83DC\u5200\u5BA2\u6237\u7AEF\u8FDE\u63A5\u4E00\u53E5\u8BDD\u6728\u9A6C\u65F6\u4EA7\u751F\u7684

                                \u82E5\u6570\u636E\u5305\u4E2D\u5E26\u6709\u7279\u6B8A\u7684Referer\u3001Accept-Language\uFF0C\u5219\u4E00\u822C\u662F\u653B\u51FB\u8005\u5229\u7528Weevely Webshell\u5DE5\u5177\u8FDE\u63A5\u4EA7\u751F\u7684

                                \u5982\u679C\u653B\u51FB\u8005\u5728\u653B\u51FB\u6210\u529F\u540E\u5229\u7528msf\u4E2D\u7684reverse_tcp\u4E0A\u7EBF\uFF0C\u90A3\u4E48\u5728Wireshark\u6570\u636E\u5305\u4E2D\u4E00\u822C\u4F1A\u6709PSH\uFF08PuSH\uFF09\u6807\u5FD7\u4F4D

                \u6E05\u9664\u52A0\u56FA
                        123


                `)))}()},{name:"\u5904\u7F6E\u6848\u4F8B",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`
                \u4E8B\u4EF6\u80CC\u666F

                \u4E8B\u4EF6\u5904\u7F6E

                \u6839\u9664\u53CA\u6062\u590D

                `))}]},{name:"\u8FDC\u63A7",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`
                  \uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F

                  Termite\uFF08\u767D\u8681\uFF09\u8FDC\u7A0B\u63A7\u5236\u5DE5\u5177
                          \uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F


                  `))},{name:"\u7F51\u9875\u7E82\u6539",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u6982\u8FF0",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u7F51\u9875\u7BE1\u6539\u4E8B\u4EF6\u5206\u7C7B
                        \u7F51\u9875\u7BE1\u6539\u4E00\u822C\u6709\u660E\u663E\u5F0F\u548C\u9690\u85CF\u5F0F\u4E24\u79CD

                \u7F51\u9875\u7BE1\u6539\u539F\u56E0
                        \u653B\u51FB\u8005\u83B7\u53D6\u7ECF\u6D4E\u5229\u76CA
                                \u7ECF\u8425\u8005\u4F1A\u901A\u8FC7\u4E0E\u653B\u51FB\u8005\u5408\u4F5C\uFF0C\u8D2D\u4E70\u653B\u9677\u7AD9\u70B9\u6765\u6279\u91CF\u7BE1\u6539\u9875\u9762\uFF0C\u5B9E\u73B0\u975E\u6CD5\u7AD9\u70B9\u63A8\u5E7F\uFF0C\u4ECE\u800C\u83B7\u5F97\u5DE8\u5927\u7684\u7ECF\u6D4E\u5229\u76CA
                                \u653B\u51FB\u8005\u4F1A\u5411\u88AB\u7BE1\u6539\u7AD9\u70B9\u7F51\u9875\u5D4C\u5165\u6D4F\u89C8\u5668\u6316\u77FF\u811A\u672C\u6216\u5728\u7F51\u7AD9\u4E2D\u52A0\u5165\u4E00\u6BB5JavaScript\u4EE3\u7801
                        \u653B\u51FB\u8005\u5C55\u73B0\u80FD\u529B\uFF0C\u635F\u574F\u4ED6\u4EBA\u5F62\u8C61
                                123
                        \u901A\u8FC7\u7F51\u9875\u7BE1\u6539\uFF0C\u5B9E\u73B0\u540E\u7EED\u5176\u4ED6\u653B\u51FB
                                \u7F51\u9875\u6302\u9A6C
                                \u6C34\u5751\u653B\u51FB
                                \u7F51\u7EDC\u9493\u9C7C

                \u7F51\u9875\u7BE1\u6539\u653B\u51FB\u624B\u6CD5
                        123

                \u7F51\u9875\u7BE1\u6539\u68C0\u6D4B\u6280\u672F
                        \u5916\u6302\u8F6E\u8BE2\u6280\u672F
                                123
                        \u6838\u5FC3\u5185\u5D4C\u6280\u672F
                                \u5C06\u7BE1\u6539\u68C0\u6D4B\u6A21\u5757\u5185\u5D4C\u5728Web\u670D\u52A1\u5668\u8F6F\u4EF6\u4E2D\uFF0C\u5B83\u5728\u6BCF\u4E2A\u7F51\u9875\u6D41\u51FA\u65F6\u90FD\u8FDB\u884C\u5B8C\u6574\u6027\u68C0\u67E5
                        \u4E8B\u4EF6\u89E6\u53D1\u6280\u672F
                                \u5728\u7F51\u9875\u6587\u4EF6\u88AB\u4FEE\u6539\u65F6\u8FDB\u884C\u5408\u6CD5\u6027\u68C0\u67E5

                \u7F51\u9875\u7BE1\u6539\u9632\u5FA1\u65B9\u6CD5
                        123
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B496\u79CD

                \u7F51\u9875\u7BE1\u6539\u7BA1\u7406\u5236\u5EA6
                        123
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B493\u79CD

                `))},{name:"\u5904\u7F6E\u65B9\u6CD5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u9694\u79BB\u88AB\u611F\u67D3\u7684\u670D\u52A1\u5668/\u4E3B\u673A
                        \u76EE\u7684\uFF1A
                                \u4E00\u662F\u9632\u6B62\u6728\u9A6C\u901A\u8FC7\u7F51\u7EDC\u7EE7\u7EED\u611F\u67D3\u5176\u4ED6\u670D\u52A1\u5668/\u4E3B\u673A\uFF1B
                                \u4E8C\u662F\u9632\u6B62\u653B\u51FB\u8005\u901A\u8FC7\u5DF2\u7ECF\u611F\u67D3\u7684\u670D\u52A1\u5668/\u4E3B\u673A\u7EE7\u7EED\u64CD\u63A7\u5176\u4ED6\u8BBE\u5907\u3002

                        \u6709\u4E00\u7C7B\u9ED1\u94FE\u4F1A\u5728\u5185\u5B58\u4E2D\u5FAA\u73AF\u6267\u884C\u7A0B\u5E8F\uFF0C\u4EA7\u751F\u5927\u91CF\u7684\u9ED1\u94FE\u6587\u4EF6\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49\u7B49\u7B49

                        \u4E3B\u8981\u7684\u9694\u79BB\u65B9\u6CD5\u5982\u4E0B\uFF1A
                                \u2026\u2026\u2026\u2026\u2026\u2026\u7B492\u6761

                \u6392\u67E5\u4E1A\u52A1\u7CFB\u7EDF


                \u786E\u5B9A\u6F0F\u6D1E\u6E90\u5934\u3001\u6EAF\u6E90\u5206\u6790
                        \u6EAF\u6E90\u5206\u6790\u4E00\u822C\u662F\u901A\u8FC7\u67E5\u770B\u670D\u52A1\u5668/\u4E3B\u673A\u4E2D\u4FDD\u7559\u7684\u65E5\u5FD7\u4FE1\u606F\u548C\u6837\u672C\u4FE1\u606F\u5C55\u5F00\u7684\u3002

                        \u67E5\u627E\u6728\u9A6C\u53EF\u4EE5\u4F7F\u7528Webshell\u67E5\u6740\u5DE5\u5177\u8FDB\u884C\u5168\u76D8\u67E5\u6740\uFF0C\u7136\u540E\u901A\u8FC7\u65E5\u5FD7\u5224\u65AD\u6728\u9A6C\u7684\u5165\u4FB5\u65B9\u5F0F
                                \u5982\u679C\u65E5\u5FD7\u88AB\u5220\u9664\u4E86\uFF0C\u90A3\u4E48\u5C31\u9700\u8981\u53BB\u670D\u52A1\u5668/\u4E3B\u673A\u5BFB\u627E\u76F8\u5173\u7684\u6728\u9A6C\u6837\u672C\u6216\u53EF\u7591\u6587\u4EF6\uFF0C\u518D\u901A\u8FC7\u5206\u6790\u8FD9\u4E9B\u53EF\u7591\u7684\u6587\u4EF6\u6765\u5224\u65AD\u6728\u9A6C\u7684\u5165\u4FB5\u9014\u5F84
                                \u5F53\u7136\uFF0C\u4E5F\u53EF\u4EE5\u76F4\u63A5\u4F7F\u7528\u4E13\u4E1A\u7684\u65E5\u5FD7\u5206\u6790\u5DE5\u5177\u6216\u8054\u7CFB\u4E13\u4E1A\u6280\u672F\u4EBA\u5458\u8FDB\u884C\u65E5\u5FD7\u53CA\u6837\u672C\u7684\u5206\u6790\u3002

                \u6062\u590D\u6570\u636E\u548C\u4E1A\u52A1
                        123123
                        123123

                \u540E\u7EED\u9632\u62A4\u5EFA\u8BAE
                        123123

                `))},{name:"\u5E38\u7528\u5DE5\u5177",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u5728\u7F51\u9875\u88AB\u7BE1\u6539\u540E\uFF0C\u6211\u4EEC\u6700\u5173\u5FC3\u7684\u95EE\u9898\uFF1A
                        \u4E00\u662F\u54EA\u4E9B\u7F51\u9875\u88AB\u7BE1\u6539\u4E86\uFF0C
                        \u4E8C\u662F\u653B\u51FB\u8005\u662F\u600E\u4E48\u5B9E\u73B0\u653B\u51FB\u7684\u3002

                \u65E5\u5FD7\u5206\u6790\u5DE5\u5177
                        123

                \u7F51\u7AD9\u76D1\u63A7\u5DE5\u5177
                        123

                `))},{name:"\u64CD\u4F5C\u6307\u5357",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u521D\u6B65\u9884\u5224
                        \u4E1A\u52A1\u7CFB\u7EDF\u67D0\u90E8\u5206\u7F51\u9875\u51FA\u73B0\u5F02\u5E38\u5B57\u8BCD
                        \u7F51\u7AD9\u51FA\u73B0\u5F02\u5E38\u56FE\u7247\u3001\u6807\u8BED\u7B49

                \u7CFB\u7EDF\u6392\u67E5
                        \u800C\u83B7\u53D6\u6743\u9650\u4E3B\u8981\u6709\u4E09\u79CD\u65B9\u6CD5\uFF1A
                                \u4E00\u662F\u901A\u8FC7\u975E\u6CD5\u9014\u5F84\u8D2D\u4E70\u5DF2\u7ECF\u6CC4\u9732\u7684\u76F8\u5E94\u6743\u9650\u7684\u670D\u52A1\u5668\u8D26\u53F7\uFF1B
                                \u4E8C\u662F\u4F7F\u7528\u6076\u610F\u7A0B\u5E8F\u8FDB\u884C\u66B4\u529B\u7834\u574F\uFF0C\u4ECE\u800C\u4FEE\u6539\u7F51\u9875\uFF1B
                                \u4E09\u662F\u5165\u4FB5\u7F51\u7AD9\u670D\u52A1\u5668\uFF0C\u8FDB\u800C\u83B7\u53D6\u64CD\u4F5C\u6743\u9650\u3002\u5E94\u5BF9\u7F51\u9875\u7BE1\u6539\u4E8B\u4EF6\u8FDB\u884C\u7684\u7CFB\u7EDF\u6392\u67E5\u5982\u4E0B\u3002

                        \u5F02\u5E38\u7AEF\u53E3\u3001\u8FDB\u7A0B\u6392\u67E5
                                \u68C0\u67E5\u7AEF\u53E3\u8FDE\u63A5\u60C5\u51B5\uFF0C\u5224\u65AD\u662F\u5426\u6709\u8FDC\u7A0B\u8FDE\u63A5\u3001\u53EF\u7591\u8FDE\u63A5\u3002
                                \u67E5\u770B\u53EF\u7591\u7684\u8FDB\u7A0B\u53CA\u5176\u5B50\u8FDB\u7A0B

                        \u53EF\u7591\u6587\u4EF6\u6392\u67E5
                                \u53D1\u73B0\u53EF\u7591\u8FDB\u7A0B\u540E\uFF0C\u901A\u8FC7\u8FDB\u7A0B\u67E5\u8BE2\u6076\u610F\u7A0B\u5E8F\u3002
                                        \u591A\u6570\u7684\u7F51\u9875\u7BE1\u6539\u662F\u5229\u7528\u6F0F\u6D1E\u4E0A\u4F20Webshell\u6587\u4EF6\u83B7\u53D6\u6743\u9650\u7684
                                                D\u76FE\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49\u5DE5\u5177

                        \u53EF\u7591\u8D26\u53F7\u6392\u67E5
                                123

                        \u786E\u8BA4\u7BE1\u6539\u65F6\u95F4
                                \u4E3A\u4E86\u65B9\u4FBF\u540E\u7EED\u7684\u65E5\u5FD7\u5206\u6790\uFF0C\u6B64\u65F6\u9700\u8981\u786E\u8BA4\u7F51\u9875\u7BE1\u6539\u7684\u5177\u4F53\u65F6\u95F4
                                        access.log\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F
                                                \u4E3A\u4EC0\u4E48\u4E3A\u4EC0\u4E48\uFF1F\uFF1F

                \u65E5\u5FD7\u6392\u67E5
                        \u7CFB\u7EDF\u65E5\u5FD7
                                Windows\u7CFB\u7EDF
                                        \u7CFB\u7EDF
                                                123
                                        \u5B89\u5168
                                                123
                                        \u5E94\u7528
                                                123
                                Linux\u7CFB\u7EDF
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49\u65E5\u5FD7

                        Web\u65E5\u5FD7
                                \u901A\u8FC7Web\u65E5\u5FD7\u53EF\u4EE5\u6E05\u695A\u77E5\u6653\u7528\u6237\u7684IP\u5730\u5740\u3001\u4F55\u65F6\u4F7F\u7528\u7684\u64CD\u4F5C\u7CFB\u7EDF\u3001\u4F7F\u7528\u4EC0\u4E48\u6D4F\u89C8\u5668\u8BBF\u95EE\u4E86\u7F51\u7AD9\u7684\u54EA\u4E2A\u9875\u9762\u3001\u662F\u5426\u8BBF\u95EE\u6210\u529F\u7B49\u3002
                                \u901A\u8FC7\u5BF9Web\u65E5\u5FD7\u8FDB\u884C\u5B89\u5168\u5206\u6790\uFF0C\u53EF\u4EE5\u8FD8\u539F\u653B\u51FB\u573A\u666F

                                Windows\u7CFB\u7EDF
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49

                                Linux\u7CFB\u7EDF
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49

                        \u6570\u636E\u5E93\u65E5\u5FD7
                                MySQL\u6570\u636E\u5E93\u65E5\u5FD7
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49

                                Oracle\u6570\u636E\u5E93\u65E5\u5FD7
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49

                \u7F51\u7EDC\u6D41\u91CF\u6392\u67E5
                        123

                \u6E05\u9664\u52A0\u56FA
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B495\u6761

                `))},{name:"\u5904\u7F6E\u6848\u4F8B",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u4E8B\u4EF6\u80CC\u666F

                \u4E8B\u4EF6\u5904\u7F6E

                \u6839\u9664\u53CA\u6062\u590D

                `))}]},{name:"DDos\u653B\u51FB",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u6982\u8FF0",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                DDoS\u653B\u51FB\u76EE\u7684
                        \u8FDB\u884C\u52D2\u7D22
                        \u6253\u51FB\u7ADE\u4E89\u5BF9\u624B
                        \u62A5\u590D\u884C\u4E3A\u6216\u653F\u6CBB\u76EE\u7684

                \u5E38\u89C1DDoS\u653B\u51FB\u65B9\u6CD5
                        \u6D88\u8017\u7F51\u7EDC\u5E26\u5BBD\u8D44\u6E90
                                \u653B\u51FB\u8005\u4E3B\u8981\u5229\u7528\u53D7\u63A7\u4E3B\u673A\u53D1\u9001\u5927\u91CF\u7684\u7F51\u7EDC\u6570\u636E\u5305\uFF0C\u5360\u6EE1\u653B\u51FB\u76EE\u6807\u7684\u5E26\u5BBD\uFF0C\u4F7F\u5F97\u6B63\u5E38\u8BF7\u6C42\u65E0\u6CD5\u8FBE\u5230\u53CA\u65F6\u6709\u6548\u7684\u54CD\u5E94\u3002

                                ICMP Flood\uFF08ICMP\u6D2A\u6C34\u653B\u51FB\uFF09
                                        \uFF08\u540C\u65F6\uFF0C\u4E5F\u662FPing\u4F7F\u7528\u7684\u90A3\u4E2A\u534F\u8BAE\uFF09
                                UDP Flood\uFF08UDP\u6D2A\u6C34\u653B\u51FB\uFF09

                                \u53CD\u5C04\u4E0E\u653E\u5927\u653B\u51FB
                                        \u4E5F\u79F0\u4E3A\u5206\u5E03\u5F0F\u53CD\u5C04\u62D2\u7EDD\u670D\u52A1\u653B\u51FB\uFF08DRDoS\uFF09\u3002

                                        \u5E38\u89C1\u7684DRDoS\u653B\u51FB\u5982\u4E0B\u3002
                                                NTP Reflection Flood

                                                DNS Reflection Flood

                                                SSDP Reflection Flood

                                                SNMP Reflection Flood
                        \u6D88\u8017\u7CFB\u7EDF\u8D44\u6E90
                                \u6D88\u8017\u7CFB\u7EDF\u8D44\u6E90\u653B\u51FB\u4E3B\u8981\u901A\u8FC7\u5BF9\u7CFB\u7EDF\u7EF4\u62A4\u7684\u8FDE\u63A5\u8D44\u6E90\u8FDB\u884C\u6D88\u8017\uFF0C\u4F7F\u5176\u65E0\u6CD5\u6B63\u5E38\u8FDE\u63A5\uFF0C\u4EE5\u8FBE\u5230\u62D2\u7EDD\u670D\u52A1\u5668\u7684\u76EE\u7684\u3002

                                TCP Flood

                                SYN Flood

                        \u6D88\u8017\u5E94\u7528\u8D44\u6E90
                                \u6D88\u8017\u5E94\u7528\u8D44\u6E90\u653B\u51FB\u901A\u8FC7\u5411\u5E94\u7528\u63D0\u4EA4\u5927\u91CF\u6D88\u8017\u8D44\u6E90\u7684\u8BF7\u6C42\uFF0C\u4EE5\u8FBE\u5230\u62D2\u7EDD\u670D\u52A1\u7684\u76EE\u7684

                                HTTP Flood\uFF08CC\u653B\u51FB\uFF09
                                        HTTP GET\u653B\u51FB

                                        HTTP POST\u653B\u51FB

                                \u6162\u901F\u653B\u51FB
                                        \u6162\u901F\u653B\u51FB\u4F9D\u8D56\u4E8E\u6162\u901F\u6D41\u91CF\uFF0C\u4E3B\u8981\u9488\u5BF9\u5E94\u7528\u7A0B\u5E8F\u6216\u670D\u52A1\u5668\u8D44\u6E90\u3002
                                                \u4E0E\u4F20\u7EDF\u7684\u653B\u51FB\u4E0D\u540C\uFF0C\u6162\u901F\u653B\u51FB\u6240\u9700\u7684\u5E26\u5BBD\u975E\u5E38\u5C11\uFF0C\u4E14\u96BE\u4EE5\u7F13\u89E3\uFF0C\u56E0\u4E3A\u5176\u751F\u6210\u7684\u6D41\u91CF\u5F88\u96BE\u4E0E\u6B63\u5E38\u6D41\u91CF\u533A\u5206\u5F00

                DDoS\u653B\u51FB\u9632\u5FA1\u65B9\u6CD5
                        \u653B\u51FB\u524D\u7684\u9632\u5FA1\u9636\u6BB5
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B497\u6761

                        \u653B\u51FB\u65F6\u7684\u7F13\u89E3\u9636\u6BB5
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B493\u6761

                        \u653B\u51FB\u540E\u7684\u8FFD\u6EAF\u603B\u7ED3\u9636\u6BB5
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B493\u6761

                `))},{name:"\u5904\u7F6E\u65B9\u6CD5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u5224\u65ADDDoS\u653B\u51FB\u7684\u7C7B\u578B

                        \u5982\u679C\u6709\u6297DDoS\u653B\u51FB\u8BBE\u5907\u3001\u6D41\u91CF\u76D1\u63A7\u8BBE\u5907\u7B49\uFF0C\u90A3\u4E48\u6211\u4EEC\u53EF\u4EE5\u5206\u6790\u8BBE\u5907\u7684\u6D41\u91CF\u3001\u544A\u8B66\u4FE1\u606F\uFF0C\u5224\u65AD\u653B\u51FB\u7C7B\u578B\uFF1B

                        \u5982\u679C\u6CA1\u6709\u76F8\u5173\u8BBE\u5907\uFF0C\u90A3\u4E48\u6211\u4EEC\u53EF\u4EE5\u901A\u8FC7\u6293\u5305\u3001\u6392\u67E5\u8BBE\u5907\u8BBF\u95EE\u65E5\u5FD7\u4FE1\u606F\uFF0C\u5224\u65AD\u653B\u51FB\u7C7B\u578B\uFF0C\u4E3A\u91C7\u53D6\u9002\u5F53\u7684\u9632\u5FA1\u63AA\u65BD\u63D0\u4F9B\u4F9D\u636E\u3002

                \u91C7\u53D6\u63AA\u65BD\u7F13\u89E3
                        \u786E\u8BA4\u653B\u51FB\u7C7B\u578B\u540E\uFF0C\u6211\u4EEC\u53EF\u4EE5\u9488\u5BF9\u5F53\u524D\u653B\u51FB\u6D41\u91CF\u9650\u5236\u8BBF\u95EE\u901F\u7387\uFF0C\u8C03\u6574\u5B89\u5168\u8BBE\u5907\u7684\u9632\u62A4\u7B56\u7565\u3002

                        \u901A\u8FC7\u8BBE\u5907\u7684\u8BB0\u5F55\u4FE1\u606F\uFF0C\u5BF9\u8BBF\u95EE\u5F02\u5E38\u7684IP\u5730\u5740\u8FDB\u884C\u5C01\u5835\u3002

                        \u5982\u679C\u6D41\u91CF\u8FDC\u8FDC\u8D85\u51FA\u51FA\u53E3\u5E26\u5BBD\uFF0C\u5EFA\u8BAE\u8054\u7CFB\u8FD0\u8425\u5546\u8FDB\u884C\u6D41\u91CF\u6E05\u6D17\u3002

                \u6EAF\u6E90\u5206\u6790
                        123

                \u540E\u7EED\u9632\u62A4\u5EFA\u8BAE
                        \u670D\u52A1\u5668\u9632\u62A4
                                123
                                123
                        \u7F51\u7EDC\u9632\u62A4\u4E0E\u5B89\u5168\u76D1\u6D4B
                                123
                                123
                                123
                        \u5E94\u7528\u7CFB\u7EDF\u9632\u62A4
                                123


                `))},{name:"\u64CD\u4F5C\u6307\u5357",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u521D\u6B65\u9884\u5224
                        \u53EF\u4ECE\u4EE5\u4E0B\u51E0\u65B9\u9762\u5224\u65AD\u670D\u52A1\u5668/\u4E3B\u673A\u662F\u5426\u906D\u53D7DDoS\u653B\u51FB
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B494\u6761

                        \u6848\u4F8B\uFF1A
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026

                \u95EE\u9898\u6392\u67E5
                        \u4E86\u89E3DDoS\u4E8B\u4EF6\u53D1\u751F\u7684\u65F6\u95F4

                        \u4E86\u89E3\u7CFB\u7EDF\u67B6\u6784

                        \u4E86\u89E3DDoS\u653B\u51FB\u7684\u5F71\u54CD\u8303\u56F4

                \u4E34\u65F6\u5904\u7F6E\u65B9\u6CD5

                        \u5F53\u6D41\u91CF\u8F83\u5C0F\uFF0C\u4E14\u5728\u670D\u52A1\u5668\u786C\u4EF6\u4E0E\u5E94\u7528\u63A5\u53D7\u8303\u56F4\u5185\uFF0C\u5E76\u4E0D\u5F71\u54CD\u4E1A\u52A1\u65F6\uFF0C\u53EF\u5229\u7528IPTable\u5B9E\u73B0\u8F6F\u4EF6\u5C42\u9632\u62A4\u3002

                        \u5F53\u6D41\u91CF\u8F83\u5927\uFF0C\u81EA\u8EAB\u6709\u6297DDoS\u8BBE\u5907\uFF0C\u4E14\u5728\u8BBE\u5907\u5904\u7406\u8303\u56F4\u5185\uFF0C\u5C0F\u4E8E\u51FA\u53E3\u5E26\u5BBD\u65F6\uFF0C\u53EF\u6839\u636E\u653B\u51FB\u7C7B\u578B\uFF0C\u5229\u7528IPTable\uFF0C\u901A\u8FC7\u8C03\u6574\u9632\u62A4\u7B56\u7565\u3001\u9650\u901F\u7B49\u65B9\u6CD5\u5B9E\u73B0\u8F6F\u4EF6\u5C42\u9632\u62A4\u3002
                                \u82E5\u653B\u51FB\u6301\u7EED\u5B58\u5728\uFF0C\u5219\u53EF\u5728\u51FA\u53E3\u8BBE\u5907\u914D\u7F6E\u9ED1\u6D1E\u7B49\u9632\u62A4\u7B56\u7565\uFF0C\u6216\u63A5\u5165CDN\u9632\u62A4\u3002

                        \u5F53\u9047\u5230\u8D85\u5927\u6D41\u91CF\uFF0C\u8D85\u51FA\u51FA\u53E3\u5E26\u5BBD\u53CA\u9632\u62A4\u8BBE\u5907\u80FD\u529B\u65F6\uFF0C\u5219\u5EFA\u8BAE\u7533\u8BF7\u8FD0\u8425\u5546\u6E05\u6D17\u3002

                \u7814\u5224\u6EAF\u6E90
                        123


                \u6E05\u9664\u52A0\u56FA
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B497\u6761

                `))},{name:"\u5904\u7F6E\u6848\u4F8B",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u4E8B\u4EF6\u80CC\u666F

                \u4E8B\u4EF6\u5904\u7F6E

                \u6839\u9664\u53CA\u6062\u590D



                `))}]},{name:"\u6570\u636E\u6CC4\u9732",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u6982\u8FF0",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u4EE5\u3010\u5947\u5B89\u4FE1\u3011\u4E3A\u4F8B\uFF1A
                        \u786E\u8BA4\u662F\u5426\u4E3A\u6570\u636E\u6CC4\u9732\u5B89\u5168\u4E8B\u4EF6\u4E3B\u8981\u4F9D\u636E\u4EE5\u4E0B\u4E09\u6761\u57FA\u672C\u539F\u5219\u3002
                                \uFF081\uFF09\u8FDD\u53CD\u673A\u5BC6\u6027\uFF1A\u672A\u6388\u6743\u6216\u610F\u5916\u62AB\u9732\u673A\u5BC6\u6570\u636E\u3002
                                \uFF082\uFF09\u8FDD\u53CD\u53EF\u7528\u6027\uFF1A\u610F\u5916\u4E22\u5931\u6570\u636E\u8BBF\u95EE\u6743\u6216\u5BF9\u673A\u5BC6\u6570\u636E\u9020\u6210\u4E0D\u53EF\u9006\u8F6C\u7684\u7834\u574F\u3002
                                \uFF083\uFF09\u8FDD\u53CD\u5B8C\u6574\u6027\uFF1A\u673A\u5BC6\u6570\u636E\u672A\u6388\u6743\u6216\u610F\u5916\u53D8\u66F4\u3002

                        \u6570\u636E\u6CC4\u9732\u9014\u5F84
                                \u5916\u90E8\u6CC4\u9732
                                        \u4F9B\u5E94\u94FE\u6CC4\u9732
                                                \u81EA\u8EAB\u4F9B\u5E94\u94FE\u6CC4\u9732
                                                \u7B2C\u4E09\u65B9\u4F9B\u5E94\u5546\u6CC4\u9732

                                        \u4E92\u8054\u7F51\u654F\u611F\u4FE1\u606F\u6CC4\u9732
                                                \u641C\u7D22\u5F15\u64CE
                                                \u516C\u5F00\u7684\u4EE3\u7801\u4ED3\u5E93
                                                \u7F51\u76D8
                                                \u793E\u4EA4\u7F51\u7EDC

                                        \u4E92\u8054\u7F51\u5E94\u7528\u7CFB\u7EDF\u6CC4\u9732

                                \u5185\u90E8\u6CC4\u9732
                                        \u5185\u90E8\u4EBA\u5458\u7A83\u5BC6\uFF08\u4E3B\u52A8\u6CC4\u5BC6\uFF09
                                        \u7EC8\u7AEF\u6728\u9A6C\u7A83\u53D6
                                        \u57FA\u7840\u652F\u6491\u5E73\u53F0\u6CC4\u9732
                                        \u5185\u90E8\u5E94\u7528\u7CFB\u7EDF\u6CC4\u9732

                        \u6570\u636E\u6CC4\u9732\u9632\u8303
                                \u6570\u636E\u5916\u90E8\u6CC4\u9732\u9632\u8303
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B493\u6761

                                \u6570\u636E\u5185\u90E8\u6CC4\u9732\u9632\u8303
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B494\u6761

                \u4EE5\u3010\u5B89\u6052\u3011\u670D\u52A1\u6D41\u7A0B\u4E3A\u4F8B\uFF1A
                        \u53C2\u8003\u8D44\u6599\uFF1A    https://www.dbappsecurity.com.cn/product/cloud1901.html
                        1.\u4E8B\u524D\u9632\u5FA1
                            \uFF08\u524D\u9762\u7684\u57FA\u672C\u662F\u5E9F\u8BDD\uFF0C\u6700\u540E\u4E00\u53E5\u8FD8\u6709\u70B9\u7528\uFF09
                                \u5B89\u6052\u4FE1\u606FAPT\u4EA7\u54C1\uFF0C\u5BF9 \u7F51\u7EDC\u4E2D\u4F20\u8F93 \u7684\u5DF2\u77E5\u6F0F\u6D1E\u3001\u672A\u516C\u5F00\u6F0F\u6D1E\u7684\u653B\u51FB\u8FDB\u884C\u9632\u5FA1\uFF0C\u53EF\u4EE5\u76D1\u6D4B\u7F51\u7EDC\u4E2D\u9488\u5BF9 \u6570\u636E\u7A83\u53D6 \u7684\u653B\u51FB\uFF0C\u51C6\u786E\u5B9A\u4F4D \u6CC4\u5BC6\u8D44\u4EA7\u3002

                        2.\u4E8B\u4EF6\u786E\u8BA4
                            \u5728\u7528\u6237\u7591\u4F3C \u6570\u636E\u6CC4\u9732\u65F6\uFF0C\u5E94\u6025\u54CD\u5E94\u5DE5\u7A0B\u5E08\u4E0E\u7528\u6237\u4EA4\u6D41 \u4E8B\u4EF6\u5177\u4F53\u8BE6\u60C5\uFF0C\u5E76\u8BB0\u5F55\u6CC4\u9732\u6570\u636E\uFF0C\u6839\u636E\u4E0E\u7528\u6237\u6C9F\u901A\u7684\u60C5\u51B5\u4E0E\u7CFB\u7EDF\u3001\u6570\u636E\u5E93\u5B9E\u9645\u60C5\u51B5\uFF0C\u5BF9\u4E8B\u4EF6\u8FDB\u884C\u5224\u65AD\u3002
                        3.\u4E8B\u4EF6\u5206\u6790
                            \u4ECE\uFF0C\u6570\u636E\u5E93\u64CD\u4F5C\u548C\u67E5\u8BE2 \u65E5\u5FD7\u3001\u670D\u52A1\u5668\u8FDB\u7A0B\u3001\u670D\u52A1\u5668 \u548C \u7F51\u7EDC\u65E5\u5FD7\u3001\u53EF\u7591\u6587\u4EF6 \u7B49\u65B9\u5F0F\uFF0C\u5206\u6790 \u653B\u51FB\u8005 \u7684\u521D\u59CB\u653B\u51FB\u8DEF\u5F84\u3002
                        4.\u4E8B\u4E2D\u5904\u7406
                            \u2460 \u4E8B\u4EF6\u5206\u6790\u5B8C\u6210\u540E\uFF0C\u6839\u636E\u5206\u6790\u7684\u7ED3\u679C\uFF0C\u5224\u65AD \u653B\u51FB\u8005\u653B\u51FB\u7684\u7CFB\u7EDF \u6216\u6570\u636E\u5E93\u3002
                            \u2461 \u5148\u5C06\u653B\u51FB\u8005\u4E0A\u4F20\u7684\u6076\u610F\u6587\u4EF6\u5907\u4EFD\uFF0C\u518D\u8FDB\u884C\u6076\u610F\u6587\u4EF6\u7684\u5220\u9664\u5904\u7406\u3002
                            \u2462 \u5BF9\u6570\u636E\u5E93\u6267\u884C\u7684\u8BED\u53E5 \u8FDB\u884C\u67E5\u8BE2\uFF0C\u6062\u590D\u6570\u636E\u5E93\u5185\u5BB9\u3001\u5220\u9664\u65E0\u7528\u6570\u636E\u3002
                            \u2463 \u5BF9 \u9020\u6210\u670D\u52A1\u5668\u3010\u88AB\u79CD\u9A6C\u3011 \u6216 \u6570\u636E\u5E93\u3010\u88AB\u8131\u5E93\u3011 \u7684\u6F0F\u6D1E\uFF0C\u8FDB\u884C\u52A0\u56FA\u4FEE\u590D\u3002
                            \u2464 \u5BF9 \u670D\u52A1\u5668 \u6216 \u6570\u636E\u5E93 \u5B58\u5728\u5F31\u53E3\u4EE4\u7684\u8D26\u53F7\uFF0C\u8FDB\u884C\u5220\u9664 \u6216 \u5F3A\u5236\u4FEE\u6539\u5BC6\u7801\u3002
                            \u2465 \u9632\u6B62\u7CFB\u7EDF \u6216 \u670D\u52A1\u5668\uFF0C\u88AB\u4E8C\u6B21\u5165\u4FB5 \u9020\u6210\u7684 \u6570\u636E\u4E8C\u6B21\u6CC4\u9732\u3002
                            \u2466 \u6839\u636E \u653B\u51FB\u7EBF\u7D22 \u5BFB\u627E \u5077\u53D6\u6570\u636E\u8005\u3002
                        5.\u5E94\u6025\u54CD\u5E94\u5206\u6790\u62A5\u544A
                            \u5B8C\u6210 \u4EE5\u4E0A\u5E94\u6025\u64CD\u4F5C \u540E\uFF0C\u8FDB\u884C\u3010\u73B0\u573A\u53D6\u8BC1\u3011\u3002
                            \u4E4B\u540E \u6839\u636E\u5B9E\u9645\u60C5\u51B5\u7F16\u5199 \u300A\u6570\u636E\u6CC4\u9732\u5E94\u6025\u54CD\u5E94\u62A5\u544A\u300B\uFF0C\u5BF9\u6574\u4E2A\u4E8B\u4EF6\u7684\u73B0\u8C61\u3001\u5206\u6790\u5904\u7F6E\u8FC7\u7A0B\u3001\u5904\u7F6E\u7ED3\u679C\u3001\u4E8B\u4EF6\u53D1\u751F\u539F\u56E0\uFF0C\u8FDB\u884C\u9610\u8FF0
                            \u7ED9\u51FA\u76F8\u5173\u5B89\u5168\u5EFA\u8BAE\uFF0C\u534F\u52A9\u7528\u6237\u8FDB\u884C \u6F0F\u6D1E\u6574\u6539\u3001\u4E3B\u673A\u52A0\u56FA\u3002


                `))},{name:"\u5904\u7F6E\u65B9\u6CD5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u53D1\u73B0\u6570\u636E\u6CC4\u9732
                        \u5916\u90E8\u53CD\u9988
                                123
                        \u76D1\u7BA1\u901A\u62A5
                                123
                        \u81EA\u884C\u53D1\u73B0
                                123

                \u68B3\u7406\u57FA\u672C\u60C5\u51B5
                        123

                \u5224\u65AD\u6CC4\u9732\u9014\u5F84
                        123

                \u6570\u636E\u6CC4\u9732\u5904\u7F6E
                        \u4E3E\u4F8B\uFF1A
                                123

                `))},{name:"\u5E38\u7528\u5DE5\u5177",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u76D1\u63A7\u4E92\u8054\u7F51\u6D41\u51FA",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                          \u8D44\u6599\uFF1A
                              \u4E00\u4EFD\u6E05\u5355\uFF1A
                                  \u4E3B\u6D41\u4EE3\u7801\u6CC4\u9732\u76D1\u63A7\u9879\u76EE\u6A2A\u5411\u8BC4\u6D4B - FreeBuf\u7F51\u7EDC\u5B89\u5168\u884C\u4E1A\u95E8\u6237
                                      https://www.freebuf.com/sectool/276638.html

                              \u3010GSIL\u3011\u7684\u4F5C\u8005\u3010FEEI\u3011\uFF0C\u5BF9\u8FD9\u4E00\u5757\u4EA7\u54C1\uFF0C\u505A\u51FA\u7684\u6DF1\u5165\u5206\u6790\uFF1A
                                  GitHub\u654F\u611F\u4FE1\u606F\u6CC4\u9732\u76D1\u63A7 - \u4F01\u4E1A\u5B89\u5168\u6700\u4F73\u5B9E\u8DF5
                                      https://esbp.feei.cn/vulnerabilities/gsil


                          \u7801\u5C0F\u516D       \uFF08\u542C\u8BF4\uFF0C\u6BD4HawkEye\u8981\u597D\uFF09
                              \u53C2\u8003\u8D44\u6599\uFF1A
                                  https://github.com/4x99/code6
                              \u8FD0\u4F5C\u539F\u7406\uFF1A
                                  \u53EF\u80FD\u8FD8\u662F\u8D70\u3010\u5173\u952E\u5B57\u3011

                          HawkEye
                              \u53C2\u8003\u8D44\u6599\uFF1A
                                  GitHub\u5B98\u65B9\u4ED3\u5E93\uFF1Ahttps://github.com/0xbug/Hawkeye
                              \u4ECB\u7ECD\uFF1A
                                  \u76D1\u63A7GitHub\u4EE3\u7801\u5E93\uFF0C\u53CA\u65F6\u53D1\u73B0\u5458\u5DE5\u6258\u7BA1\u516C\u53F8\u4EE3\u7801\u5230GitHub\u7684\u884C\u4E3A\uFF0C\u5E76\u9884\u8B66\uFF0C\u964D\u4F4E\u4EE3\u7801\u6CC4\u9732\u98CE\u9669\u3002
                                  \u4E00\u4E9B\uFF1A
                                      \u4F01\u4E1AGitHub\u4FE1\u606F\u68C0\u6D4B
                                      \u544A\u8B66\u63A8\u9001
                                      \u5468\u671F\u6027\u76D1\u63A7
                                      Web\u7AEF\u7BA1\u7406
                              \u8FD0\u884C\u539F\u7406\uFF1A
                                  \uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F
                          `))},{name:"\u76D1\u63A7\u672C\u5730\u6D41\u51FA",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                    Windows

                            SysMom
                                    \u4ECB\u7ECD\uFF1A
                                            \u662F\u4E00\u6B3E\uFF0C\u5FAE\u8F6F\u51FA\u54C1\u7684\uFF0C\u8F7B\u91CF\u7EA7\u7CFB\u7EDF\u76D1\u63A7\u5DE5\u5177

                                            \u867D\u7136\u540E\u9762\u4E5F\u63A8\u51FA\u4E86 Linux\u7248\u672C \uFF0C\u4F46\u53EA\u6709\u4E00\u5E74\u591A\u7684\u65F6\u95F4\uFF0C\u4F7F\u7528\u7684\u8FD8\u6BD4\u8F83\u5C11\u3002

                                    \u8F85\u52A9\u5206\u6790\u5DE5\u5177
                                            Sysmon View
                                                    Sysmon\u65E5\u5FD7\u53EF\u89C6\u5316\u5DE5\u5177
                                            Sysmon Shell
                                                    Sysmon\u914D\u7F6E\u6587\u4EF6\u751F\u6210\u5DE5\u5177
                                            Sysmon Box
                                                    Sysmon\u7F51\u7EDC\u6355\u83B7\u65E5\u5FD7\u8BB0\u5F55\u5DE5\u5177

                                    \u76D1\u63A7\u5185\u5BB9

                                            \u8FDB\u7A0B
                                                    ProcessCreate\uFF0C\u8FDB\u7A0B\u521B\u5EFA
                                                    ProcessTerminal\uFF0C\u8FDB\u7A0B\u7ED3\u675F
                                                    ProcessAccess\uFF0C\u8FDB\u7A0B\u8BBF\u95EE
                                            \u7EBF\u7A0B
                                                    CreateRemoteThread\uFF0C\u8FDC\u7A0B\u7EBF\u7A0B\u521B\u5EFA
                                            \u6587\u4EF6
                                                    FileCreate\uFF0C\u6587\u4EF6\u521B\u5EFA
                                                    FileCreateTime\uFF0C\u6587\u4EF6\u521B\u5EFA\u65F6\u95F4
                                                    FileCreateStream\uFF0C\u6587\u4EF6\u6D41\u521B\u5EFA
                                            \u7F51\u7EDC
                                                    NetworkConnect\uFF0C\u7F51\u7EDC\u8FDE\u63A5
                                            \u9A71\u52A8
                                                    DriverLoad\uFF0C\u9A71\u52A8\u52A0\u8F7D
                                            \u9A71\u52A8\u5668
                                                    RawAccessRead\uFF0C\u9A71\u52A8\u5668\u8BFB\u53D6
                                            \u955C\u50CF
                                                    ImageLoad\uFF0C\u955C\u50CF\u52A0\u8F7D
                                            \u6CE8\u518C\u8868
                                                    RegistryEvent\uFF0C\u6CE8\u518C\u8868\u4E8B\u4EF6

                          `))}]},{name:"\u64CD\u4F5C\u6307\u5357",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u521D\u6B65\u7814\u5224
                        \u6536\u96C6\u57FA\u7840\u4FE1\u606F
                                \u9996\u5148\u53EF\u53CA\u65F6\u4E86\u89E3\u6570\u636E\u6CC4\u9732\u4E8B\u4EF6\u53D1\u751F\u7684\u65F6\u95F4\u3001\u6CC4\u9732\u7684\u5185\u5BB9\u3001\u6570\u636E\u5B58\u50A8\u7684\u4F4D\u7F6E\u3001\u6CC4\u9732\u6570\u636E\u7684\u8868\u73B0\u5F62\u5F0F\u7B49\u3002
                                        \u5177\u4F53\u53EF\u4ECE\u4EE5\u4E0B\u516D\u65B9\u9762\uFF085W+1H\uFF09\u4E86\u89E3\u6570\u636E\u6CC4\u9732\u7684\u73B0\u72B6\u3002
                                                \uFF081\uFF09What\u2014\u2014\u4E86\u89E3\u6CC4\u9732\u4E86\u4EC0\u4E48\u6570\u636E\uFF0C\u6CC4\u9732\u6570\u636E\u7684\u8868\u73B0\u5F62\u5F0F\u53CA\u91CF\u7EA7\u3002
                                                \uFF082\uFF09Where\u2014\u2014\u4E86\u89E3\u5728\u4EC0\u4E48\u4F4D\u7F6E\u53EF\u4EE5\u8BBF\u95EE\u548C\u4E0B\u8F7D\u5230\u76F8\u5173\u7684\u6CC4\u9732\u6570\u636E\u3002
                                                \uFF083\uFF09When\u2014\u2014\u4E86\u89E3\u6570\u636E\u6CC4\u9732\u7684\u5927\u81F4\u65F6\u95F4\u3002
                                                \uFF084\uFF09Who\u2014\u2014\u4E86\u89E3\u53EF\u4EE5\u63A5\u89E6\u5230\u8FD9\u4E9B\u6570\u636E\u7684\u4EBA\u5458\u3002
                                                \uFF085\uFF09Why\u2014\u2014\u4E86\u89E3\u4E3A\u4EC0\u4E48\u4F1A\u6CC4\u9732\u8BE5\u6570\u636E\uFF0C\u8BE5\u6570\u636E\u6CC4\u9732\u540E\u53EF\u80FD\u9020\u6210\u7684\u5F71\u54CD\u3002
                                                \uFF086\uFF09How\u2014\u2014\u6839\u636E\u4E86\u89E3\u7684\u73B0\u72B6\u521D\u6B65\u5224\u65AD\u6570\u636E\u662F\u5982\u4F55\u6CC4\u9732\u7684\uFF0C\u7F29\u5C0F\u6392\u67E5\u8303\u56F4\u3002

                        \u7F51\u7EDC\u73AF\u5883\u786E\u8BA4
                                \u4E13\u7528\u751F\u4EA7\u7F51\u7EDC
                                        \uFF081\uFF09\u4E0E\u5916\u90E8\u5B8C\u5168\u9694\u79BB\uFF1B
                                        \uFF082\uFF09\u901A\u8FC7\u4E13\u7528\u7EBF\u8DEF\u4E0E\u5916\u90E8\u7CFB\u7EDF\uFF08\u975E\u4E92\u8054\u7F51\uFF09\u8FDB\u884C\u6570\u636E\u4EA4\u6362\uFF1B
                                        \uFF083\uFF09\u901A\u8FC7\u865A\u62DF\u4E13\u7528\u7F51\u7EDC\uFF08VPN\uFF09\u4E0E\u4E92\u8054\u7F51\u8FDB\u884C\u6570\u636E\u4EA4\u6362\uFF1B
                                        \uFF084\uFF09\u901A\u8FC7\u7F51\u95F8\u7B49\u9694\u79BB\u624B\u6BB5\u4E0E\u4E92\u8054\u7F51\u8FDB\u884C\u6570\u636E\u4EA4\u6362\u3002
                                \u4E92\u8054\u7F51\u73AF\u5883\u7F51\u7EDC
                                        \uFF081\uFF09\u90E8\u5206\u91CD\u8981\u8D44\u4EA7\u76F4\u63A5\u66B4\u9732\u4E8E\u4E92\u8054\u7F51\u4E2D\uFF1B
                                        \uFF082\uFF09\u6240\u6709\u91CD\u8981\u8D44\u4EA7\u76F4\u63A5\u66B4\u9732\u4E8E\u4E92\u8054\u7F51\u4E2D\u3002

                        \u5DF2\u6709\u5B89\u5168\u63AA\u65BD\u786E\u8BA4
                                \u5FEB\u901F\u786E\u8BA4\u73B0\u573A\u7F51\u7EDC\u73AF\u5883\u4E2D\u5B89\u5168\u63AA\u65BD\u914D\u5907\u3001\u7BA1\u63A7\u8303\u56F4\u53CA\u529F\u80FD\u914D\u7F6E\u60C5\u51B5\uFF0C\u4E3A\u540E\u7EED\u786E\u7ACB\u5904\u7F6E\u7B56\u7565\u63D0\u4F9B\u4F9D\u636E\u548C\u652F\u6491\u3002

                                \u91CD\u70B9\u5BF9\u4EE5\u4E0B\u5185\u5BB9\u8FDB\u884C\u786E\u8BA4\u3002
                                        \uFF081\uFF09\u4E13\u7528\u6570\u636E\u6CC4\u9732\u9632\u62A4\u7C7B\u4EA7\u54C1\uFF1A\u786E\u8BA4\u6570\u636E\u6CC4\u9732\u884C\u4E3A\u76D1\u6D4B\u3001\u9884\u8B66\u3001\u963B\u65AD\u60C5\u51B5\u3002
                                        \uFF082\uFF09\u5B89\u5168\u5BA1\u8BA1\u7C7B\u4EA7\u54C1\uFF1A\u786E\u8BA4\u6570\u636E\u5E93\u5BA1\u8BA1\u3001\u5E94\u7528\u5BA1\u8BA1\u3001\u8FD0\u7EF4\u64CD\u4F5C\u5BA1\u8BA1\u60C5\u51B5\u3002
                                        \uFF083\uFF09\u5165\u4FB5\u68C0\u6D4B\u7C7B\u4EA7\u54C1\uFF1A\u786E\u8BA4\u5165\u4FB5\u653B\u51FB\u76D1\u6D4B\u3001\u9884\u8B66\u60C5\u51B5\u3002
                                        \uFF084\uFF09\u6D41\u91CF\u5206\u6790\u7C7B\u4EA7\u54C1\uFF08\u5982\u5929\u773C\uFF09\uFF1A\u786E\u8BA4\u653B\u51FB\u548C\u5F02\u5E38\u884C\u4E3A\u76D1\u6D4B\u3001\u9884\u8B66\u60C5\u51B5\u3002
                                        \uFF085\uFF09\u786E\u8BA4\u5E94\u7528\u7CFB\u7EDF\u3001\u670D\u52A1\u5668\u3001\u7EC8\u7AEF\u7B49\u65E5\u5FD7\u60C5\u51B5\u3002

                \u786E\u5B9A\u6392\u67E5\u8303\u56F4\u548C\u76EE\u6807
                        \u4F9D\u636E\u6536\u96C6\u7684\u57FA\u7840\u4FE1\u606F\uFF0C\u5206\u6790\u548C\u786E\u5B9A\u672C\u6B21\u5E94\u6025\u54CD\u5E94\u7684\u8303\u56F4\u548C\u76EE\u6807\uFF0C\u53EF\u4F9D\u636E\u5982\u4E0B\u539F\u5219\u3002
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B492\u6761

                \u5EFA\u7ACB\u7B56\u7565
                        \u5224\u5B9A\u6570\u636E\u6CC4\u9732\u4E8B\u4EF6\u7C7B\u578B
                                \u4F9D\u636E\u6CC4\u9732\u6570\u636E\u7684\u7C7B\u578B\u3001\u91CF\u7EA7\u53CA\u7EC4\u7F51\u7C7B\u578B\uFF0C\u53EF\u521D\u6B65\u5224\u5B9A\u6570\u636E\u6CC4\u9732\u4E8B\u4EF6\u7C7B\u578B\uFF08\u4E3B\u52A8/\u88AB\u52A8\uFF09\uFF0C\u5224\u5B9A\u89C4\u5219\u5982\u4E0B\uFF1A
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B492\u6761

                \u786E\u7ACB\u5E94\u6025\u54CD\u5E94\u5904\u7F6E\u7B56\u7565
                        \u4E3B\u52A8\u6CC4\u9732
                                [\u56FE]
                                \u4E3B\u52A8\u6CC4\u9732\u6392\u67E5\u987A\u5E8F
                                        \u4E13\u7528\u6570\u636E\u6CC4\u9732\u9632\u62A4\u7C7B \u4EA7\u54C1\u65E5\u5FD7\u6392\u67E5 \u2014\u2014\u2014\u2014 \u5B89\u5168\u5BA1\u8BA1\u7C7B \u4EA7\u54C1\u65E5\u5FD7\u6392\u67E5 \u2014\u2014\u2014\u2014 \u5E94\u7528\u7CFB\u7EDF\u3001\u670D\u52A1\u5668\u3001\u7EC8\u7AEF\u7B49 \u65E5\u5FD7\u6392\u67E5

                        \u88AB\u52A8\u6CC4\u9732
                                [\u56FE]
                                \u88AB\u52A8\u6CC4\u9732\u6392\u67E5\u987A\u5E8F
                                        \u5E94\u7528\u7CFB\u7EDF\u3001\u670D\u52A1\u5668\u3001\u7EC8\u7AEF\u7B49 \u65E5\u5FD7\u6392\u67E5 \u2014\u2014\u2014\u2014 \u5165\u4FB5\u68C0\u6D4B\u7C7B\u3001\u6D41\u91CF\u5206\u6790\u7C7B \u4EA7\u54C1\u65E5\u5FD7\u6392\u67E5 \u2014\u2014\u2014\u2014 \u5B89\u5168\u5BA1\u8BA1\u7C7B \u4EA7\u54C1\u65E5\u5FD7\u6392\u67E5

                \u7CFB\u7EDF\u6392\u67E5
                        \u4E13\u7528\u6570\u636E\u6CC4\u9732\u9632\u62A4\u7C7B\u4EA7\u54C1\u65E5\u5FD7\u6392\u67E5
                                \u5206\u6790\u901A\u8FC7\u7535\u5B50\u90AE\u4EF6\u3001QQ\u3001MSN\u7B49\u7F51\u7EDC\u9014\u5F84\u8FDB\u884C\u6570\u636E\u5916\u53D1\u7684\u65E5\u5FD7\uFF0C\u4F9D\u636E\u88AB\u6CC4\u9732\u6570\u636E\u7684\u7279\u5F81\u3001\u65F6\u95F4\u3001\u91CF\u7EA7\u7B49\u8981\u7D20\uFF0C\u53D1\u73B0\u5F02\u5E38\u7684\u6570\u636E\u5916\u53D1\u884C\u4E3A
                                \u5206\u6790\u91CD\u8981\u7EC8\u7AEF\u7684\u6587\u4EF6\u6253\u5370\u3001\u590D\u5370\uFF0C\u4EE5\u53CA\u901A\u8FC7U\u76D8\u7B49\u79FB\u52A8\u5B58\u50A8\u4ECB\u8D28\u8FDB\u884C\u6570\u636E\u62F7\u8D1D\u7684\u65E5\u5FD7\uFF0C\u4F9D\u636E\u88AB\u6CC4\u9732\u6570\u636E\u7684\u7279\u5F81\u3001\u65F6\u95F4\u3001\u91CF\u7EA7\u7B49\u8981\u7D20\uFF0C\u53D1\u73B0\u5F02\u5E38\u7684\u6587\u4EF6\u6253\u5370\u3001\u590D\u5370\u53CA\u6570\u636E\u62F7\u8D1D\u884C\u4E3A
                        \u5B89\u5168\u5BA1\u8BA1\u7C7B\u4EA7\u54C1\u65E5\u5FD7\u6392\u67E5
                                \u5206\u6790\u9488\u5BF9\u91CD\u8981\u670D\u52A1\u5668\u3001\u6570\u636E\u5E93\u3001\u5E94\u7528\u7CFB\u7EDF\u7684\u8BBF\u95EE\u65E5\u5FD7
                                        \u4F9D\u636E\u88AB\u6CC4\u9732\u6570\u636E\u7684\u5173\u952E\u5B57\u6BB5\u3001\u7279\u5F81\u3001\u65F6\u95F4\u3001\u91CF\u7EA7\u7B49\u8981\u7D20\uFF0C\u53D1\u73B0\u5F02\u5E38\u7684\u6570\u636E\u64CD\u4F5C\u548C\u8BBF\u95EE\u884C\u4E3A
                                                \u5982\u9488\u5BF9\u88AB\u6CC4\u9732\u6570\u636E\u7684\u67E5\u8BE2\u3001\u5BFC\u51FA\u64CD\u4F5C\u7B49
                        \u5165\u4FB5\u68C0\u6D4B\u7C7B\u4EA7\u54C1\u65E5\u5FD7\u6392\u67E5
                                \u63D0\u53D6\u5728\u6392\u67E5\u8303\u56F4\u5185\u7684\u670D\u52A1\u5668\u3001\u7EC8\u7AEF\u3001\u5E94\u7528\u7CFB\u7EDF\u7B49\u7684\u544A\u8B66\u65E5\u5FD7\uFF0C\u5E76\u8FDB\u884C\u5206\u6790\uFF0C\u53D1\u73B0\u53EF\u80FD\u7A83\u53D6\u6570\u636E\u7684\u653B\u51FB\u884C\u4E3A\u3002
                                        \u91CD\u70B9\u6392\u67E5\u548C\u5206\u6790SQL\u6CE8\u5165\u3001Webshell\u7B49\u53EF\u83B7\u53D6\u6570\u636E\u7684\u653B\u51FB\u65E5\u5FD7\u3002
                        \u6D41\u91CF\u5206\u6790\u7C7B\u4EA7\u54C1\u65E5\u5FD7\u6392\u67E5
                                \u5206\u6790\u91CD\u8981\u670D\u52A1\u5668\u3001\u7EC8\u7AEF\u3001\u5E94\u7528\u7CFB\u7EDF\u7B49\u7684\u6D41\u91CF\u6570\u636E\uFF0C\u53D1\u73B0\u53EF\u80FD\u7A83\u53D6\u6570\u636E\u7684\u653B\u51FB\u884C\u4E3A\u3001\u5F02\u5E38\u8BBF\u95EE\u4E0E\u64CD\u4F5C\u884C\u4E3A\u3001\u75C5\u6BD2\u6728\u9A6C\u7B49\u3002
                        \u5E94\u7528\u7CFB\u7EDF\u3001\u670D\u52A1\u5668\u3001\u7EC8\u7AEF\u7B49\u65E5\u5FD7\u6392\u67E5
                                \u5BF9\u7EC8\u7AEF\u3001\u670D\u52A1\u5668\uFF08\u5305\u62EC\u64CD\u4F5C\u7CFB\u7EDF\u65E5\u5FD7\u3001\u4E2D\u95F4\u4EF6\u65E5\u5FD7\u3001\u6570\u636E\u5E93\u65E5\u5FD7\u7B49\uFF09\u3001\u8FDB\u7A0B\u3001\u811A\u672C\u7A0B\u5E8F\u3001\u8D26\u53F7\u7B49\u8FDB\u884C\u6392\u67E5\u548C\u5206\u6790\uFF0C\u53D1\u73B0\u53EF\u80FD\u7A83\u53D6\u6570\u636E\u7684\u5165\u4FB5\u884C\u4E3A\u3001\u75C5\u6BD2\u6728\u9A6C\u53CA\u5F02\u5E38\u7684\u5386\u53F2\u64CD\u4F5C\u547D\u4EE4\u7B49\uFF1B
                                \u5BF9\u5E94\u7528\u7CFB\u7EDF\u3001\u7F51\u7AD9\u3001\u670D\u52A1\u5668\u3001\u7EC8\u7AEF\u7B49\u8FDB\u884C\u626B\u63CF\u3001\u6D4B\u8BD5\uFF0C\u53D1\u73B0\u53EF\u5229\u7528\u7684\u3001\u53EF\u80FD\u5BFC\u81F4\u6570\u636E\u6CC4\u9732\u7684\u5B89\u5168\u6F0F\u6D1E\uFF0C\u5982SQL\u6CE8\u5165\u6F0F\u6D1E\u3001\u8FDC\u7A0B\u547D\u4EE4\u6267\u884C\u6F0F\u6D1E\u3001\u4EFB\u610F\u6587\u4EF6\u4E0A\u4F20\u6F0F\u6D1E\u3001\u9274\u6743\u53CA\u8D8A\u6743\u6F0F\u6D1E\u7B49\uFF1B
                                \u5BF9\u5E94\u7528\u7CFB\u7EDF\u65E5\u5FD7\uFF08\u5E94\u7528\u7CFB\u7EDF\u5177\u5907\u65E5\u5FD7\u529F\u80FD\uFF09\u8FDB\u884C\u5206\u6790\uFF0C\u53D1\u73B0\u4EBA\u5458\u7684\u5F02\u5E38\u64CD\u4F5C\u548C\u8BBF\u95EE\u884C\u4E3A\u3002


                `))},{name:"\u5904\u7F6E\u6848\u4F8B",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u4E8B\u4EF6\u80CC\u666F

                \u521D\u6B65\u7814\u5224

                \u786E\u5B9A\u6392\u67E5\u8303\u56F4\u548C\u76EE\u6807

                \u5EFA\u7ACB\u5E94\u6025\u54CD\u5E94\u5904\u7F6E\u7B56\u7565
                        123

                \u6570\u636E\u6CC4\u9732\u6392\u67E5
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B493\u6761

                \u9632\u62A4\u5EFA\u8BAE
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B494\u6761

                `))},{name:"\u96F6\u661F\u7684\u4E00\u70B9\u7B14\u8BB0\u5185\u5BB9 \u2014\u2014\u2014\u2014 \u6392\u67E5\u65B9\u5F0F",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u6587\u4EF6\u6392\u67E5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(""))},{name:"\u8FDB\u7A0B\u6392\u67E5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(""))},{name:"\u65E5\u5FD7\u6392\u67E5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(""))},{name:"\u540E\u95E8\u67E5\u627E",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(""))}]}]},{name:"\u6D41\u91CF\u52AB\u6301",desc:u.a.createElement(u.a.Fragment,null),steps:[{name:"\u6982\u8FF0",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u6D41\u91CF\u52AB\u6301\u7B80\u4ECB
                        \u5B83\u662F\u4E00\u79CD\u901A\u8FC7\u5728\u5E94\u7528\u7CFB\u7EDF\u4E2D\u690D\u5165\u6076\u610F\u4EE3\u7801\u3001\u5728\u7F51\u7EDC\u4E2D\u90E8\u7F72\u6076\u610F\u8BBE\u5907\u3001\u4F7F\u7528\u6076\u610F\u8F6F\u4EF6\u7B49\u624B\u6BB5\uFF0C
                                \u63A7\u5236\u5BA2\u6237\u7AEF\u4E0E\u670D\u52A1\u7AEF\u4E4B\u95F4\u7684\u6D41\u91CF\u901A\u4FE1\u3001\u7BE1\u6539\u6D41\u91CF\u6570\u636E\u6216\u6539\u53D8\u6D41\u91CF\u8D70\u5411\uFF0C
                                        \u9020\u6210\u975E\u9884\u671F\u884C\u4E3A\u7684\u7F51\u7EDC\u653B\u51FB\u6280\u672F

                        \u6D41\u91CF\u52AB\u6301\u7684\u8868\u73B0\u5F62\u5F0F\uFF1A
                                \u6211\u4EEC\u5728\u65E5\u5E38\u751F\u6D3B\u4E2D\u7ECF\u5E38\u9047\u5230\u7684\u6D41\u6C13\u8F6F\u4EF6\u3001\u5E7F\u544A\u5F39\u7A97\u3001\u7F51\u5740\u8DF3\u8F6C\u7B49\u90FD\u662F\u3002

                        \u6D41\u91CF\u52AB\u6301\u7684\u4E3B\u8981\u7684\u76EE\u7684\u5982\u4E0B\uFF1A
                                \uFF081\uFF09\u5F15\u6D41\u63A8\u5E7F\uFF1B
                                \uFF082\uFF09\u9493\u9C7C\u653B\u51FB\uFF1B
                                \uFF083\uFF09\u8BBF\u95EE\u9650\u5236\uFF1B
                                \uFF084\uFF09\u4FA6\u542C\u7A83\u5BC6\u3002

                \u5E38\u89C1\u6D41\u91CF\u52AB\u6301
                        DNS\u52AB\u6301
                                NS\u52AB\u6301\u53C8\u79F0\u57DF\u540D\u52AB\u6301\uFF0C\u662F\u6307\u63A7\u5236DNS\u67E5\u8BE2\u89E3\u6790\u7684\u8BB0\u5F55\uFF0C\u5728\u52AB\u6301\u7684\u7F51\u7EDC\u4E2D\u62E6\u622ADNS\u8BF7\u6C42\uFF0C\u5206\u6790\u5339\u914D\u8BF7\u6C42\u57DF\u540D\uFF0C\u8FD4\u56DE\u865A\u5047IP\u4FE1\u606F\u6216\u4E0D\u505A\u4EFB\u4F55\u64CD\u4F5C\u4F7F\u8BF7\u6C42\u65E0\u6548\u3002
                                        \u76EE\u7684\u662F\u5C06\u7528\u6237\u5F15\u5BFC\u81F3\u975E\u9884\u671F\u76EE\u6807\uFF0C\u6216\u7981\u6B62\u7528\u6237\u8BBF\u95EE\u3002

                        CDN\u52AB\u6301\uFF08CDN\u7F13\u5B58\u6C61\u67D3\u653B\u51FB\uFF09
                                \u5F02\u5E38HTTP\u8BF7\u6C42\u901A\u5E38\u662F\u4EE5\u4E0B\u4E09\u79CD\u7C7B\u578B\u3002
                                        HTTP\u5934\u90E8\u8FC7\u5927\uFF08HHO\uFF09
                                        HTTP\u5143\u5B57\u7B26\uFF08HMC\uFF09
                                        HTTP\u65B9\u6CD5\u91CD\u5199\uFF08HMO\uFF09

                        HTTP\u52AB\u6301
                                HTTP\u52AB\u6301\u6D41\u7A0B\u5982\u56FE10.1.4\u6240\u793A\uFF0C\u6B65\u9AA4\u5982\u4E0B\uFF1A
                                        [\u56FE]
                                        \uFF081\uFF09\u83B7\u53D6\u7F51\u7EDC\u6D41\u91CF\uFF0C\u5E76\u5728\u5176\u4E2D\u6807\u8BC6\u51FAHTTP\u534F\u8BAE\u6D41\u91CF\uFF1B
                                        \uFF082\uFF09\u62E6\u622A\u670D\u52A1\u5668\u54CD\u5E94\u5305\uFF0C\u5BF9\u54CD\u5E94\u5305\u7684\u5185\u5BB9\u8FDB\u884C\u7BE1\u6539\uFF1B
                                        \uFF083\uFF09\u5C06\u7BE1\u6539\u4E4B\u540E\u7684\u6570\u636E\u5305\u62A2\u5148\u4E8E\u6B63\u5E38\u54CD\u5E94\u5305\u8FD4\u56DE\u7ED9\u5BA2\u6237\u7AEF\uFF1B
                                        \uFF084\uFF09\u5BA2\u6237\u7AEF\u5148\u63A5\u6536\u7BE1\u6539\u7684\u6570\u636E\u5305\uFF0C\u5E76\u5C06\u540E\u9762\u6B63\u5E38\u7684\u54CD\u5E94\u5305\u4E22\u5F03\u3002

                        \u94FE\u8DEF\u5C42\u52AB\u6301
                                TCP\u52AB\u6301
                                        \u4E00\u6B21TCP\u4F1A\u8BDD\u52AB\u6301\u7684\u6D41\u7A0B\u5982\u4E0B\uFF1A
                                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B497\u6761
                                ARP\u52AB\u6301

                \u5E38\u89C1\u653B\u51FB\u573A\u666F
                        DNS\u52AB\u6301
                                \u5E38\u89C1\u7684DNS\u52AB\u6301\u653B\u51FB\u624B\u6CD5\u5206\u4E3A\uFF1A
                                        \u672C\u5730DNS\u52AB\u6301
                                        \u8DEF\u7531\u5668DNS\u52AB\u6301
                                        \u4E2D\u95F4\u4EBADNS\u653B\u51FB
                                        \u6076\u610FDNS\u670D\u52A1\u5668\u653B\u51FB\u3002

                                \u4F8B\u5B50\uFF1A
                                        123


                                \u653B\u51FB\u8303\u56F4\uFF1A
                                        \u5C40\u57DF\u7F51DNS\u52AB\u6301
                                            \u4E2A\u4EBA\u7EC8\u7AEF\u3010\u88AB\u52AB\u6301\u3011

                                            \u4F01\u4E1ADNS\u670D\u52A1\u5668\u3010\u88AB\u52AB\u6301\u3011

                                        \u5E7F\u57DF\u7F51DNS\u52AB\u6301
                                            \u8FD0\u8425\u5546DNS\u3010\u88AB\u52AB\u6301\u3011


                        HTTP\u52AB\u6301
                                \u4E3B\u8981\u76EE\u7684\u5982\u4E0B\uFF1A
                                        \uFF081\uFF09\u55C5\u63A2\u4FA6\u542C\u6D41\u91CF\uFF0C\u4F2A\u9020HTTP\u54CD\u5E94\uFF1B
                                        \uFF082\uFF09\u9493\u9C7C\u653B\u51FB\uFF1B
                                        \uFF083\uFF09\u7070\u4EA7\u5E7F\u544A\u5F15\u6D41\u3002

                                \u653B\u51FB\u65B9\u5F0F\uFF1A
                                        JS\u811A\u672C\u7C7B

                                        \u4E2D\u95F4\u4EF6\u7C7B

                                        \u6076\u610F\u8F6F\u4EF6\u7C7B


                                \u5E38\u89C1\u60C5\u51B5\u5206\u6790\uFF1A
                                        \u56E0\u3010\u94FE\u8DEF\u5C42\u52AB\u6301\u3011\u800C\u9020\u6210\u7684\uFF1A
                                                \u2460 \u83B7\u53D6\u7F51\u7EDC\u6D41\u91CF\uFF0C\u5E76\u5728\u5176\u4E2D\u6807\u8BC6\u51FA\u3010HTTP\u534F\u8BAE\u6D41\u91CF\u3011\u3002
                                                \u2461 \u62E6\u622A \u670D\u52A1\u5668\u54CD\u5E94\u5305\uFF0C\u5BF9 \u54CD\u5E94\u5305 \u7684\u5185\u5BB9\u8FDB\u884C\u7E82\u6539\u3002
                                                \u2462 \u5C06 \u7E82\u6539\u4E4B\u540E \u7684\u6570\u636E\u5305\uFF0C\u62A2\u5148\u4E8E \u6B63\u5E38\u54CD\u5E94\u5305 \u8FD4\u56DE\u7ED9\u5BA2\u6237\u7AEF\u3002
                                                \u2463 \u5BA2\u6237\u7AEF \u5148\u63A5\u53D7\u5230 \u7E82\u6539\u7684\u6570\u636E\u5305\uFF0C\u5C06\u540E\u9762\u6B63\u5E38\u54CD\u5E94\u5305 \u4E22\u5F03\u3002

                                        \u7F51\u7AD9\u3010\u88AB\u653B\u51FB\u8005\u5165\u4FB5\u3011\u540E\u690D\u5165\u3010\u6076\u610F\u4EE3\u7801\u3011
                                                Rammit\u75C5\u6BD2\u7C7B \u7684\u6076\u610F\u7A0B\u5E8F
                                                        \uFF08\u66FE\u611F\u67D3320\u4E07\u53F0\uFF09
                                                \u7F51\u7AD9\u7EDF\u8BA1\u7C7B \u7684JS\u6587\u4EF6
                                                \u7F51\u9875HTML \u88AB\u7E82\u6539
                                                \u4FEE\u6539\u4E86 Web\u5BB9\u5668\u8FDB\u7A0B\uFF08\u5982IIS\uFF09
                                                        \uFF1F\uFF1F\uFF1F

                                \u5904\u7F6E\u65B9\u5F0F
                                        \u7F51\u7AD9\u4F7F\u7528\u3010HTTPS\u8BC1\u4E66\u3011\uFF0C\u8BA9\u5BA2\u6237\u7AEF \u4F7F\u7528HTTPS\u534F\u8BAE \u8FDB\u884C\u8BBF\u95EE
                                        \u62C6\u5206 HTTP \u8BF7\u6C42\u6570\u636E\u5305
                                                \uFF1F\uFF1F\uFF1F
                                        \u4F7F\u7528\u3010CSP\u3011\u548C\u3010DOM\u4E8B\u4EF6\u3011\uFF0C\u8FDB\u884C\u76D1\u542C\u9632\u5FA1\u3002
                                                DOM\u4E8B\u4EF6
                                                        \u76D1\u542C\u3010DOMNodeInserted\u3011\u3001\u3010DOMContentLoaded\u3011\u3001\u3010DOMAttrModified\u3011\u7B49\u4E8B\u4EF6\uFF0C\u53EF\u4EE5\u5728 \u524D\u7AEFDOM\u7ED3\u6784 \u53D1\u751F\u53D8\u5316\u65F6\u89E6\u53D1\u56DE\u8C03\u3002


                        \u94FE\u8DEF\u5C42\u52AB\u6301
                                TCP\u52AB\u6301
                                        TCP\u52AB\u6301\u7684\u4E3B\u8981\u76EE\u7684\u5982\u4E0B\uFF1A
                                                \uFF081\uFF09\u55C5\u63A2\u4FA6\u542C\u6D41\u91CF\uFF0C\u7A83\u5BC6\uFF1B
                                                \uFF082\uFF09\u8BBF\u95EE\u9650\u5236\uFF0C\u91CD\u5B9A\u5411\u5BFC\u81F4\u65AD\u7F51\u6216\u8005\u9493\u9C7C\u653B\u51FB\uFF1B
                                                \uFF083\uFF09\u7070\u4EA7\u5E7F\u544A\u5F15\u6D41\u3002

                                ARP\u52AB\u6301
                                        ARP\u52AB\u6301\u591A\u7528\u4E8E\u5C40\u57DF\u7F51\u653B\u51FB\uFF0C\u4E3B\u8981\u76EE\u7684\u5982\u4E0B\uFF1A
                                                \uFF081\uFF09\u55C5\u63A2\u4FA6\u542C\u6D41\u91CF\uFF0C\u7A83\u5BC6\uFF1B
                                                \uFF082\uFF09\u963B\u65AD\u7528\u6237\u7F51\u7EDC\u8FDE\u63A5\u3002

                                        \u4F8B\u5B50\uFF1A
                                                \u5982\u6BD4\u8F83\u7ECF\u5178\u7684ARP\u75C5\u6BD2\u201C\u4F20\u5947\u7F51\u5427\u6740\u624B\u201D\uFF0C
                                                        \u8BE5\u75C5\u6BD2\u4F5C\u8005\u7834\u89E3\u4E86\u201C\u4F20\u5947\u201D\u6E38\u620F\u7684\u52A0\u3001\u89E3\u5BC6\u7B97\u6CD5\uFF0C\u901A\u8FC7\u5206\u6790\u6E38\u620F\u7684\u901A\u4FE1\u534F\u8BAE\uFF0C\u5728\u7F51\u5427\u5185\u4F5C\u6848\uFF0C\u7A83\u53D6\u540C\u5728\u4E00\u4E2A\u7F51\u5427\u5C40\u57DF\u7F51\u5185\u7684\u201C\u4F20\u5947\u201D\u6E38\u620F\u73A9\u5BB6\u7684\u8BE6\u7EC6\u4FE1\u606F\u3002


                \u6D41\u91CF\u52AB\u6301\u9632\u5FA1\u65B9\u6CD5
                        DNS\u52AB\u6301\u9632\u5FA1
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B495\u79CD

                        HTTP\u52AB\u6301\u9632\u5FA1
                                123

                        \u94FE\u8DEF\u5C42\u52AB\u6301\u9632\u5FA1
                                TCP\u52AB\u6301
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B492\u79CD

                                ARP\u52AB\u6301
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B494\u79CD




                `))},{name:"\u5904\u7F6E\u65B9\u6CD5",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                DNS\u52AB\u6301\u5904\u7F6E
                        \u5C40\u57DF\u7F51DNS\u52AB\u6301\u5904\u7F6E
                                \u4E2A\u4EBA\u7EC8\u7AEFDNS\u52AB\u6301\u5904\u7F6E
                                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B495\u6761
                                \u4F01\u4E1ADNS\u670D\u52A1\u5668\u52AB\u6301\u5904\u7F6E
                                        DNS\u670D\u52A1\u5668\u52AB\u6301\u7684\u539F\u56E0\u5927\u591A\u662F\uFF1ADNS\u670D\u52A1\u5668\u5B58\u5728\u5B89\u5168\u9690\u60A3\u5BFC\u81F4\u670D\u52A1\u5668\u88AB\u5165\u4FB5\u3002
                                        \u56E0\u6B64\uFF0C\u9700\u8981\u5C06\u5F02\u5E38DNS\u670D\u52A1\u5668\u9694\u79BB\uFF0C\u5E76\u542F\u7528\u5907\u7528DNS\u670D\u52A1\u5668\u3002
                                                \u9694\u79BB\u5F02\u5E38DNS\u670D\u52A1\u5668\u7684\u76EE\u7684\u662F\u9632\u6B62\u653B\u51FB\u8005\u5229\u7528DNS\u670D\u52A1\u5668\u8FDB\u4E00\u6B65\u5165\u4FB5\u3002

                                        \u9694\u79BB\u4E3B\u8981\u91C7\u7528\u4EE5\u4E0B\u4E24\u79CD\u65B9\u6CD5\uFF1A
                                                123
                                                123

                        \u5E7F\u57DF\u7F51DNS\u52AB\u6301\u5904\u7F6E
                                123

                HTTP\u52AB\u6301\u5904\u7F6E
                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B493\u6761

                \u94FE\u8DEF\u5C42\u52AB\u6301\u5904\u7F6E
                        TCP\u52AB\u6301\u5904\u7F6E
                                123

                        ARP\u52AB\u6301\u5904\u7F6E
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B494\u6761

                `))},{name:"\u5E38\u7528\u5DE5\u5177",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                nslookup\u547D\u4EE4

                dig\u547D\u4EE4

                traceroute\u547D\u4EE4

                Wireshark\u5DE5\u5177

                \u6D41\u91CF\u55C5\u63A2\u5DE5\u5177    \uFF08\u662F\u4E0D\u662F\u6709\u70B9\u91CD\u590D\u4E86\uFF1F\uFF1F\uFF09
                        \u5E38\u89C1\u7684\u6D41\u91CF\u55C5\u63A2\u5DE5\u5177\u6709Cain\u3001NetFuke\u3001Ettercap\uFF0C\u53EF\u4F5C\u7528\u5728\u5C40\u57DF\u7F51\u8303\u56F4\u5185\u8FDB\u884C\u6D41\u91CF\u55C5\u63A2\u3001\u83B7\u53D6\u5C40\u57DF\u7F51\u5185\u654F\u611F\u4FE1\u606F\u3001\u52AB\u6301\u5C40\u57DF\u7F51\u5176\u4ED6\u4E3B\u673A\u6D41\u91CF\u7B49\u3002



                `))},{name:"\u64CD\u4F5C\u6307\u5357",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u521D\u6B65\u9884\u5224
                        \u9996\u5148\u9700\u8981\u786E\u5B9A\u662F\u5426\u906D\u9047\u6D41\u91CF\u52AB\u6301\u3002\u5F53\u51FA\u73B0\u4EE5\u4E0B\u60C5\u51B5\u65F6\uFF0C\u8868\u793A\u5F88\u53EF\u80FD\u906D\u9047\u6D41\u91CF\u52AB\u6301\u3002
                                \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B495\u6761

                        \u53EF\u901A\u8FC7\u4EE5\u4E0B\u65B9\u6CD5\u5224\u65AD\u5F53\u524D\u6D41\u91CF\u52AB\u6301\u7684\u7C7B\u578B\u3002
                                DNS\u52AB\u6301\uFF1A
                                        \u5F53\u5207\u6362\u8FD0\u8425\u5546\u7F51\u7EDC\u6216DNS\u8BBE\u7F6E\u540E\uFF0C\u8BBF\u95EE\u6062\u590D\u6B63\u5E38\u3002
                                HTTP\u52AB\u6301\uFF1A
                                        \u4F7F\u7528\u6D4F\u89C8\u5668F12\u529F\u80FD\u76D1\u542C\u7F51\u7EDC\u6D41\u91CF\u4E0E\u811A\u672C\u6587\u4EF6\uFF0C\u89C2\u5BDF\u54CD\u5E94\u662F\u5426\u53D1\u751F\u5728\u6E90\u670D\u52A1\u5668\u7684\u672C\u5730\u8D44\u6E90\u3002
                                \u94FE\u8DEF\u5C42\u52AB\u6301\uFF1A
                                        TCP\u52AB\u6301\u4E00\u822C\u53D1\u751F\u5728\u4E92\u8054\u7F51\u8BBF\u95EE\u65F6\uFF0C\u51FA\u73B0\u5E7F\u544A\u5F15\u6D41\u73B0\u8C61\uFF0C\u5F53\u5207\u6362\u8FD0\u8425\u5546\u7F51\u7EDC\u6216\u7269\u7406\u4F4D\u7F6E\u540E\uFF0C\u6062\u590D\u6B63\u5E38\uFF1B
                                        ARP\u52AB\u6301\u4E00\u822C\u53D1\u751F\u5728\u5C40\u57DF\u7F51\u5185\uFF0C\u53EF\u4EE5\u4F7F\u7528\u6293\u5305\u5DE5\u5177\uFF0C\u53D1\u73B0\u5927\u91CF\u5F02\u5E38\u7684ARP\u8BF7\u6C42\u3002

                DNS\u52AB\u6301\u6392\u67E5
                        DNS\u52AB\u6301\u4E3B\u8981\u901A\u8FC7\u8BA1\u7B97\u673Ahosts\u6587\u4EF6\u7BE1\u6539\u3001\u8DEF\u7531\u5668\u6216\u5176\u4ED6\u7F51\u7EDC\u8BBE\u5907DNS\u8BBE\u7F6E\u7BE1\u6539\u3001DNS\u670D\u52A1\u5668\u7F13\u5B58\u6C61\u67D3\u7B49\u624B\u6BB5\u5B9E\u73B0\u52AB\u6301\u653B\u51FB\u3002

                        \u6392\u67E5\u672C\u5730\u4FE1\u606F

                        \u6392\u67E5\u672C\u5730\u7F51\u5361DNS\u914D\u7F6E\u4FE1\u606F

                        \u6392\u67E5\u5F02\u5E38DNS\u670D\u52A1\u5668

                HTTP\u52AB\u6301\u6392\u67E5
                        123

                TCP\u52AB\u6301\u6392\u67E5
                        TCP\u52AB\u6301\u4E8B\u4EF6\u591A\u4E3A\u62A2\u5148\u56DE\u5305\u52AB\u6301\u4F1A\u8BDD\u3002
                                \u5982\u679C\u53D1\u751F\u52AB\u6301\uFF0C\u4F7F\u7528\u6293\u5305\u5DE5\u5177\uFF08Wireshark\uFF09\u6355\u83B7\u6D4F\u89C8\u5668\u8BBF\u95EE\u7684\u94FE\u8DEF\u5C42\u6D41\u91CF\uFF0C\u53EF\u53D1\u73B0\u5BF9\u6D4F\u89C8\u5668\u4EA7\u751F\u7684\u5355\u4E2A\u8BF7\u6C42\uFF0C\u540C\u65F6\u4F1A\u6536\u5230\u4E24\u4E2A\u4E0D\u540C\u7684TCP\u54CD\u5E94\u62A5\u6587\uFF0C
                                        \u56E0\u4E3A\u4F2A\u9020\u7684\u7B2C1\u4E2A\u6570\u636E\u5305\u5148\u5230\uFF0C\u6240\u4EE5\u7B2C2\u4E2A\u6B63\u5E38\u7684TCP\u54CD\u5E94\u6570\u636E\u5305\u88AB\u5BA2\u6237\u7AEF\u5FFD\u7565\u4E86\u3002

                ARP\u52AB\u6301\u6392\u67E5
                        \u3010arp\u3011\u547D\u4EE4

                        \u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u2026\u7B49\u7B49

                `))},{name:"\u5904\u7F6E\u6848\u4F8B",desc:u.a.createElement(u.a.Fragment,null),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

                \u4E8B\u4EF6\u80CC\u666F

                \u4E8B\u4EF6\u5904\u7F6E

                \u6839\u9664\u53CA\u6062\u590D

                `))}]}]},{name:"\u7ECF\u5178\u5B9E\u6218\u6848\u4F8B\u5256\u6790",desc:u.a.createElement(u.a.Fragment,null,e.\u5B9E\u6218\u89E3\u6790),content:u.a.createElement(u.a.Fragment,null,F.a.\u8F6C\u5316\u8001\u6587\u672C_\u4E3Apre\u6807\u7B7E(`

              \u670D\u52A1\u7AEF\u6EAF\u6E90\u3001\u8FD8\u539F\u573A\u666F\u3001\u8FD8\u539F\u653B\u51FB\u8DEF\u5F84
                  \u9AD8\u8D28\u91CF
                          \u4E00\u573A\u7CBE\u5FC3\u7B56\u5212\u7684\u9488\u5BF9\u9A71\u52A8\u4EBA\u751F\u516C\u53F8\u7684\u5B9A\u5411\u653B\u51FB\u6D3B\u52A8\u5206\u6790 - FreeBuf\u7F51\u7EDC\u5B89\u5168\u884C\u4E1A\u95E8\u6237
                              https://www.freebuf.com/articles/system/192194.html

              \u5BA2\u6237\u7AEF\u5E94\u6025\u54CD\u5E94\u3001\u573A\u666F\u5206\u6790
                  \u9AD8\u8D28\u91CF
                          \uFF08\u5BF9\u5E94\u7684\u3010\u9A71\u52A8\u4EBA\u751F\u3011\uFF09
                          \u67D0\u5E02\u67D0\u5355\u4F4D\u201C\u9A71\u52A8\u4EBA\u751F\u201D\u4E8B\u4EF67\u5C0F\u65F6\u5E94\u6025\u54CD\u5E94-\u534E\u76DF\u7F51
                              https://www.77169.net/html/231028.html

              `))}],b={name:"\u3010\u84DD\u961F\u3011_\u3010\u76D1\u6D4B\u7814\u5224\u3011_\u624B\u518C",steps:[{name:"\u5E94\u6025\u5904\u7406",desc:u.a.createElement(u.a.Fragment,null),steps:[].concat(f,v,L)},{name:"\u5176\u5B83",steps:[]}]},y=b,M=u.a.createElement(W.a,{cfg:y,lsKey:Object(W.b)(b.name)})},zdYZ:function(d,l,n){"use strict";n.r(l);var r=n("q1tI"),o=n.n(r),h=n("oaox"),c=function(){return o.a.createElement(o.a.Fragment,null,h.a)};l.default=c}}]);
