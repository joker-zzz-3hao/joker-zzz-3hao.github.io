(window.webpackJsonp=window.webpackJsonp||[]).push([[59],{GWUD:function(w,E,e){"use strict";e.d(E,"a",function(){return s});var z=e("fWQN"),b=e("mtLc"),v=e("p8+B"),L=e.n(v),F=e("bv8d"),o;(function(r){})(o||(o={}));var s=function(){function r(){Object(z.a)(this,r)}return Object(b.a)(r,null,[{key:"getData__1",value:function(y){var m=new v.Transformer,A=m.transform(y),C=A.root,h=A.features,g=C,I=!0;if(I){var j=m.getAssets(),H=j.styles,D=j.scripts;return{styles:H,scripts:D,root:g}}else{var p=m.getUsedAssets(h),R=p.styles,k=p.scripts;return{styles:R,scripts:k,root:g}}}},{key:"renderUI",value:function(y,m){var A=m.styles,C=m.scripts,h=F.Markmap,g=F.loadCSS,I=F.loadJS;A&&g(A),C&&I(C,{getMarkmap:function(){return F}});var p={};h.create("#".concat(r.id),p,y)}}]),r}();s.id="markmap"},hNvT:function(w,E,e){"use strict";e.r(E),E.default=`<Config>
  <AllUnits>
    <Unit id="1" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[\u6837\u4F8B\u6811]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="2" type="IMAGE" date="" viewable="1">
      <Title><![CDATA[Image\u8282\u70B9\u6837\u4F8B, \u70B9\u51FB\u56FE\u6807\u67E5\u770B\u539F\u56FE]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>http://qiniu.1000ride.cn/3zen/4a9639bac214a6c59c4a7932d88e648a.jpg</Image>
      <Url>http://qiniu.1000ride.cn/3zen/4a9639bac214a6c59c4a7932d88e648a.jpg</Url>
    </Unit>
    <Unit id="3" type="ARTICLE" date="" viewable="1">
      <Title><![CDATA[Text\u8282\u70B9\u6837\u4F8B, \u70B9\u51FB\u56FE\u6807\u67E5\u770B\u8BE6\u7EC6\u4FE1\u606F]]></Title>
      <Content><![CDATA[Here is the content area.
\u8FD9\u91CC\u662F\u6587\u672C\u5185\u5BB9\u533A\u57DF\u3002
\u9019\u88CF\u662F\u6587\u672C\u5167\u5BB9\u5340\u57DF\u3002
\u3053\u3053\u306F\u30C6\u30AD\u30B9\u30C8\u306E\u5185\u5BB9\u30A8\u30EA\u30A2\u3067\u3059\u3002
]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="4" type="WEBPAGE" date="" viewable="1">
      <Title><![CDATA[3ZENTREE\u64CD\u4F5C\u6307\u5357 V0.11]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>http://qiniu.1000ride.cn/3zen/7e48d1147aedfa53f2172ee93af341d5.jpg</Image>
      <Url>https://www.bilibili.com/video/BV14E411w716?from=search&amp;seid=17029345808406508</Url>
    </Unit>
    <Unit id="5" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[\u8BE5\u8282\u70B9\u5305\u542B3\u4E2A\u5B50\u8282\u70B9]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="6" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[Text\u8282\u70B9\u4F5C\u4E3A\u6807\u7B7E\u4F7F\u7528]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="7" type="IMAGE" date="" viewable="0">
      <Title><![CDATA[Image\u8282\u70B9\u4F5C\u4E3A\u6807\u7B7E\u4F7F\u7528]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>http://qiniu.1000ride.cn/3zen/1fdf8fe9d5178f6a0ede85c43e0e7abc.jpg</Image>
      <Url>http://qiniu.1000ride.cn/3zen/1fdf8fe9d5178f6a0ede85c43e0e7abc.jpg</Url>
    </Unit>
    <Unit id="10" type="WEBPAGE" date="" viewable="1">
      <Title><![CDATA[3ZENTREE V0.11 TRAILER]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>http://qiniu.1000ride.cn/3zen/b5dcb4551ae2c5bd17725fd3f7af5915.jpg</Image>
      <Url>https://www.bilibili.com/video/BV1aE411A759</Url>
    </Unit>
    <Unit id="11" type="IMAGE" date="" viewable="1">
      <Title><![CDATA[\u5728SAMPLETREE\u6587\u4EF6\u5939\u4E2D\u6709\u6837\u4F8B\u6811\u6587\u4EF6\uFF0C\u53EF\u4EE5\u70B9\u51FB\u53F3\u4E0A\u89D2\u7684\u6253\u5F00\u6587\u4EF6\u6309\u7EBD\u6D4F\u89C8]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>http://qiniu.1000ride.cn/3zen/21ca44d1ad43772ed0f7af42cd9653fd.png</Image>
      <Url>http://qiniu.1000ride.cn/3zen/21ca44d1ad43772ed0f7af42cd9653fd.png</Url>
    </Unit>
    <Unit id="12" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[\u7248\u672C\u8FDB\u5C55]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="13" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[VERSION 0.11]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="14" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[VERSION 0.12]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="15" type="WEBPAGE" date="" viewable="1">
      <Title><![CDATA[\u4E09\u751F\u4E4B\u6811V0.12\u65B0\u529F\u80FD\u9884\u544A ]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>https://indienova.com/home/blogread/25760</Url>
    </Unit>
    <Unit id="16" type="TREE" date="" viewable="1">
      <Title><![CDATA[\u6253\u5F00\u97F3\u4E50\u89C6\u754C]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>http://qiniu.1000ride.cn/3zen/a416c2a48e9f9ea6fef45bf01d1928dd.jpg</Image>
      <Url>http://1kvoidsoft.cn/3zentree/samples/MusicShiJie1003.3zen</Url>
    </Unit>
    <Unit id="19" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[V0.2 \u793E\u533A\u7248\u4F53\u9A8C\u7248]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="20" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[\u7ED3\u70B9\u95F4\u76F8\u4E92\u5173\u8054]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="22" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[\u793A\u4F8B\u70B9 2]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="23" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[\u793A\u4F8B\u70B9 1]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
    <Unit id="24" type="ARTICLE" date="" viewable="0">
      <Title><![CDATA[\u793A\u4F8B\u70B93]]></Title>
      <Content><![CDATA[]]></Content>
      <Image>
      </Image>
      <Url>
      </Url>
    </Unit>
  </AllUnits>
  <RootId>1</RootId>
  <NodeRelations>
    <Pair>1,3</Pair>
    <Pair>1,2</Pair>
    <Pair>1,5</Pair>
    <Pair>5,6</Pair>
    <Pair>5,7</Pair>
    <Pair>5,11</Pair>
    <Pair>1,12</Pair>
    <Pair>12,13</Pair>
    <Pair>13,10</Pair>
    <Pair>13,4</Pair>
    <Pair>13,14</Pair>
    <Pair>14,15</Pair>
    <Pair>19,16</Pair>
    <Pair>19,20</Pair>
    <Pair>20,22</Pair>
    <Pair>22,23</Pair>
    <Pair>20,23</Pair>
    <Pair>22,24</Pair>
    <Pair>23,24</Pair>
    <Pair>20,24</Pair>
    <Pair>4,22</Pair>
    <Pair>15,19</Pair>
  </NodeRelations>
  <Positions>
    <Unit id="1" x="0" y="0" z="0" />
    <Unit id="2" x="18.38835" y="9.959279" z="-1.396965" />
    <Unit id="3" x="4.896252" y="10.31" z="9.973402" />
    <Unit id="4" x="-25.63351" y="17.22527" z="6.620762" />
    <Unit id="5" x="-6.526437" y="14.71369" z="-23.58762" />
    <Unit id="6" x="-18.95987" y="25.08122" z="-22.55001" />
    <Unit id="7" x="6.483984" y="22.64621" z="-21.24136" />
    <Unit id="10" x="-18.14646" y="17.21843" z="22.14528" />
    <Unit id="11" x="-5.150176" y="19.2984" z="-31.36553" />
    <Unit id="12" x="-14.27363" y="8.894099" z="9.325737" />
    <Unit id="13" x="-20.44415" y="13.00101" z="13.2058" />
    <Unit id="14" x="-25.52227" y="21.53514" z="16.44717" />
    <Unit id="15" x="-21.9026" y="27.10298" z="22.37621" />
    <Unit id="16" x="-47.8435" y="43.10975" z="8.174094" />
    <Unit id="19" x="-52.50779" y="35.74895" z="0.6249869" />
    <Unit id="20" x="-43.99975" y="45.16475" z="-5.63751" />
    <Unit id="22" x="-47.25771" y="53.97559" z="-11.64381" />
    <Unit id="23" x="-39.87237" y="50.37052" z="-32.18356" />
    <Unit id="24" x="-56.90061" y="44.8783" z="-12.35322" />
  </Positions>
  <ExtraUnitInfo>
  </ExtraUnitInfo>
  <Members>
  </Members>
  <TreeStyle>
    <LayerRange>8</LayerRange>
    <LayerHeight>8</LayerHeight>
    <LineRadius>0.2821429</LineRadius>
    <LineColor>#2E2E2EFF</LineColor>
    <CurveType>far</CurveType>
    <CurveNodeNum>20</CurveNodeNum>
  </TreeStyle>
  <TreeNodeStyle>
    <WindowColor>#aaaaaaff</WindowColor>
    <FontColor>#000000ff</FontColor>
  </TreeNodeStyle>
  <CameraConfig>
    <Distance>73.34229</Distance>
    <OffsetY>35.99998</OffsetY>
    <DegreeX>-2976.388</DegreeX>
    <DegreeY>-21.60001</DegreeY>
  </CameraConfig>
  <VisualEnvironment>
    <SkyboxId>2</SkyboxId>
    <ThemeId>0</ThemeId>
  </VisualEnvironment>
</Config>
`},vvOS:function(w,E,e){"use strict";e.r(E),e.d(E,"_",function(){return J});var z=e("5NDa"),b=e("5rEg"),v=e("k1fw"),L=e("tJVT"),F=e("q1tI"),o=e.n(F),s=e("fWQN"),r=e("mtLc"),O=e("mPz0"),y=e.n(O),m=e("hNvT").default,A=function(){function t(){Object(s.a)(this,t)}return Object(r.a)(t,null,[{key:"test",value:function(){var n=new y.a({keepCData:!0,selfClosingElements:!1,keepText:!0}),u=n.xml2js(m),d=n.js2xml(u);return{document_obj:u,xml_str:d,x2js:n}}},{key:"simpleBeauty_\u7B80\u5355\u7F8E\u5316_xmlStr",value:function(n){return n.replaceAll(/(\w>)(<\w)/g,`$1
$2`)}}]),t}(),C=[`
# \u8FD9\u91CC\uFF0C\u4F3C\u4E4E\u653E\u4EC0\u4E48\u90FD\u53EF\u4EE5
\u5F00\u59CB\u7684\u5730\u65B9


`,`
- \u9996\u5148\uFF1A
    - \u4FE1\u606F\u6536\u96C6\u7684\u4E1C\u897F
        - \u5DE5\u5546\u94F6\u884C  \u662F\u5206\u884C\uFF0C\u6240\u4EE5\u4E0B\u5C5E\u7684  \u4E00\u822C\u90FD\u6302\u5728  \u603B\u884C
            - \u5206\u884C\uFF0C\u7C7B\u4F3C\u4E8E  \u4E00\u4E2A\u90E8\u95E8
        - \u627E\u5230\u4E00\u4E9B  \u8D44\u4EA7
            - \u5305\u62EC\uFF0C\u5907\u6848    \u7684\u4E00\u4E9B\u4E1C\u897F
    - \u53BB\u6E17\u900F\uFF1A
        - \u6846\u67B6\u7684\u6D1E\uFF1A
            - \u4E00\u4E9B\u7AD9\uFF0C  \u53EF\u80FD\u90FD\u662F    Vue  +  SpringBoot  \u7684\u4E1C\u897F
                - \u4ECEVue\u6E90\u7801\u4E2D\uFF0C\u53EF\u4EE5\u53BB\u627E
                    - \u63A5\u53E3\u554A  \u4EC0\u4E48\u7684\uFF0C\u5F88\u591A\u3002
                        - \u53EF\u4EE5\u627E\u4E00\u4E9B    \u63A5\u53E3\u8D8A\u6743\u7684\u3001    \u6CC4\u9732\u654F\u611F\u4FE1\u606F\u3001    \u903B\u8F91\u6F0F\u6D1E    \u7684
                            - \u8FD9\u6837\u7684\u8BDD    \u53EF\u80FD\u53EF\u4EE5  \u6253\u5230\u540E\u53F0\u3002
                                - \u4F46  shell\u8FD9\u5757\uFF0C\u5C31\u4E0D\u7528\u60F3\u4E86    \u4E00\u822C\u6253\u4E0D\u8FDB\u53BB
                        - \u8FD8\u53EF\u80FD\u6709\u4E00\u4E9B    SQL\u6CE8\u5165  \u8FD9\u5757\u7684
                - \u7136\u540E\u8FD9\u5757\u7684\u8BDD    shell\u4E00\u822C\u4E0D\u7528\u60F3\u4E86
                    - \u54EA\u6015\u4F20\u4E0A\u53BB\u4E86    \u540E\u53F0\u7684  SpringBoot    \u4E5F\u4E0D\u4F1A\u89E3\u6790
                        - \u5BF9\u4E8E\u3010jsp\u3011\uFF0C\u5C31\u6CA1\u6709\u505A\u89E3\u6790
        - \u5173\u4E8E  0day
            - \u4E0D\u50CF  \u653B\u9632  \u90A3\u6837\u7684\uFF0C0day\u8FD9\u6837\u7684\u4E1C\u897F\uFF0C\u5C31\u4E0D\u7528\u53BB\u60F3\u4E86
            - \u6846\u67B6\u7684\u6D1E\uFF0C\u57FA\u672C\u4E0A\u4E5F\u6CA1\u6709
            - \u8FD8\u6709\u4E00\u79CD\u60C5\u51B5\uFF1A
                - \u4F60\u80FD\u591F  \u62FF\u5230  \u5DE5\u5546\u7684\u6E90\u7801\uFF0C\u7136\u540E\u5BA1\u51FA    \u4E00\u4E2A0day\u3002
        - 1
    - \u8FD8\u6709\u5176\u5B83\u7684\uFF0C\u7B49\u4F1A\u52A0
    - \u540E\u7EED\u5907\u6CE8\uFF1A
        - 1\u3001\u76EE\u6807\uFF1A\u5317\u4EAC\uFF0C\u5929\u6D25\uFF0C\u6CB3\u5317\uFF0C\u5409\u6797\uFF0C\u9ED1\u9F99\u6C5F\uFF0C\u8FBD\u5B81\uFF0C\u5927\u8FDE\uFF0C\u5DE5\u94F6\u79D1\u6280\u3002
        - 2\u3001\u975E\u76EE\u6807\uFF1A\u624B\u673A\u94F6\u884C\u3001\u878D\u6613\u8054\u3001\u878D\u6613\u8D2D\u7B49\u603B\u884C\u5E94\u7528\u548C\u5176\u4ED6\u5355\u4F4D\u4E0D\u5728\u672C\u6B21\u4F17\u6D4B\u8303\u56F4\u5185
        - 3\u3001\u505A\u8FB9\u754C\u7A81\u7834\uFF0C\u4E00\u5B9A\u8981\u62A5\u5907\uFF0C\u4E0D\u786E\u5B9A\u7684\u8D44\u4EA7\u968F\u65F6\u5728\u672C\u7FA4\u5185\u6C9F\u901A\uFF0C\u6D89\u53CA\u649E\u5E93\u4E4B\u5217\u7684\u64CD\u4F5C\uFF0C\u8981\u63A7\u5236\u4E00\u4E0B\uFF0C\u80FD\u4E0D\u505A\u6700\u597D\u4E0D\u505A\uFF0C\u4E0D\u8981\u5F04\u51FA\u751F\u4EA7\u4E8B\u6545\u3002\u4E0D\u80FD\u9493\u9C7C\u3002
        - 4\u3001\u5168\u7A0B\u5F55\u5C4F\uFF0C\u6BCF\u65E5\u6309\u8981\u6C42\u62A5\u5907IP\u3002
`].join(`
`).trim(),h=function(){function t(){Object(s.a)(this,t)}return Object(r.a)(t,null,[{key:"test",value:function(){var n=e("1M3H"),u=new n,d=u.render(C),_=u.parse(C)}}]),t}(),g=function(){function t(){Object(s.a)(this,t)}return Object(r.a)(t,null,[{key:"test",value:function(){var n=e("fFwQ"),u=new n.Renderer;u.heading=function(a,i){return JSON.stringify({type:"heading",level:i,text:a})},u.paragraph=function(a){return JSON.stringify({type:"paragraph",text:a})},u.heading=function(a,i){return JSON.stringify({type:"heading",level:i,text:a})},function(){u.space=function(a){return JSON.stringify({type:"space",text:a})}}();var d=n.lexer(C),_=JSON.stringify(d.map(function(a){u[a.type](a.text)}).join(`
`))}}]),t}(),I=function(){function t(){Object(s.a)(this,t)}return Object(r.a)(t,null,[{key:"test",value:function(){var n=e("Ijy0"),u=n.parse(C)}}]),t}(),p=function(){function t(){Object(s.a)(this,t)}return Object(r.a)(t,null,[{key:"test",value:function(){var n=e("kUvq")}}]),t}(),R=function t(){Object(s.a)(this,t)},k=function t(){Object(s.a)(this,t)},j=e("GWUD"),H={\u5E26\u56FE\u7247:{type:"IMAGE",isLarge:"1",\u7AD6\u8F74vert_ratio:5*1.5,\u6C34\u5E73hor_ratio:2/2,is_horRandom\u6C34\u5E73\u968F\u673A:!1},\u4EC5\u8282\u70B9:{type:"ARTICLE",isLarge:"0",\u7AD6\u8F74vert_ratio:5*2,\u6C34\u5E73hor_ratio:2/1.5,is_horRandom\u6C34\u5E73\u968F\u673A:!1}},D=H.\u4EC5\u8282\u70B9,W=function(){function t(){Object(s.a)(this,t),this.node_arr=[],this.pair_arr=[],this.position_arr=[],this.ID=0}return Object(r.a)(t,[{key:"get_id",value:function(){return this.ID+=1,this.ID}},{key:"get_2d_rand",value:function(n){var u=arguments.length>1&&arguments[1]!==void 0?arguments[1]:0;return Math.random()*n-n/2+u}},{key:"get_\u4E8C\u7EF4\u5206\u5E03_\u7B2C1\u79CD_\u968F\u673A",value:function(){var n=this.get_2d_rand(35)+"",u=this.get_2d_rand(35)+"";return{_x:n,_z:u}}},{key:"get_\u4E8C\u7EF4\u5206\u5E03_\u7B2C2\u79CD_\u87BA\u65CB\u7EBF",value:function(n,u){function d(){for(var B={a_\u57FA\u6570:0,b_\u968F\u5F27\u5EA6\u589E\u957F\u901F\u5EA6:10},c={angle:0},P=[],T={\u5F27\u5EA6\u589E\u957F:.1,\u6700\u5927\u5708\u6570:2},U=T.\u6700\u5927\u5708\u6570*2*Math.PI;c.angle<=U;){var x={x:0,y:0},f=B.a_\u57FA\u6570,N=B.b_\u968F\u5F27\u5EA6\u589E\u957F\u901F\u5EA6,M=c.angle;x.x=(f+N*M)*Math.cos(M),x.y=(f+N*M)*Math.sin(M),P.push(x),c.angle=M+T.\u5F27\u5EA6\u589E\u957F}}var _={\u5F27\u5EA6\u589E\u957F:Math.PI*3/4,\u957F\u5EA6:{\u57FA\u6570:0,\u589E\u957F\u534A\u5F84:D.\u6C34\u5E73hor_ratio}},a=_.\u5F27\u5EA6\u589E\u957F*((D.is_horRandom\u6C34\u5E73\u968F\u673A?Math.random()*Math.PI*2:0)+n*.8+(u+1)),i=_.\u957F\u5EA6.\u57FA\u6570+_.\u957F\u5EA6.\u589E\u957F\u534A\u5F84*a;return{_x:i*Math.cos(a)+"",_z:i*Math.sin(a)+""}}},{key:"_\u9012\u5F52_\u5206\u6790",value:function(n,u,d){var _,a=this;n._3d_id=this.get_id(),this.node_arr.push({Title:{__cdata:n.v},Content:{__text:n.v},Image:{__text:"http://qiniu.1000ride.cn/3zen/4a9639bac214a6c59c4a7932d88e648a.jpg"},Url:{},_id:n._3d_id+"",_date:"",_viewable:D.isLarge,_type:D.type});var i=this.get_\u4E8C\u7EF4\u5206\u5E03_\u7B2C2\u79CD_\u87BA\u65CB\u7EBF(n.d,u),B=i._x,c=i._z;this.position_arr.push({_id:n._3d_id+"",_x:B,_y:D.\u7AD6\u8F74vert_ratio*n.d+"",_z:c}),d&&this.pair_arr.push({__text:"".concat(d._3d_id,",").concat(n._3d_id)}),(_=n.c)===null||_===void 0||_.forEach(function(P,T){a._\u9012\u5F52_\u5206\u6790(P,T,n)})}}]),t}(),V=e("ysNt"),G=e("be4S"),S=new G.a("VulnBox"),J=function(){var l=Object(F.useState)(S.loadData____\u5141\u8BB8\u90E8\u5206\u6570\u636E\u6B8B\u7F3A()),n=Object(L.a)(l,2),u=n[0],d=n[1];function _(){var a=A.test(),i=a.document_obj,B=a.xml_str,c=a.x2js;h.test(),g.test(),I.test(),p.test();var P=j.a.getData__1(u.markdown_str||C),T=P.root,U=new W;U._\u9012\u5F52_\u5206\u6790(T,0);var x={Config:Object(v.a)(Object(v.a)({},i.Config),{},{AllUnits:{Unit:U.node_arr},NodeRelations:{Pair:U.pair_arr},Positions:{Unit:U.position_arr}})},f=c.js2xml(x);f=A.simpleBeauty_\u7B80\u5355\u7F8E\u5316_xmlStr(f),S.\u5168\u91CF_setState_and_save\u4FDD\u5B58\u5230\u672C\u5730(Object(v.a)(Object(v.a)({},u),{},{xml_str:f}),d),Object(V.j)(f)}return Object(F.useEffect)(function(){_()},[u.markdown_str]),o.a.createElement(o.a.Fragment,null,o.a.createElement("div",null,o.a.createElement("h1",null,"1"),o.a.createElement(b.a.TextArea,{value:u.markdown_str,autoSize:{minRows:8},onChange:function(i){S.simple_set_and_save("markdown_str",i,u,d)}})),o.a.createElement("div",null,o.a.createElement("h1",null,"2"),o.a.createElement(b.a.TextArea,{disabled:!0,value:u.xml_str,autoSize:{minRows:8}})))},X=E.default=J}}]);
